﻿namespace Agenda_Estudiantil
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textNombre = new System.Windows.Forms.TextBox();
            this.textapeli = new System.Windows.Forms.TextBox();
            this.textdirec = new System.Windows.Forms.TextBox();
            this.textced = new System.Windows.Forms.TextBox();
            this.cBxnacionalida = new System.Windows.Forms.ComboBox();
            this.texttel = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textunidda = new System.Windows.Forms.TextBox();
            this.textmail = new System.Windows.Forms.TextBox();
            this.textedad = new System.Windows.Forms.TextBox();
            this.cBxcarrera = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cBxCiclo = new System.Windows.Forms.ComboBox();
            this.dataRegistro = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nacionalida = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cedula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Carrera = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ciclo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Genero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado_Civil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tipo_sangre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grBGenero = new System.Windows.Forms.GroupBox();
            this.checkF = new System.Windows.Forms.CheckBox();
            this.checkM = new System.Windows.Forms.CheckBox();
            this.butAdd = new System.Windows.Forms.Button();
            this.butEdd = new System.Windows.Forms.Button();
            this.butEliminar = new System.Windows.Forms.Button();
            this.butnew = new System.Windows.Forms.Button();
            this.textestadoC = new System.Windows.Forms.TextBox();
            this.combosangre = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataRegistro)).BeginInit();
            this.grBGenero.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Apellidos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Direccion";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cedula";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(50, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Nacionalidad";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(50, 265);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Telefono";
            // 
            // textNombre
            // 
            this.textNombre.Location = new System.Drawing.Point(157, 23);
            this.textNombre.Name = "textNombre";
            this.textNombre.Size = new System.Drawing.Size(143, 22);
            this.textNombre.TabIndex = 6;
            this.textNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNombre_KeyPress);
            // 
            // textapeli
            // 
            this.textapeli.Location = new System.Drawing.Point(157, 73);
            this.textapeli.Name = "textapeli";
            this.textapeli.Size = new System.Drawing.Size(143, 22);
            this.textapeli.TabIndex = 7;
            this.textapeli.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textapeli_KeyPress);
            // 
            // textdirec
            // 
            this.textdirec.Location = new System.Drawing.Point(157, 117);
            this.textdirec.Name = "textdirec";
            this.textdirec.Size = new System.Drawing.Size(143, 22);
            this.textdirec.TabIndex = 8;
            this.textdirec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textdirec_KeyPress);
            // 
            // textced
            // 
            this.textced.Location = new System.Drawing.Point(157, 160);
            this.textced.Name = "textced";
            this.textced.Size = new System.Drawing.Size(100, 22);
            this.textced.TabIndex = 9;
            this.textced.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textced_KeyPress);
            // 
            // cBxnacionalida
            // 
            this.cBxnacionalida.FormattingEnabled = true;
            this.cBxnacionalida.Items.AddRange(new object[] {
            "Ecuador",
            "Peru",
            "Estados Unidos ",
            "Colombia",
            "Chile ",
            "Paraguay",
            "Mexico"});
            this.cBxnacionalida.Location = new System.Drawing.Point(157, 204);
            this.cBxnacionalida.Name = "cBxnacionalida";
            this.cBxnacionalida.Size = new System.Drawing.Size(121, 24);
            this.cBxnacionalida.TabIndex = 10;
            // 
            // texttel
            // 
            this.texttel.Location = new System.Drawing.Point(157, 259);
            this.texttel.Name = "texttel";
            this.texttel.Size = new System.Drawing.Size(100, 22);
            this.texttel.TabIndex = 11;
            this.texttel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.texttel_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(332, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "Unidad Educativa";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(332, 79);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "Mail";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(332, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "Carrera";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(332, 166);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "Ciclo";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(332, 207);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 16);
            this.label11.TabIndex = 16;
            this.label11.Text = "Edad";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(332, 262);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 16);
            this.label12.TabIndex = 17;
            this.label12.Text = "Estado civil";
            // 
            // textunidda
            // 
            this.textunidda.Location = new System.Drawing.Point(469, 23);
            this.textunidda.Name = "textunidda";
            this.textunidda.Size = new System.Drawing.Size(188, 22);
            this.textunidda.TabIndex = 18;
            // 
            // textmail
            // 
            this.textmail.Location = new System.Drawing.Point(469, 73);
            this.textmail.Name = "textmail";
            this.textmail.Size = new System.Drawing.Size(152, 22);
            this.textmail.TabIndex = 19;
            // 
            // textedad
            // 
            this.textedad.Location = new System.Drawing.Point(469, 201);
            this.textedad.Name = "textedad";
            this.textedad.Size = new System.Drawing.Size(65, 22);
            this.textedad.TabIndex = 22;
            this.textedad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textedad_KeyPress);
            // 
            // cBxcarrera
            // 
            this.cBxcarrera.FormattingEnabled = true;
            this.cBxcarrera.Items.AddRange(new object[] {
            "Analisis de Sistemas",
            "Mecanica Industrial",
            "Industria de Alimentos",
            "Diseño Grafico",
            "Redes Telecomunicacion"});
            this.cBxcarrera.Location = new System.Drawing.Point(469, 117);
            this.cBxcarrera.Name = "cBxcarrera";
            this.cBxcarrera.Size = new System.Drawing.Size(121, 24);
            this.cBxcarrera.TabIndex = 24;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Agenda_Estudiantil.Properties.Resources._2;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(752, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 102);
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(758, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 16);
            this.label13.TabIndex = 26;
            this.label13.Text = "Fotografia";
            // 
            // cBxCiclo
            // 
            this.cBxCiclo.FormattingEnabled = true;
            this.cBxCiclo.Items.AddRange(new object[] {
            "Primer Ciclo",
            "Segundo Ciclo",
            "Tercer Ciclo",
            "Cuarto Ciclo",
            "Quinto Ciclo",
            "Sexto Ciclo"});
            this.cBxCiclo.Location = new System.Drawing.Point(469, 163);
            this.cBxCiclo.Name = "cBxCiclo";
            this.cBxCiclo.Size = new System.Drawing.Size(121, 24);
            this.cBxCiclo.TabIndex = 27;
            // 
            // dataRegistro
            // 
            this.dataRegistro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataRegistro.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Nacionalida,
            this.Cedula,
            this.Nombre,
            this.Apellido,
            this.Telefono,
            this.Direccion,
            this.Mail,
            this.Carrera,
            this.Ciclo,
            this.Genero,
            this.Edad,
            this.Estado_Civil,
            this.Tipo_sangre});
            this.dataRegistro.Location = new System.Drawing.Point(3, 303);
            this.dataRegistro.Name = "dataRegistro";
            this.dataRegistro.Size = new System.Drawing.Size(1491, 150);
            this.dataRegistro.TabIndex = 29;
            this.dataRegistro.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataRegistro_CellClick);
            // 
            // Column1
            // 
            this.Column1.FillWeight = 30F;
            this.Column1.HeaderText = "#";
            this.Column1.Name = "Column1";
            this.Column1.Width = 30;
            // 
            // Nacionalida
            // 
            this.Nacionalida.FillWeight = 120F;
            this.Nacionalida.HeaderText = "Nacionalida";
            this.Nacionalida.Name = "Nacionalida";
            this.Nacionalida.Width = 120;
            // 
            // Cedula
            // 
            this.Cedula.FillWeight = 120F;
            this.Cedula.HeaderText = "Cedula";
            this.Cedula.Name = "Cedula";
            this.Cedula.Width = 120;
            // 
            // Nombre
            // 
            this.Nombre.FillWeight = 140F;
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.Width = 140;
            // 
            // Apellido
            // 
            this.Apellido.FillWeight = 140F;
            this.Apellido.HeaderText = "Apellido";
            this.Apellido.Name = "Apellido";
            this.Apellido.Width = 140;
            // 
            // Telefono
            // 
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.Name = "Telefono";
            // 
            // Direccion
            // 
            this.Direccion.FillWeight = 140F;
            this.Direccion.HeaderText = "Direccion";
            this.Direccion.Name = "Direccion";
            this.Direccion.Width = 140;
            // 
            // Mail
            // 
            this.Mail.FillWeight = 140F;
            this.Mail.HeaderText = "Mail";
            this.Mail.Name = "Mail";
            this.Mail.Width = 140;
            // 
            // Carrera
            // 
            this.Carrera.FillWeight = 140F;
            this.Carrera.HeaderText = "Carrera";
            this.Carrera.Name = "Carrera";
            this.Carrera.Width = 140;
            // 
            // Ciclo
            // 
            this.Ciclo.FillWeight = 60F;
            this.Ciclo.HeaderText = "Ciclo";
            this.Ciclo.Name = "Ciclo";
            this.Ciclo.Width = 60;
            // 
            // Genero
            // 
            this.Genero.FillWeight = 60F;
            this.Genero.HeaderText = "Genero";
            this.Genero.Name = "Genero";
            this.Genero.Width = 60;
            // 
            // Edad
            // 
            this.Edad.FillWeight = 60F;
            this.Edad.HeaderText = "Edad";
            this.Edad.Name = "Edad";
            this.Edad.Width = 60;
            // 
            // Estado_Civil
            // 
            this.Estado_Civil.HeaderText = "Estado_Civil";
            this.Estado_Civil.Name = "Estado_Civil";
            // 
            // Tipo_sangre
            // 
            this.Tipo_sangre.HeaderText = "Tipo_sangre";
            this.Tipo_sangre.Name = "Tipo_sangre";
            // 
            // grBGenero
            // 
            this.grBGenero.Controls.Add(this.checkF);
            this.grBGenero.Controls.Add(this.checkM);
            this.grBGenero.Enabled = false;
            this.grBGenero.Location = new System.Drawing.Point(629, 100);
            this.grBGenero.Name = "grBGenero";
            this.grBGenero.Size = new System.Drawing.Size(102, 83);
            this.grBGenero.TabIndex = 30;
            this.grBGenero.TabStop = false;
            this.grBGenero.Text = "Genero";
            this.grBGenero.Enter += new System.EventHandler(this.grBGenero_Enter);
            // 
            // checkF
            // 
            this.checkF.AutoSize = true;
            this.checkF.Location = new System.Drawing.Point(11, 51);
            this.checkF.Name = "checkF";
            this.checkF.Size = new System.Drawing.Size(36, 20);
            this.checkF.TabIndex = 1;
            this.checkF.Text = "F";
            this.checkF.UseVisualStyleBackColor = true;
            // 
            // checkM
            // 
            this.checkM.AutoSize = true;
            this.checkM.Location = new System.Drawing.Point(11, 26);
            this.checkM.Name = "checkM";
            this.checkM.Size = new System.Drawing.Size(39, 20);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            // 
            // butAdd
            // 
            this.butAdd.Location = new System.Drawing.Point(980, 41);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(75, 23);
            this.butAdd.TabIndex = 31;
            this.butAdd.Text = "Agregar";
            this.butAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butAdd, "Agrerga un dato");
            this.butAdd.UseVisualStyleBackColor = true;
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // butEdd
            // 
            this.butEdd.Location = new System.Drawing.Point(980, 100);
            this.butEdd.Name = "butEdd";
            this.butEdd.Size = new System.Drawing.Size(75, 23);
            this.butEdd.TabIndex = 32;
            this.butEdd.Text = "Editar";
            this.butEdd.UseVisualStyleBackColor = true;
            this.butEdd.Click += new System.EventHandler(this.butEdd_Click);
            // 
            // butEliminar
            // 
            this.butEliminar.Location = new System.Drawing.Point(980, 151);
            this.butEliminar.Name = "butEliminar";
            this.butEliminar.Size = new System.Drawing.Size(75, 23);
            this.butEliminar.TabIndex = 33;
            this.butEliminar.Text = "Eliminar";
            this.butEliminar.UseVisualStyleBackColor = true;
            this.butEliminar.Click += new System.EventHandler(this.butEliminar_Click);
            // 
            // butnew
            // 
            this.butnew.Location = new System.Drawing.Point(980, 201);
            this.butnew.Name = "butnew";
            this.butnew.Size = new System.Drawing.Size(75, 23);
            this.butnew.TabIndex = 34;
            this.butnew.Text = "Nuevo";
            this.butnew.UseVisualStyleBackColor = true;
            this.butnew.Click += new System.EventHandler(this.butnew_Click);
            // 
            // textestadoC
            // 
            this.textestadoC.Location = new System.Drawing.Point(469, 256);
            this.textestadoC.Name = "textestadoC";
            this.textestadoC.Size = new System.Drawing.Size(100, 22);
            this.textestadoC.TabIndex = 23;
            this.textestadoC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textestadoC_KeyPress);
            // 
            // combosangre
            // 
            this.combosangre.FormattingEnabled = true;
            this.combosangre.Items.AddRange(new object[] {
            "ORH+",
            "ORH-",
            "AB+",
            "AB-"});
            this.combosangre.Location = new System.Drawing.Point(629, 199);
            this.combosangre.Name = "combosangre";
            this.combosangre.Size = new System.Drawing.Size(121, 24);
            this.combosangre.TabIndex = 35;
            this.combosangre.Text = "Tipo de Sangre";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1542, 455);
            this.Controls.Add(this.combosangre);
            this.Controls.Add(this.butnew);
            this.Controls.Add(this.butEliminar);
            this.Controls.Add(this.butEdd);
            this.Controls.Add(this.butAdd);
            this.Controls.Add(this.grBGenero);
            this.Controls.Add(this.dataRegistro);
            this.Controls.Add(this.cBxCiclo);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cBxcarrera);
            this.Controls.Add(this.textestadoC);
            this.Controls.Add(this.textedad);
            this.Controls.Add(this.textmail);
            this.Controls.Add(this.textunidda);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.texttel);
            this.Controls.Add(this.cBxnacionalida);
            this.Controls.Add(this.textced);
            this.Controls.Add(this.textdirec);
            this.Controls.Add(this.textapeli);
            this.Controls.Add(this.textNombre);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Agenda Estudiantil";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataRegistro)).EndInit();
            this.grBGenero.ResumeLayout(false);
            this.grBGenero.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textNombre;
        private System.Windows.Forms.TextBox textapeli;
        private System.Windows.Forms.TextBox textdirec;
        private System.Windows.Forms.TextBox textced;
        private System.Windows.Forms.ComboBox cBxnacionalida;
        private System.Windows.Forms.TextBox texttel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textunidda;
        private System.Windows.Forms.TextBox textmail;
        private System.Windows.Forms.TextBox textedad;
        private System.Windows.Forms.ComboBox cBxcarrera;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cBxCiclo;
        private System.Windows.Forms.DataGridView dataRegistro;
        private System.Windows.Forms.GroupBox grBGenero;
        private System.Windows.Forms.CheckBox checkF;
        private System.Windows.Forms.CheckBox checkM;
        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.Button butEdd;
        private System.Windows.Forms.Button butEliminar;
        private System.Windows.Forms.Button butnew;
        private System.Windows.Forms.TextBox textestadoC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nacionalida;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cedula;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Carrera;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ciclo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Genero;
        private System.Windows.Forms.DataGridViewTextBoxColumn Edad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado_Civil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tipo_sangre;
        private System.Windows.Forms.ComboBox combosangre;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

