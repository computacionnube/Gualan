﻿namespace Agenda_Estudiantil
{
    partial class Pj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butaceptar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butaceptar
            // 
            this.butaceptar.Location = new System.Drawing.Point(188, 46);
            this.butaceptar.Name = "butaceptar";
            this.butaceptar.Size = new System.Drawing.Size(75, 23);
            this.butaceptar.TabIndex = 0;
            this.butaceptar.Text = "Guardar";
            this.butaceptar.UseVisualStyleBackColor = true;
            this.butaceptar.Click += new System.EventHandler(this.butaceptar_Click);
            // 
            // Pj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.butaceptar);
            this.Name = "Pj";
            this.Text = "Pj";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butaceptar;
    }
}