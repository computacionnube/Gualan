﻿namespace Agenda_Estudiantil
{
    partial class Datos_Ins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.butAnterior = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textUnidad = new System.Windows.Forms.TextBox();
            this.cbCarrera = new System.Windows.Forms.ComboBox();
            this.textprofesor = new System.Windows.Forms.TextBox();
            this.textdirecINt = new System.Windows.Forms.TextBox();
            this.texttelfIns = new System.Windows.Forms.TextBox();
            this.groupmaterias = new System.Windows.Forms.GroupBox();
            this.chquimi = new System.Windows.Forms.CheckBox();
            this.chkCal = new System.Windows.Forms.CheckBox();
            this.chkmant = new System.Windows.Forms.CheckBox();
            this.chkMeto = new System.Windows.Forms.CheckBox();
            this.chkComuni = new System.Windows.Forms.CheckBox();
            this.chkingle = new System.Windows.Forms.CheckBox();
            this.chkFlui = new System.Windows.Forms.CheckBox();
            this.chkDise = new System.Windows.Forms.CheckBox();
            this.cobCurso = new System.Windows.Forms.ComboBox();
            this.textmailIst = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbEstudisS = new System.Windows.Forms.RadioButton();
            this.rbquimica = new System.Windows.Forms.RadioButton();
            this.rbCienci = new System.Windows.Forms.RadioButton();
            this.rbfisica = new System.Windows.Forms.RadioButton();
            this.textfax = new System.Windows.Forms.TextBox();
            this.textProvincia = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.butbuscar1 = new System.Windows.Forms.Button();
            this.groupmaterias.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // butAnterior
            // 
            this.butAnterior.Location = new System.Drawing.Point(971, 7);
            this.butAnterior.Name = "butAnterior";
            this.butAnterior.Size = new System.Drawing.Size(75, 23);
            this.butAnterior.TabIndex = 48;
            this.butAnterior.Text = "Previous";
            this.butAnterior.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butAnterior, "Regresa al campo prinsipal");
            this.butAnterior.UseVisualStyleBackColor = true;
            this.butAnterior.Click += new System.EventHandler(this.butAnterior_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Fotografia";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(138, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 16);
            this.label6.TabIndex = 56;
            this.label6.Text = "Telefono_Institucion";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(138, 295);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 16);
            this.label5.TabIndex = 55;
            this.label5.Text = "Direccion INstitucion";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(138, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 16);
            this.label4.TabIndex = 54;
            this.label4.Text = "Profesor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(145, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 16);
            this.label2.TabIndex = 52;
            this.label2.Text = "Carrera";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(138, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 16);
            this.label7.TabIndex = 51;
            this.label7.Text = "Unidad Educativa";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(410, 69);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 13);
            this.label15.TabIndex = 62;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(488, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(129, 16);
            this.label14.TabIndex = 61;
            this.label14.Text = "@Mail_Institucion";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(410, 192);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 13);
            this.label12.TabIndex = 60;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(445, 192);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 13);
            this.label11.TabIndex = 59;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(138, 131);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 16);
            this.label8.TabIndex = 58;
            this.label8.Text = "Curso";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(163, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 13);
            this.label13.TabIndex = 57;
            // 
            // textUnidad
            // 
            this.textUnidad.Location = new System.Drawing.Point(275, 14);
            this.textUnidad.Name = "textUnidad";
            this.textUnidad.Size = new System.Drawing.Size(164, 20);
            this.textUnidad.TabIndex = 63;
            this.toolTip1.SetToolTip(this.textUnidad, "Igrese la unidad");
            this.textUnidad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textUnidad_KeyPress);
            // 
            // cbCarrera
            // 
            this.cbCarrera.FormattingEnabled = true;
            this.cbCarrera.Items.AddRange(new object[] {
            "Analisis Sistemas ",
            "Contabilidad",
            "Mecanica Industrial",
            "Ingles",
            "Industria de Alimentos",
            "Redes y Telecomunicaciones"});
            this.cbCarrera.Location = new System.Drawing.Point(301, 62);
            this.cbCarrera.Name = "cbCarrera";
            this.cbCarrera.Size = new System.Drawing.Size(121, 21);
            this.cbCarrera.TabIndex = 64;
            this.cbCarrera.Text = "Carrera";
            this.toolTip1.SetToolTip(this.cbCarrera, "Seleccione una carrera");
            // 
            // textprofesor
            // 
            this.textprofesor.Location = new System.Drawing.Point(322, 192);
            this.textprofesor.Name = "textprofesor";
            this.textprofesor.Size = new System.Drawing.Size(100, 20);
            this.textprofesor.TabIndex = 65;
            this.toolTip1.SetToolTip(this.textprofesor, "Igrese el Profesor");
            this.textprofesor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textprofesor_KeyPress);
            // 
            // textdirecINt
            // 
            this.textdirecINt.Location = new System.Drawing.Point(322, 291);
            this.textdirecINt.Name = "textdirecINt";
            this.textdirecINt.Size = new System.Drawing.Size(100, 20);
            this.textdirecINt.TabIndex = 66;
            this.toolTip1.SetToolTip(this.textdirecINt, "Ingrese la direccion");
            this.textdirecINt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textdirecINt_KeyPress);
            // 
            // texttelfIns
            // 
            this.texttelfIns.Location = new System.Drawing.Point(322, 236);
            this.texttelfIns.Name = "texttelfIns";
            this.texttelfIns.Size = new System.Drawing.Size(100, 20);
            this.texttelfIns.TabIndex = 68;
            this.toolTip1.SetToolTip(this.texttelfIns, "Igrese el telefono");
            this.texttelfIns.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.texttelfIns_KeyPress);
            // 
            // groupmaterias
            // 
            this.groupmaterias.Controls.Add(this.chquimi);
            this.groupmaterias.Controls.Add(this.chkCal);
            this.groupmaterias.Controls.Add(this.chkmant);
            this.groupmaterias.Controls.Add(this.chkMeto);
            this.groupmaterias.Controls.Add(this.chkComuni);
            this.groupmaterias.Controls.Add(this.chkingle);
            this.groupmaterias.Controls.Add(this.chkFlui);
            this.groupmaterias.Controls.Add(this.chkDise);
            this.groupmaterias.Location = new System.Drawing.Point(448, 41);
            this.groupmaterias.Name = "groupmaterias";
            this.groupmaterias.Size = new System.Drawing.Size(467, 100);
            this.groupmaterias.TabIndex = 69;
            this.groupmaterias.TabStop = false;
            this.groupmaterias.Text = "Materias";
            this.toolTip1.SetToolTip(this.groupmaterias, "Seleccione unas Materias");
            // 
            // chquimi
            // 
            this.chquimi.AutoSize = true;
            this.chquimi.Location = new System.Drawing.Point(322, 64);
            this.chquimi.Name = "chquimi";
            this.chquimi.Size = new System.Drawing.Size(111, 17);
            this.chquimi.TabIndex = 7;
            this.chquimi.Text = "Quimica Aplicada ";
            this.chquimi.UseVisualStyleBackColor = true;
            // 
            // chkCal
            // 
            this.chkCal.AutoSize = true;
            this.chkCal.Location = new System.Drawing.Point(365, 19);
            this.chkCal.Name = "chkCal";
            this.chkCal.Size = new System.Drawing.Size(61, 17);
            this.chkCal.TabIndex = 6;
            this.chkCal.Text = "Calculo";
            this.chkCal.UseVisualStyleBackColor = true;
            // 
            // chkmant
            // 
            this.chkmant.AutoSize = true;
            this.chkmant.Location = new System.Drawing.Point(208, 64);
            this.chkmant.Name = "chkmant";
            this.chkmant.Size = new System.Drawing.Size(95, 17);
            this.chkmant.TabIndex = 5;
            this.chkmant.Text = "Mantenimiento";
            this.chkmant.UseVisualStyleBackColor = true;
            // 
            // chkMeto
            // 
            this.chkMeto.AutoSize = true;
            this.chkMeto.Location = new System.Drawing.Point(207, 19);
            this.chkMeto.Name = "chkMeto";
            this.chkMeto.Size = new System.Drawing.Size(152, 17);
            this.chkMeto.TabIndex = 4;
            this.chkMeto.Text = "Metodologia Programacion";
            this.chkMeto.UseVisualStyleBackColor = true;
            // 
            // chkComuni
            // 
            this.chkComuni.AutoSize = true;
            this.chkComuni.Location = new System.Drawing.Point(99, 64);
            this.chkComuni.Name = "chkComuni";
            this.chkComuni.Size = new System.Drawing.Size(93, 17);
            this.chkComuni.TabIndex = 3;
            this.chkComuni.Text = "Comunicacion";
            this.chkComuni.UseVisualStyleBackColor = true;
            // 
            // chkingle
            // 
            this.chkingle.AutoSize = true;
            this.chkingle.Location = new System.Drawing.Point(19, 64);
            this.chkingle.Name = "chkingle";
            this.chkingle.Size = new System.Drawing.Size(54, 17);
            this.chkingle.TabIndex = 2;
            this.chkingle.Text = "Ingles";
            this.chkingle.UseVisualStyleBackColor = true;
            // 
            // chkFlui
            // 
            this.chkFlui.AutoSize = true;
            this.chkFlui.Location = new System.Drawing.Point(121, 19);
            this.chkFlui.Name = "chkFlui";
            this.chkFlui.Size = new System.Drawing.Size(59, 17);
            this.chkFlui.TabIndex = 1;
            this.chkFlui.Text = "Fluidos";
            this.chkFlui.UseVisualStyleBackColor = true;
            // 
            // chkDise
            // 
            this.chkDise.AutoSize = true;
            this.chkDise.Location = new System.Drawing.Point(9, 19);
            this.chkDise.Name = "chkDise";
            this.chkDise.Size = new System.Drawing.Size(106, 17);
            this.chkDise.TabIndex = 0;
            this.chkDise.Text = "Diseño Multimedi";
            this.toolTip1.SetToolTip(this.chkDise, "Seleccione Unas Materias");
            this.chkDise.UseVisualStyleBackColor = true;
            // 
            // cobCurso
            // 
            this.cobCurso.FormattingEnabled = true;
            this.cobCurso.Items.AddRange(new object[] {
            "Primer Ciclo",
            "Segundo Ciclo",
            "Tercer Ciclo",
            "Cuarto Ciclo",
            "Quinto Ciclo",
            "Sexto Ciclo"});
            this.cobCurso.Location = new System.Drawing.Point(301, 122);
            this.cobCurso.Name = "cobCurso";
            this.cobCurso.Size = new System.Drawing.Size(121, 21);
            this.cobCurso.TabIndex = 70;
            this.cobCurso.Text = "Ciclo";
            this.toolTip1.SetToolTip(this.cobCurso, "Seleccione el curso");
            // 
            // textmailIst
            // 
            this.textmailIst.Location = new System.Drawing.Point(661, 15);
            this.textmailIst.Name = "textmailIst";
            this.textmailIst.Size = new System.Drawing.Size(146, 20);
            this.textmailIst.TabIndex = 71;
            this.toolTip1.SetToolTip(this.textmailIst, "Igrese el mail");
            this.textmailIst.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textmailIst_KeyPress);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbEstudisS);
            this.groupBox2.Controls.Add(this.rbquimica);
            this.groupBox2.Controls.Add(this.rbCienci);
            this.groupBox2.Controls.Add(this.rbfisica);
            this.groupBox2.Location = new System.Drawing.Point(741, 174);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 72;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Especialida";
            this.toolTip1.SetToolTip(this.groupBox2, "Seleccione Una especialidad");
            // 
            // rbEstudisS
            // 
            this.rbEstudisS.AutoSize = true;
            this.rbEstudisS.Location = new System.Drawing.Point(86, 19);
            this.rbEstudisS.Name = "rbEstudisS";
            this.rbEstudisS.Size = new System.Drawing.Size(108, 17);
            this.rbEstudisS.TabIndex = 3;
            this.rbEstudisS.TabStop = true;
            this.rbEstudisS.Text = "Estudios Sociales";
            this.rbEstudisS.UseVisualStyleBackColor = true;
            // 
            // rbquimica
            // 
            this.rbquimica.AutoSize = true;
            this.rbquimica.Location = new System.Drawing.Point(131, 62);
            this.rbquimica.Name = "rbquimica";
            this.rbquimica.Size = new System.Drawing.Size(63, 17);
            this.rbquimica.TabIndex = 2;
            this.rbquimica.TabStop = true;
            this.rbquimica.Text = "Quimica";
            this.rbquimica.UseVisualStyleBackColor = true;
            // 
            // rbCienci
            // 
            this.rbCienci.AutoSize = true;
            this.rbCienci.Location = new System.Drawing.Point(16, 62);
            this.rbCienci.Name = "rbCienci";
            this.rbCienci.Size = new System.Drawing.Size(105, 17);
            this.rbCienci.TabIndex = 1;
            this.rbCienci.TabStop = true;
            this.rbCienci.Text = "Ciencias Basicas";
            this.rbCienci.UseVisualStyleBackColor = true;
            // 
            // rbfisica
            // 
            this.rbfisica.AutoSize = true;
            this.rbfisica.Location = new System.Drawing.Point(16, 20);
            this.rbfisica.Name = "rbfisica";
            this.rbfisica.Size = new System.Drawing.Size(52, 17);
            this.rbfisica.TabIndex = 0;
            this.rbfisica.TabStop = true;
            this.rbfisica.Text = "Fisica";
            this.rbfisica.UseVisualStyleBackColor = true;
            // 
            // textfax
            // 
            this.textfax.Location = new System.Drawing.Point(542, 186);
            this.textfax.Name = "textfax";
            this.textfax.Size = new System.Drawing.Size(100, 20);
            this.textfax.TabIndex = 73;
            this.toolTip1.SetToolTip(this.textfax, "Ingrese el Fax");
            this.textfax.TextChanged += new System.EventHandler(this.textfax_TextChanged);
            this.textfax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textfax_KeyPress);
            // 
            // textProvincia
            // 
            this.textProvincia.Location = new System.Drawing.Point(542, 234);
            this.textProvincia.Name = "textProvincia";
            this.textProvincia.Size = new System.Drawing.Size(100, 20);
            this.textProvincia.TabIndex = 74;
            this.toolTip1.SetToolTip(this.textProvincia, "Ingrese la provincia");
            this.textProvincia.TextChanged += new System.EventHandler(this.textProvincia_TextChanged);
            this.textProvincia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textProvincia_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(464, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 16);
            this.label3.TabIndex = 75;
            this.label3.Text = "Fax";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(439, 236);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 16);
            this.label9.TabIndex = 76;
            this.label9.Text = "Provincia";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Agenda_Estudiantil.Properties.Resources._5;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(25, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 98);
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // butbuscar1
            // 
            this.butbuscar1.Location = new System.Drawing.Point(25, 138);
            this.butbuscar1.Name = "butbuscar1";
            this.butbuscar1.Size = new System.Drawing.Size(100, 23);
            this.butbuscar1.TabIndex = 77;
            this.butbuscar1.Text = "Buscar";
            this.butbuscar1.UseVisualStyleBackColor = true;
            this.butbuscar1.Click += new System.EventHandler(this.butbuscar1_Click);
            // 
            // Datos_Ins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1121, 371);
            this.Controls.Add(this.butbuscar1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textProvincia);
            this.Controls.Add(this.textfax);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.textmailIst);
            this.Controls.Add(this.cobCurso);
            this.Controls.Add(this.groupmaterias);
            this.Controls.Add(this.texttelfIns);
            this.Controls.Add(this.textdirecINt);
            this.Controls.Add(this.textprofesor);
            this.Controls.Add(this.cbCarrera);
            this.Controls.Add(this.textUnidad);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.butAnterior);
            this.Name = "Datos_Ins";
            this.Text = "Datos de la Institucion";
            this.Load += new System.EventHandler(this.Datos_Ins_Load);
            this.groupmaterias.ResumeLayout(false);
            this.groupmaterias.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        public System.Windows.Forms.TextBox textUnidad;
        public System.Windows.Forms.ComboBox cbCarrera;
        public System.Windows.Forms.TextBox textprofesor;
        public System.Windows.Forms.TextBox textdirecINt;
        public System.Windows.Forms.TextBox texttelfIns;
        public System.Windows.Forms.GroupBox groupmaterias;
        public System.Windows.Forms.CheckBox chquimi;
        public System.Windows.Forms.CheckBox chkCal;
        public System.Windows.Forms.CheckBox chkmant;
        public System.Windows.Forms.CheckBox chkMeto;
        public System.Windows.Forms.CheckBox chkComuni;
        public System.Windows.Forms.CheckBox chkingle;
        public System.Windows.Forms.CheckBox chkFlui;
        public System.Windows.Forms.CheckBox chkDise;
        public System.Windows.Forms.ComboBox cobCurso;
        public System.Windows.Forms.TextBox textmailIst;
        public System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.RadioButton rbEstudisS;
        public System.Windows.Forms.RadioButton rbquimica;
        public System.Windows.Forms.RadioButton rbCienci;
        public System.Windows.Forms.RadioButton rbfisica;
        public System.Windows.Forms.Button butAnterior;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox textfax;
        public System.Windows.Forms.TextBox textProvincia;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button butbuscar1;
    }
}