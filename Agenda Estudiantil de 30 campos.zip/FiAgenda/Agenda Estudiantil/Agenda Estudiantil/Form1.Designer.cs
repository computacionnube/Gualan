﻿namespace Agenda_Estudiantil
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.texttel = new System.Windows.Forms.TextBox();
            this.cBxnacionalida = new System.Windows.Forms.ComboBox();
            this.textced = new System.Windows.Forms.TextBox();
            this.textdirec = new System.Windows.Forms.TextBox();
            this.textapeli = new System.Windows.Forms.TextBox();
            this.textNombre = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textedad = new System.Windows.Forms.TextBox();
            this.textmail = new System.Windows.Forms.TextBox();
            this.textunidda = new System.Windows.Forms.TextBox();
            this.grBGenero = new System.Windows.Forms.GroupBox();
            this.checkF = new System.Windows.Forms.CheckBox();
            this.checkM = new System.Windows.Forms.CheckBox();
            this.grBTipo_sangre = new System.Windows.Forms.GroupBox();
            this.checAB2 = new System.Windows.Forms.CheckBox();
            this.checkORH2 = new System.Windows.Forms.CheckBox();
            this.checAB = new System.Windows.Forms.CheckBox();
            this.checORH = new System.Windows.Forms.CheckBox();
            this.butnew = new System.Windows.Forms.Button();
            this.butEliminar = new System.Windows.Forms.Button();
            this.butEdd = new System.Windows.Forms.Button();
            this.butAdd = new System.Windows.Forms.Button();
            this.dataRegistro = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Parroquia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cedula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Seg_Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Seg_Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sexo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado_Civil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ti_Sangre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Deporte = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Joby = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Materia_Favorita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textSegunNombre = new System.Windows.Forms.TextBox();
            this.textseguenAple = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.butsiguiente = new System.Windows.Forms.Button();
            this.butcerrar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unidad_Educativa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Especialidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Carrera = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ciclo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Profesor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel_Institucion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direc_Institucion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Materias = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Provincia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbxEstadoCi = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textmaterFav = new System.Windows.Forms.TextBox();
            this.textjoby = new System.Windows.Forms.TextBox();
            this.textdeporFavo = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.textedit = new System.Windows.Forms.TextBox();
            this.textdigito = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.butbuscar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grBGenero.SuspendLayout();
            this.grBTipo_sangre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataRegistro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(137, 344);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Telefono";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(135, 290);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Parroquia";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(132, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Cedula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(132, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Direccion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(132, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Apellidos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(132, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nombre";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.pictureBox1.BackgroundImage = global::Agenda_Estudiantil.Properties.Resources._5;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(21, 67);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 110);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Fotografia";
            // 
            // texttel
            // 
            this.texttel.Location = new System.Drawing.Point(214, 338);
            this.texttel.Name = "texttel";
            this.texttel.Size = new System.Drawing.Size(100, 20);
            this.texttel.TabIndex = 19;
            this.toolTip1.SetToolTip(this.texttel, "Igrese su telefono");
            this.texttel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.texttel_KeyPress);
            // 
            // cBxnacionalida
            // 
            this.cBxnacionalida.FormattingEnabled = true;
            this.cBxnacionalida.Items.AddRange(new object[] {
            "El Sagrario",
            "Sucre",
            "El Valle",
            "San Sebastián",
            "Punzara",
            "Carigán"});
            this.cBxnacionalida.Location = new System.Drawing.Point(234, 285);
            this.cBxnacionalida.Name = "cBxnacionalida";
            this.cBxnacionalida.Size = new System.Drawing.Size(121, 21);
            this.cBxnacionalida.TabIndex = 18;
            this.cBxnacionalida.Text = "Seleccione";
            this.toolTip1.SetToolTip(this.cBxnacionalida, "seleccione un campo");
            // 
            // textced
            // 
            this.textced.Location = new System.Drawing.Point(214, 235);
            this.textced.Name = "textced";
            this.textced.Size = new System.Drawing.Size(100, 20);
            this.textced.TabIndex = 17;
            this.toolTip1.SetToolTip(this.textced, "Igrese la cedula");
            this.textced.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textced_KeyPress);
            // 
            // textdirec
            // 
            this.textdirec.Location = new System.Drawing.Point(212, 196);
            this.textdirec.Name = "textdirec";
            this.textdirec.Size = new System.Drawing.Size(143, 20);
            this.textdirec.TabIndex = 16;
            this.toolTip1.SetToolTip(this.textdirec, "Igrese la direccion");
            this.textdirec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textdirec_KeyPress);
            // 
            // textapeli
            // 
            this.textapeli.Location = new System.Drawing.Point(212, 152);
            this.textapeli.Name = "textapeli";
            this.textapeli.Size = new System.Drawing.Size(143, 20);
            this.textapeli.TabIndex = 15;
            this.toolTip1.SetToolTip(this.textapeli, "Igrese el apellido");
            this.textapeli.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textapeli_KeyPress);
            // 
            // textNombre
            // 
            this.textNombre.Location = new System.Drawing.Point(212, 102);
            this.textNombre.Name = "textNombre";
            this.textNombre.Size = new System.Drawing.Size(143, 20);
            this.textNombre.TabIndex = 14;
            this.toolTip1.SetToolTip(this.textNombre, "Ingrese el Nombre");
            this.textNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNombre_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(381, 284);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 16);
            this.label12.TabIndex = 25;
            this.label12.Text = "Estado civil";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(387, 236);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 16);
            this.label11.TabIndex = 24;
            this.label11.Text = "Edad";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(387, 202);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 16);
            this.label8.TabIndex = 21;
            this.label8.Text = "Mail";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(359, 338);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(131, 16);
            this.label13.TabIndex = 20;
            this.label13.Text = "Unidad Educativa";
            // 
            // textedad
            // 
            this.textedad.Location = new System.Drawing.Point(494, 235);
            this.textedad.Name = "textedad";
            this.textedad.Size = new System.Drawing.Size(65, 20);
            this.textedad.TabIndex = 30;
            this.toolTip1.SetToolTip(this.textedad, "Igrese la edad");
            this.textedad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textedad_KeyPress);
            // 
            // textmail
            // 
            this.textmail.Location = new System.Drawing.Point(494, 195);
            this.textmail.Name = "textmail";
            this.textmail.Size = new System.Drawing.Size(188, 20);
            this.textmail.TabIndex = 29;
            this.toolTip1.SetToolTip(this.textmail, "Igrese el Mail");
            this.textmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textmail_KeyPress);
            // 
            // textunidda
            // 
            this.textunidda.Location = new System.Drawing.Point(496, 334);
            this.textunidda.Name = "textunidda";
            this.textunidda.Size = new System.Drawing.Size(225, 20);
            this.textunidda.TabIndex = 28;
            this.toolTip1.SetToolTip(this.textunidda, "Igrese la unidad educativa");
            this.textunidda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textunidda_KeyPress);
            // 
            // grBGenero
            // 
            this.grBGenero.Controls.Add(this.checkF);
            this.grBGenero.Controls.Add(this.checkM);
            this.grBGenero.Location = new System.Drawing.Point(754, 94);
            this.grBGenero.Name = "grBGenero";
            this.grBGenero.Size = new System.Drawing.Size(102, 83);
            this.grBGenero.TabIndex = 35;
            this.grBGenero.TabStop = false;
            this.grBGenero.Text = "Genero";
            this.toolTip1.SetToolTip(this.grBGenero, "Seleccione el Genero");
            // 
            // checkF
            // 
            this.checkF.AutoSize = true;
            this.checkF.Checked = true;
            this.checkF.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkF.Location = new System.Drawing.Point(11, 51);
            this.checkF.Name = "checkF";
            this.checkF.Size = new System.Drawing.Size(32, 17);
            this.checkF.TabIndex = 1;
            this.checkF.Text = "F";
            this.checkF.UseVisualStyleBackColor = true;
            // 
            // checkM
            // 
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkM.Location = new System.Drawing.Point(11, 26);
            this.checkM.Name = "checkM";
            this.checkM.Size = new System.Drawing.Size(35, 17);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.checkM.UseVisualStyleBackColor = true;
            // 
            // grBTipo_sangre
            // 
            this.grBTipo_sangre.Controls.Add(this.checAB2);
            this.grBTipo_sangre.Controls.Add(this.checkORH2);
            this.grBTipo_sangre.Controls.Add(this.checAB);
            this.grBTipo_sangre.Controls.Add(this.checORH);
            this.grBTipo_sangre.Location = new System.Drawing.Point(754, 211);
            this.grBTipo_sangre.Name = "grBTipo_sangre";
            this.grBTipo_sangre.Size = new System.Drawing.Size(140, 88);
            this.grBTipo_sangre.TabIndex = 34;
            this.grBTipo_sangre.TabStop = false;
            this.grBTipo_sangre.Text = "Tipo Sangre";
            this.toolTip1.SetToolTip(this.grBTipo_sangre, "Seleccione el tipo de Sangre");
            // 
            // checAB2
            // 
            this.checAB2.AutoSize = true;
            this.checAB2.Location = new System.Drawing.Point(82, 66);
            this.checAB2.Name = "checAB2";
            this.checAB2.Size = new System.Drawing.Size(43, 17);
            this.checAB2.TabIndex = 3;
            this.checAB2.Text = "AB-";
            this.checAB2.UseVisualStyleBackColor = true;
            // 
            // checkORH2
            // 
            this.checkORH2.AutoSize = true;
            this.checkORH2.Location = new System.Drawing.Point(82, 24);
            this.checkORH2.Name = "checkORH2";
            this.checkORH2.Size = new System.Drawing.Size(53, 17);
            this.checkORH2.TabIndex = 2;
            this.checkORH2.Text = "ORH-";
            this.checkORH2.UseVisualStyleBackColor = true;
            // 
            // checAB
            // 
            this.checAB.AutoSize = true;
            this.checAB.Location = new System.Drawing.Point(20, 66);
            this.checAB.Name = "checAB";
            this.checAB.Size = new System.Drawing.Size(46, 17);
            this.checAB.TabIndex = 1;
            this.checAB.Text = "AB+";
            this.checAB.UseVisualStyleBackColor = true;
            // 
            // checORH
            // 
            this.checORH.AutoSize = true;
            this.checORH.Location = new System.Drawing.Point(20, 24);
            this.checORH.Name = "checORH";
            this.checORH.Size = new System.Drawing.Size(56, 17);
            this.checORH.TabIndex = 0;
            this.checORH.Text = "ORH+";
            this.checORH.UseVisualStyleBackColor = true;
            // 
            // butnew
            // 
            this.butnew.Location = new System.Drawing.Point(1190, 168);
            this.butnew.Name = "butnew";
            this.butnew.Size = new System.Drawing.Size(56, 23);
            this.butnew.TabIndex = 39;
            this.butnew.Text = "Nuevo";
            this.butnew.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butnew, "Nuevo campos");
            this.butnew.UseVisualStyleBackColor = true;
            this.butnew.Click += new System.EventHandler(this.butnew_Click);
            // 
            // butEliminar
            // 
            this.butEliminar.Location = new System.Drawing.Point(1190, 134);
            this.butEliminar.Name = "butEliminar";
            this.butEliminar.Size = new System.Drawing.Size(56, 23);
            this.butEliminar.TabIndex = 38;
            this.butEliminar.Text = "Eliminar";
            this.butEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butEliminar, "Elimina los campos");
            this.butEliminar.UseVisualStyleBackColor = true;
            this.butEliminar.Click += new System.EventHandler(this.butEliminar_Click);
            // 
            // butEdd
            // 
            this.butEdd.Location = new System.Drawing.Point(1190, 101);
            this.butEdd.Name = "butEdd";
            this.butEdd.Size = new System.Drawing.Size(56, 23);
            this.butEdd.TabIndex = 37;
            this.butEdd.Text = "Editar";
            this.butEdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butEdd, "Edita los campos");
            this.butEdd.UseVisualStyleBackColor = true;
            this.butEdd.Click += new System.EventHandler(this.butEdd_Click);
            // 
            // butAdd
            // 
            this.butAdd.Location = new System.Drawing.Point(1190, 72);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(56, 23);
            this.butAdd.TabIndex = 36;
            this.butAdd.Text = "Agregar";
            this.butAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butAdd, "Agrega los campos");
            this.butAdd.UseVisualStyleBackColor = true;
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // dataRegistro
            // 
            this.dataRegistro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataRegistro.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Parroquia,
            this.Cedula,
            this.Nombre,
            this.Seg_Nombre,
            this.Apellido,
            this.Seg_Apellido,
            this.Telefono,
            this.Direccion,
            this.Mail,
            this.Sexo,
            this.Edad,
            this.Estado_Civil,
            this.Ti_Sangre,
            this.Unidad,
            this.Deporte,
            this.Joby,
            this.Materia_Favorita});
            this.dataRegistro.Location = new System.Drawing.Point(12, 437);
            this.dataRegistro.Name = "dataRegistro";
            this.dataRegistro.Size = new System.Drawing.Size(1302, 150);
            this.dataRegistro.TabIndex = 40;
            this.dataRegistro.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataRegistro_CellClick);
            // 
            // Column1
            // 
            this.Column1.FillWeight = 30F;
            this.Column1.HeaderText = "#";
            this.Column1.Name = "Column1";
            this.Column1.Width = 30;
            // 
            // Parroquia
            // 
            this.Parroquia.HeaderText = "Parroquia";
            this.Parroquia.Name = "Parroquia";
            // 
            // Cedula
            // 
            this.Cedula.HeaderText = "Cedula";
            this.Cedula.Name = "Cedula";
            // 
            // Nombre
            // 
            this.Nombre.FillWeight = 140F;
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.Width = 140;
            // 
            // Seg_Nombre
            // 
            this.Seg_Nombre.HeaderText = "Seg_Nombre";
            this.Seg_Nombre.Name = "Seg_Nombre";
            this.Seg_Nombre.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Apellido
            // 
            this.Apellido.FillWeight = 140F;
            this.Apellido.HeaderText = "Apellido";
            this.Apellido.Name = "Apellido";
            this.Apellido.Width = 140;
            // 
            // Seg_Apellido
            // 
            this.Seg_Apellido.HeaderText = "Seg_Apellido";
            this.Seg_Apellido.Name = "Seg_Apellido";
            // 
            // Telefono
            // 
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.Name = "Telefono";
            // 
            // Direccion
            // 
            this.Direccion.FillWeight = 140F;
            this.Direccion.HeaderText = "Direccion";
            this.Direccion.Name = "Direccion";
            this.Direccion.Width = 140;
            // 
            // Mail
            // 
            this.Mail.FillWeight = 140F;
            this.Mail.HeaderText = "Mail";
            this.Mail.Name = "Mail";
            this.Mail.Width = 140;
            // 
            // Sexo
            // 
            this.Sexo.HeaderText = "Sexo";
            this.Sexo.Name = "Sexo";
            // 
            // Edad
            // 
            this.Edad.FillWeight = 60F;
            this.Edad.HeaderText = "Edad";
            this.Edad.Name = "Edad";
            this.Edad.Width = 60;
            // 
            // Estado_Civil
            // 
            this.Estado_Civil.HeaderText = "Estado_Civil";
            this.Estado_Civil.Name = "Estado_Civil";
            // 
            // Ti_Sangre
            // 
            this.Ti_Sangre.HeaderText = "Tipo_Sangre";
            this.Ti_Sangre.Name = "Ti_Sangre";
            // 
            // Unidad
            // 
            this.Unidad.HeaderText = "Unidad Educativa";
            this.Unidad.Name = "Unidad";
            // 
            // Deporte
            // 
            this.Deporte.HeaderText = "Deporte";
            this.Deporte.Name = "Deporte";
            // 
            // Joby
            // 
            this.Joby.HeaderText = "Joby";
            this.Joby.Name = "Joby";
            // 
            // Materia_Favorita
            // 
            this.Materia_Favorita.HeaderText = "Materia_Favorita";
            this.Materia_Favorita.Name = "Materia_Favorita";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(387, 103);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 16);
            this.label14.TabIndex = 41;
            this.label14.Text = "2 Nombre";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(387, 152);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 16);
            this.label15.TabIndex = 42;
            this.label15.Text = "2 Apellido";
            // 
            // textSegunNombre
            // 
            this.textSegunNombre.Location = new System.Drawing.Point(494, 105);
            this.textSegunNombre.Name = "textSegunNombre";
            this.textSegunNombre.Size = new System.Drawing.Size(157, 20);
            this.textSegunNombre.TabIndex = 43;
            this.toolTip1.SetToolTip(this.textSegunNombre, "Igrese el Segundo Nombre");
            this.textSegunNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textSegunNombre_KeyPress);
            // 
            // textseguenAple
            // 
            this.textseguenAple.Location = new System.Drawing.Point(494, 152);
            this.textseguenAple.Name = "textseguenAple";
            this.textseguenAple.Size = new System.Drawing.Size(157, 20);
            this.textseguenAple.TabIndex = 44;
            this.toolTip1.SetToolTip(this.textseguenAple, "Igrese el Segundo Apellido");
            this.textseguenAple.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textseguenAple_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1187, 215);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 13);
            this.label9.TabIndex = 45;
            this.label9.Text = "--------------------------------------------";
            // 
            // butsiguiente
            // 
            this.butsiguiente.Location = new System.Drawing.Point(1190, 231);
            this.butsiguiente.Name = "butsiguiente";
            this.butsiguiente.Size = new System.Drawing.Size(75, 23);
            this.butsiguiente.TabIndex = 46;
            this.butsiguiente.Text = "Next";
            this.butsiguiente.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butsiguiente, "Siguiente formulario");
            this.butsiguiente.UseVisualStyleBackColor = true;
            this.butsiguiente.Click += new System.EventHandler(this.butsiguiente_Click);
            // 
            // butcerrar
            // 
            this.butcerrar.Location = new System.Drawing.Point(1190, 270);
            this.butcerrar.Name = "butcerrar";
            this.butcerrar.Size = new System.Drawing.Size(75, 23);
            this.butcerrar.TabIndex = 48;
            this.butcerrar.Text = "Salir";
            this.butcerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butcerrar, "Sale de la aplicacion");
            this.butcerrar.UseVisualStyleBackColor = true;
            this.butcerrar.Click += new System.EventHandler(this.butcerrar_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Unidad_Educativa,
            this.Especialidad,
            this.Carrera,
            this.Ciclo,
            this.Profesor,
            this.Tel_Institucion,
            this.Direc_Institucion,
            this.dataGridViewTextBoxColumn2,
            this.Materias,
            this.Fax,
            this.Provincia});
            this.dataGridView1.Location = new System.Drawing.Point(12, 647);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1302, 142);
            this.dataGridView1.TabIndex = 74;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 50F;
            this.dataGridViewTextBoxColumn1.HeaderText = "#";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // Unidad_Educativa
            // 
            this.Unidad_Educativa.FillWeight = 150F;
            this.Unidad_Educativa.HeaderText = "Unidad_Educativa";
            this.Unidad_Educativa.Name = "Unidad_Educativa";
            this.Unidad_Educativa.Width = 150;
            // 
            // Especialidad
            // 
            this.Especialidad.FillWeight = 120F;
            this.Especialidad.HeaderText = "Especialidad";
            this.Especialidad.Name = "Especialidad";
            this.Especialidad.Width = 120;
            // 
            // Carrera
            // 
            this.Carrera.HeaderText = "Carrera";
            this.Carrera.Name = "Carrera";
            // 
            // Ciclo
            // 
            this.Ciclo.HeaderText = "Ciclo";
            this.Ciclo.Name = "Ciclo";
            // 
            // Profesor
            // 
            this.Profesor.HeaderText = "Profesor";
            this.Profesor.Name = "Profesor";
            // 
            // Tel_Institucion
            // 
            this.Tel_Institucion.HeaderText = "Tel_Institucion";
            this.Tel_Institucion.Name = "Tel_Institucion";
            // 
            // Direc_Institucion
            // 
            this.Direc_Institucion.HeaderText = "Direc_Institucion";
            this.Direc_Institucion.Name = "Direc_Institucion";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 140F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Mail";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 140;
            // 
            // Materias
            // 
            this.Materias.FillWeight = 200F;
            this.Materias.HeaderText = "Materias";
            this.Materias.Name = "Materias";
            this.Materias.Width = 300;
            // 
            // Fax
            // 
            this.Fax.HeaderText = "Fax";
            this.Fax.Name = "Fax";
            // 
            // Provincia
            // 
            this.Provincia.HeaderText = "Provincia";
            this.Provincia.Name = "Provincia";
            // 
            // cbxEstadoCi
            // 
            this.cbxEstadoCi.FormattingEnabled = true;
            this.cbxEstadoCi.Items.AddRange(new object[] {
            "Soltero",
            "Viudo",
            "Casado"});
            this.cbxEstadoCi.Location = new System.Drawing.Point(494, 281);
            this.cbxEstadoCi.Name = "cbxEstadoCi";
            this.cbxEstadoCi.Size = new System.Drawing.Size(121, 21);
            this.cbxEstadoCi.TabIndex = 75;
            this.cbxEstadoCi.Text = "Estado Civil";
            this.toolTip1.SetToolTip(this.cbxEstadoCi, "Seleccione un campo");
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(894, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 16);
            this.label10.TabIndex = 78;
            this.label10.Text = "Materia Prferida";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(894, 145);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 16);
            this.label16.TabIndex = 79;
            this.label16.Text = "Joby";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(897, 183);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(125, 16);
            this.label17.TabIndex = 80;
            this.label17.Text = "Deporte Favorito";
            // 
            // textmaterFav
            // 
            this.textmaterFav.Location = new System.Drawing.Point(1042, 101);
            this.textmaterFav.Name = "textmaterFav";
            this.textmaterFav.Size = new System.Drawing.Size(100, 20);
            this.textmaterFav.TabIndex = 81;
            this.toolTip1.SetToolTip(this.textmaterFav, "Igrese su materia");
            this.textmaterFav.TextChanged += new System.EventHandler(this.textmaterFav_TextChanged);
            this.textmaterFav.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textmaterFav_KeyPress);
            // 
            // textjoby
            // 
            this.textjoby.Location = new System.Drawing.Point(1042, 136);
            this.textjoby.Name = "textjoby";
            this.textjoby.Size = new System.Drawing.Size(100, 20);
            this.textjoby.TabIndex = 82;
            this.toolTip1.SetToolTip(this.textjoby, "Igrese su joby");
            this.textjoby.TextChanged += new System.EventHandler(this.textjoby_TextChanged);
            this.textjoby.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textjoby_KeyPress);
            // 
            // textdeporFavo
            // 
            this.textdeporFavo.Location = new System.Drawing.Point(1042, 179);
            this.textdeporFavo.Name = "textdeporFavo";
            this.textdeporFavo.Size = new System.Drawing.Size(100, 20);
            this.textdeporFavo.TabIndex = 83;
            this.toolTip1.SetToolTip(this.textdeporFavo, "Igrese su deporte");
            this.textdeporFavo.TextChanged += new System.EventHandler(this.textdeporFavo_TextChanged);
            this.textdeporFavo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textdeporFavo_KeyPress);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1327, 25);
            this.toolStrip1.TabIndex = 84;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // textedit
            // 
            this.textedit.Location = new System.Drawing.Point(853, 334);
            this.textedit.Name = "textedit";
            this.textedit.Size = new System.Drawing.Size(100, 20);
            this.textedit.TabIndex = 76;
            // 
            // textdigito
            // 
            this.textdigito.Location = new System.Drawing.Point(732, 334);
            this.textdigito.Name = "textdigito";
            this.textdigito.Size = new System.Drawing.Size(100, 20);
            this.textdigito.TabIndex = 77;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(436, 403);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(191, 24);
            this.label18.TabIndex = 85;
            this.label18.Text = "Registro Estudiante";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(436, 611);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(203, 24);
            this.label19.TabIndex = 86;
            this.label19.Text = "Registro Institucional";
            // 
            // butbuscar
            // 
            this.butbuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butbuscar.Location = new System.Drawing.Point(21, 183);
            this.butbuscar.Name = "butbuscar";
            this.butbuscar.Size = new System.Drawing.Size(100, 20);
            this.butbuscar.TabIndex = 87;
            this.butbuscar.Text = "Buscar";
            this.butbuscar.UseVisualStyleBackColor = true;
            this.butbuscar.Click += new System.EventHandler(this.butbuscar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1327, 717);
            this.Controls.Add(this.butbuscar);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.textdeporFavo);
            this.Controls.Add(this.textjoby);
            this.Controls.Add(this.textmaterFav);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textdigito);
            this.Controls.Add(this.textedit);
            this.Controls.Add(this.cbxEstadoCi);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.butcerrar);
            this.Controls.Add(this.butsiguiente);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textseguenAple);
            this.Controls.Add(this.textSegunNombre);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dataRegistro);
            this.Controls.Add(this.butnew);
            this.Controls.Add(this.butEliminar);
            this.Controls.Add(this.butEdd);
            this.Controls.Add(this.butAdd);
            this.Controls.Add(this.grBGenero);
            this.Controls.Add(this.grBTipo_sangre);
            this.Controls.Add(this.textedad);
            this.Controls.Add(this.textmail);
            this.Controls.Add(this.textunidda);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.texttel);
            this.Controls.Add(this.cBxnacionalida);
            this.Controls.Add(this.textced);
            this.Controls.Add(this.textdirec);
            this.Controls.Add(this.textapeli);
            this.Controls.Add(this.textNombre);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Datos Personales ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grBGenero.ResumeLayout(false);
            this.grBGenero.PerformLayout();
            this.grBTipo_sangre.ResumeLayout(false);
            this.grBTipo_sangre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataRegistro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox grBGenero;
        private System.Windows.Forms.Button butnew;
        private System.Windows.Forms.Button butEliminar;
        private System.Windows.Forms.Button butEdd;
        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button butcerrar;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.TextBox texttel;
        public System.Windows.Forms.ComboBox cBxnacionalida;
        public System.Windows.Forms.TextBox textced;
        public System.Windows.Forms.TextBox textdirec;
        public System.Windows.Forms.TextBox textapeli;
        public System.Windows.Forms.TextBox textNombre;
        public System.Windows.Forms.TextBox textedad;
        public System.Windows.Forms.TextBox textmail;
        public System.Windows.Forms.TextBox textunidda;
        public System.Windows.Forms.CheckBox checkF;
        public System.Windows.Forms.CheckBox checkM;
        public System.Windows.Forms.GroupBox grBTipo_sangre;
        public System.Windows.Forms.CheckBox checAB2;
        public System.Windows.Forms.CheckBox checkORH2;
        public System.Windows.Forms.CheckBox checAB;
        public System.Windows.Forms.CheckBox checORH;
        public System.Windows.Forms.DataGridView dataRegistro;
        public System.Windows.Forms.TextBox textSegunNombre;
        public System.Windows.Forms.TextBox textseguenAple;
        public System.Windows.Forms.Button butsiguiente;
        public System.Windows.Forms.ComboBox cbxEstadoCi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textmaterFav;
        private System.Windows.Forms.TextBox textjoby;
        private System.Windows.Forms.TextBox textdeporFavo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unidad_Educativa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Especialidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Carrera;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ciclo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Profesor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel_Institucion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direc_Institucion;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Materias;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn Provincia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parroquia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cedula;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seg_Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seg_Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sexo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Edad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado_Civil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ti_Sangre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Deporte;
        private System.Windows.Forms.DataGridViewTextBoxColumn Joby;
        private System.Windows.Forms.DataGridViewTextBoxColumn Materia_Favorita;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.TextBox textedit;
        private System.Windows.Forms.TextBox textdigito;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button butbuscar;
    }
}

