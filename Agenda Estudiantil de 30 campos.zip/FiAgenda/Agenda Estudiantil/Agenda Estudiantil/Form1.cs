﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_Estudiantil
{
    public partial class Form1 : Form
    {
        Datos_Ins datos = new Datos_Ins();
        public Form1()
        {
            InitializeComponent();
            Limpiar();
        }
        public int pos;
       public int i=1;
       int Z;
       public string genero;
        public string Tipo_sangre;
        String mate;
        private void Limpiar()
        {
            textNombre.Text = "";
            textSegunNombre.Text = "";
            textapeli.Text = "";
            textseguenAple.Text = "";
            textdirec.Text = "";
            textedad.Text = "";
            textmail.Text = "";
            texttel.Text = "";
            textunidda.Text = "";
            cBxnacionalida.Text = "";
            textmaterFav.Text = "";
            textdeporFavo.Text = "";
            textjoby.Text = "";
            textdigito.Text = "";
            textedit.Text = "";
            datos.textUnidad.Text = "";
            datos.textprofesor.Text="";
            datos.texttelfIns.Text = "";
            datos.textmailIst.Text = "";
            datos.textdirecINt.Text = "";
            datos.textfax.Text = "";
            datos.textProvincia.Text = "";

            if (checkM.Checked ==true)
            {
                genero += "";

            }
            else
            {
                if (checkF.Checked ==true)
                {
                    genero += "";
                    
                }
            }
          

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void butAdd_Click(object sender, EventArgs e)
        {
            
            genero = "";
            Tipo_sangre = "";
            string cedula, apellido, nombre, apellido2, nombre2, telefono, unidadeducativa, edad, mail, direccion,deporte,materF,joby;
            cedula = textced.Text;
            apellido = textapeli.Text;
            nombre = textNombre.Text;
            apellido2 = textseguenAple.Text;
            nombre2 = textSegunNombre.Text;
            telefono = texttel.Text;
            unidadeducativa = textunidda.Text;
            edad = textedad.Text;
            mail = textmail.Text;
            direccion = textdirec.Text;
            deporte = textdeporFavo.Text;
            joby = textjoby.Text;
            materF = textmaterFav.Text;
            if (checkM.Checked==true)
            {
                genero += checkM.Text;

            }
            else
            {
                if (checkF.Checked==true)
                {
                    genero += checkF.Text;
                    
                }
            }
            //
            if (checkORH2.Checked==true)
            {
                Tipo_sangre += checkORH2.Text;
            }
            else
            {
                if (checORH.Checked==true)
                {
                    Tipo_sangre += checORH.Text;
                }
                else
                {
                    if (checAB.Checked==true)
                    {
                        Tipo_sangre += checAB.Text;
                    }
                    else
                    {
                        if (checAB2.Checked==true)
                        {
                            Tipo_sangre += checAB2.Text;
                        }
                    }
                      
                }
            }

            dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, nombre2, apellido, apellido2, telefono, direccion, mail, genero, edad,cbxEstadoCi.Text, Tipo_sangre,unidadeducativa,deporte,joby,materF);
            i++;

            datos.espe = "";
            datos.unidaE = datos.textUnidad.Text;
            datos.profesor = datos.textprofesor.Text;
            datos.tetinst = datos.texttelfIns.Text;
            datos.direccioin = datos.textdirecINt.Text;
            datos.mailints = datos.textmailIst.Text;
            if (datos.rbfisica.Checked == true)
            {
                datos.espe += datos.rbfisica.Text;

            }
            if (datos.rbCienci.Checked == true)
            {
                datos.espe += datos.rbCienci.Text;
            }
            if (datos.rbEstudisS.Checked == true)
            {
                datos.espe += datos.rbEstudisS.Text;
            }
            if (datos.rbquimica.Checked == true)
            {
                datos.espe += datos.rbquimica.Text;
            }
            mate = "";
            if (datos.chkCal.Checked == true)
            {
                mate += datos.chkCal.Text + "," ;
               
            }
            if (datos.chkComuni.Checked == true)
            {
                mate += datos.chkComuni.Text+",";
                
            }
            if (datos.chkDise.Checked == true)
            {
                mate += datos.chkDise.Text+",";
                
            }
            if (datos.chkFlui.Checked == true)
            {
                mate += datos.chkFlui.Text + ",";
               
            }
            if (datos.chkingle.Checked == true)
            {
                mate += datos.chkingle.Text + ",";
                
            }
            if (datos.chkmant.Checked == true)
            {
                mate += datos.chkmant.Text + ",";
                
            }
            if (datos.chkMeto.Checked == true)
            {
                mate += datos.chkMeto.Text + ",";
                
            }
            if (datos.chquimi.Checked == true)
            {
                mate += datos.chquimi.Text;
                
            }
            datos.fax = datos.textfax.Text;
            datos.provincia = datos.textProvincia.Text;

            dataGridView1.Rows.Add(datos.j, datos.unidaE, datos.espe, datos.cbCarrera.Text, datos.cobCurso.Text, datos.profesor, datos.tetinst, datos.direccioin, datos.mailints,mate,datos.fax,datos.provincia);
            datos.j++;
            if (textNombre.Text=="")
            {
                MessageBox.Show("Campo del nombre obligatorio");
                dataRegistro.Rows.RemoveAt(pos);
                dataGridView1.Rows.RemoveAt(Z);
                textNombre.Focus();

            }
            if (textced.Text == "")
            {
                MessageBox.Show("Campo del cedula es obligatorio");
                textced.Focus();
                dataRegistro.Rows.RemoveAt(pos);
                dataGridView1.Rows.RemoveAt(Z);
                datos.j = 1;
                i = 1;
                datos.Visible = false;

            }
            Cedula_1();

        }

        private void butsiguiente_Click(object sender, EventArgs e)
        {
           
            if (textNombre.Text == "")
            {
                datos.Visible = false;
                MessageBox.Show("Campo del nombre obligatorio");
                textNombre.Focus();
                

            }
            else
            {
                datos.Visible = true; 
            }

            if (textced.Text=="")
            {
                MessageBox.Show("Campo del cedula es obligatorio");
                textced.Focus();
                datos.Visible = false;
                
            }
            else
            {
                datos.Visible = true;
            }

        }

        private void butEdd_Click(object sender, EventArgs e)
        {
        
            
            dataRegistro[1, pos].Value = cBxnacionalida.Text;
            dataRegistro[2, pos].Value = textced.Text;
            dataRegistro[3, pos].Value = textNombre.Text;
            dataRegistro[4, pos].Value = textSegunNombre.Text;
            dataRegistro[5, pos].Value = textapeli.Text;
            dataRegistro[6, pos].Value = textseguenAple.Text;
            dataRegistro[7, pos].Value = texttel.Text;
            dataRegistro[8, pos].Value = textdirec.Text;
            dataRegistro[9, pos].Value = textmail.Text;
            if (checkF.CheckState == CheckState.Checked)
            {
                dataRegistro[10, pos].Value = checkF.Text;
            }
            if (checkM.CheckState == CheckState.Checked)
            {
                dataRegistro[10, pos].Value = checkM.Text;
            }
            dataRegistro[11, pos].Value = textedad.Text;
            dataRegistro[12, pos].Value = cbxEstadoCi.Text;
            if (checkORH2.Checked == true)
            {
                dataRegistro[13, pos].Value = checkORH2.Text;
            }
            else
            {
                if (checORH.Checked == true)
                {
                    dataRegistro[13, pos].Value = checORH.Text;
                }
                else
                {
                    if (checAB.Checked == true)
                    {
                        dataRegistro[13, pos].Value = checAB.Text;
                    }
                    else
                    {
                        if (checAB2.Checked == true)
                        {
                            dataRegistro[13, pos].Value = checAB2.Text;
                        }
                    }

                }
            }
           
           
            dataRegistro[14, pos].Value = textunidda.Text;
            dataRegistro[15, pos].Value = textdeporFavo.Text;
            dataRegistro[16, pos].Value = textjoby.Text;
            dataRegistro[17, pos].Value = textmaterFav.Text;

            if (datos.butAnterior.Enabled==true)
            {
                datos.ShowDialog();
                dataGridView1[1, Z].Value = datos.textUnidad.Text;
                if (datos.rbfisica.Checked == true)
                {
                    dataGridView1[2, Z].Value = datos.rbfisica.Text;

                }
                if (datos.rbCienci.Checked == true)
                {
                    dataGridView1[2, Z].Value = datos.rbCienci.Text;
                }
                if (datos.rbEstudisS.Checked == true)
                {
                    dataGridView1[2, Z].Value = datos.rbEstudisS.Text; 
                }
                if (datos.rbquimica.Checked == true)
                {
                    dataGridView1[2, Z].Value = datos.rbquimica.Text;
                }
                dataGridView1[3, Z].Value = datos.cbCarrera.Text;
                dataGridView1[4, Z].Value = datos.cobCurso.Text;
                dataGridView1[5, Z].Value = datos.textprofesor.Text;
                dataGridView1[6, Z].Value = datos.texttelfIns.Text;
                dataGridView1[7, Z].Value = datos.textdirecINt.Text;
                dataGridView1[8, Z].Value = datos.textmailIst.Text;
                
                if (datos.chkCal.CheckState==CheckState.Checked)
                {
                    mate += datos.chkCal.Text;
                    dataGridView1[9, Z].Value = mate;
                }

                if (datos.chkComuni.CheckState == CheckState.Checked)
                {
                    mate += datos.chkComuni.Text;
                    dataGridView1[9, Z].Value = mate;
                }
                if (datos.chkDise.CheckState == CheckState.Checked)
                {
                    mate += datos.chkDise.Text;
                    dataGridView1[9, Z].Value = mate;
                }
                if (datos.chkFlui.CheckState == CheckState.Checked)
                {
                    mate += datos.chkFlui.Text;
                    dataGridView1[9, Z].Value = mate;
                }
                if (datos.chkingle.CheckState == CheckState.Checked)
                {
                    mate += datos.chkingle.Text;
                    dataGridView1[9, Z].Value = mate;
                }
                if (datos.chkmant.CheckState == CheckState.Checked)
                {
                    mate += datos.chkmant.Text;
                    dataGridView1[9, Z].Value = mate;
                }
                if (datos.chkMeto.CheckState == CheckState.Checked)
                {
                    mate += datos.chkMeto.Text;
                    dataGridView1[9, Z].Value = mate;
                }
                if (datos.chquimi.CheckState == CheckState.Checked)
                {
                    mate += datos.chquimi.Text;
                    dataGridView1[9, Z].Value = mate;
                }

             
            }
            dataGridView1[10, Z].Value = datos.textfax.Text;
            dataGridView1[11, Z].Value = datos.textProvincia.Text;
            
        }

        private void dataRegistro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos = dataRegistro.CurrentRow.Index;
            cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            textced.Text = dataRegistro[2, pos].Value.ToString();
            textNombre.Text = dataRegistro[3, pos].Value.ToString();
            textSegunNombre.Text = dataRegistro[4, pos].Value.ToString();
            textapeli.Text = dataRegistro[5, pos].Value.ToString();
            textseguenAple.Text = dataRegistro[6, pos].Value.ToString();
            texttel.Text = dataRegistro[7, pos].Value.ToString();
            textdirec.Text = dataRegistro[8, pos].Value.ToString();
            textmail.Text = dataRegistro[9, pos].Value.ToString();
            if (checkM.Checked == true)
            {
                checkM.Text = dataRegistro[10, pos].Value.ToString();

            }
            else
            {
                if (checkF.Checked == true)
                {
                    checkF.Text = dataRegistro[10, pos].Value.ToString();
                }
            }

            textedad.Text = dataRegistro[11, pos].Value.ToString();
            cbxEstadoCi.Text = dataRegistro[12, pos].Value.ToString();
            if (checkORH2.Checked == true)
            {
                checkORH2.Text = dataRegistro[13, pos].Value.ToString();
            }
            else
            {
                if (checORH.Checked == true)
                {
                    checORH.Text = dataRegistro[13, pos].Value.ToString();
                }
                else
                {
                    if (checAB.Checked == true)
                    {
                        checAB.Text = dataRegistro[13, pos].Value.ToString();
                    }
                    else
                    {
                        if (checAB2.Checked == true)
                        {
                            checAB2.Text = dataRegistro[13, pos].Value.ToString();
                        }
                    }

                }
            }
           
            textunidda.Text = dataRegistro[14, pos].Value.ToString();
            textdeporFavo.Text = dataRegistro[15, pos].Value.ToString();
            textjoby.Text = dataRegistro[16, pos].Value.ToString();
            textmaterFav.Text = dataRegistro[17, pos].Value.ToString();
           
        }

        private void butEliminar_Click(object sender, EventArgs e)
        {
            if (butEdd.Enabled==true)
            {
                dataRegistro.Rows.RemoveAt(pos);
                dataGridView1.Rows.RemoveAt(Z);
            }
            

        }

        private void butnew_Click(object sender, EventArgs e)
        {
            Limpiar();
            cBxnacionalida.Text = "";
            cbxEstadoCi.Text = "";
            datos.cbCarrera.Text = "";
            datos.cobCurso.Text = "";
            
        }

       

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
             // b.dataGridView1.Rows.Add(j, unidaE, espe, cbCarrera.Text, cobCurso.Text, profesor, tetinst, direccioin, mailints);
            Z = dataGridView1.CurrentRow.Index;
            datos.textUnidad.Text = dataGridView1[1, Z].Value.ToString();
           
            if (datos.rbfisica.Checked == true)
            {
                datos.rbfisica.Text = dataGridView1[2, Z].Value.ToString();

            }
            if (datos.rbCienci.Checked == true)
            {
               datos.rbCienci.Text = dataGridView1[2, Z].Value.ToString();
            }
            if (datos.rbEstudisS.Checked == true)
            {
                datos.rbEstudisS.Text = dataGridView1[2, Z].Value.ToString();
            }
            if (datos.rbquimica.Checked == true)
            {
                datos.rbquimica.Text = dataGridView1[2, Z].Value.ToString();
            }
            datos.cbCarrera.Text = dataGridView1[3, Z].Value.ToString();
            datos.cobCurso.Text = dataGridView1[4, Z].Value.ToString();
            datos.textprofesor.Text = dataGridView1[5, Z].Value.ToString();
            datos.texttelfIns.Text = dataGridView1[6, Z].Value.ToString();
            datos.textdirecINt.Text = dataGridView1[7, Z].Value.ToString();
            datos.textmailIst.Text = dataGridView1[8, Z].Value.ToString();
            
            mate = "";
            if (datos.chkCal.CheckState == CheckState.Checked)
            {
                mate += datos.chkCal.Text+",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
           
            if (datos.chkComuni.CheckState == CheckState.Checked)
            {
                mate += datos.chkComuni.Text + ",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
           
            if (datos.chkDise.CheckState == CheckState.Checked)
            {
                mate += datos.chkDise.Text + ",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
           
            if (datos.chkFlui.CheckState == CheckState.Checked)
            {
                mate += datos.chkFlui.Text + ",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
           if (datos.chkingle.CheckState == CheckState.Checked)
            {
                mate += datos.chkingle.Text + ",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
            
            if (datos.chkmant.CheckState == CheckState.Checked)
            {
                mate += datos.chkmant.Text + ",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
            
            if (datos.chkMeto.CheckState == CheckState.Checked)
            {
                mate += datos.chkMeto.Text + ",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
            
            if (datos.chquimi.CheckState == CheckState.Checked)
            {
                mate += datos.chquimi.Text + ",";
                mate = dataGridView1[9, Z].Value.ToString();
            }
            datos.textfax.Text = dataGridView1[10, Z].Value.ToString();
            datos.textProvincia.Text = dataGridView1[11, Z].Value.ToString();
            
            try
            {
                textedit.Text = dataGridView1.CurrentCell.Value.ToString();
            }
            catch (Exception)
            {
                
                throw;
            }
            
            
        }
        /*public bool VerificarCedula(string cedula)
        {
            int Num;
            var total=0;
            const int tamaño_longitud_cedula = 10;
            int[] coeficiente={2,1,2,1,2,1,2,1,2};
            const int Numero_provinci = 24;
            const int tercer_digito = 6;
            if (int.TryParse(cedula, out Num)&&cedula.Length==tamaño_longitud_cedula)
            {
                var pronvincia = Convert.ToInt32(string.Concat(cedula[0], cedula[1], string.Empty));
                var digito_3 = Convert.ToInt32(cedula[2] + string.Empty);
                if ((pronvincia>0&&pronvincia<=Numero_provinci)&&digito_3<tercer_digito)
                {
                    var digito_rcivido_verificador = Convert.ToInt32(cedula[9] + string.Empty);
                    for (var i = 0; i < coeficiente.Length; i++)
                    {
                        var valor = Convert.ToInt32(coeficiente[i] + string.Empty) * Convert.ToInt32(cedula[i] + string.Empty);
                        total = valor >= 10 ? total + (valor - 9) : total + valor;

                    }
                    var digito_verificador_obtenido = total >= 10 ? (total % 10) != 0 ? 10 - (total % 10) : (total % 10) : total;
                    MessageBox.Show("" + total);
                    return digito_verificador_obtenido == digito_rcivido_verificador;

                }
               
            }

            return false;
               
        }*/
        private void butcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Cedula_1()
        {
            string cedula;
            cedula = textced.Text;
            char[] vector = cedula.ToArray();
            int sumaTotal = 0;
            if (vector.Length==10)
            {
                for (int i = 0; i <vector.Length-1; i++)
                {
                    int digito = Convert.ToInt32(vector[i].ToString());
                    if ((i+1)%2==1)
                    {
                        digito = Convert.ToInt32(vector[i].ToString())*2;
                        if (digito<9)
                        {
                            digito = digito - 9;
                        }
                    }
                    sumaTotal += digito;

                }
                sumaTotal = 10 - (sumaTotal % 10);
                if (sumaTotal > 9)
                {
                    textced.Text = "Ingrese cedula";
                }
                else
                {
                    textdigito.Text = sumaTotal.ToString();
                }
            }
            
                
            else
            {
                MessageBox.Show("El numero es muy corto o largo o no puso ninguno");
                datos.j--;
                i--;
                textced.Text = "";

            }

           
        }
        private void textced_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
           
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
                 
            }
           
        }

        private void texttel_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textedad_KeyPress(object sender, KeyPressEventArgs e)
        {

            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textapeli_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textdirec_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textSegunNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textseguenAple_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textunidda_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textmaterFav_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textjoby_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textdeporFavo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textdeporFavo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textjoby_TextChanged(object sender, EventArgs e)
        {

        }

        private void textmaterFav_TextChanged(object sender, EventArgs e)
        {

        }

        private void butbuscar_Click(object sender, EventArgs e)
        {
            OpenFileDialog Imagen = new OpenFileDialog();
            Imagen.InitialDirectory = "C:\\";
            Imagen.Filter = "Archivos de imagen (*.jpg)(jpeg)|*.jpg;*.jpeg|PNG(*.png)|*.png|GIF(*.gif)|*.gif";
            if (Imagen.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = Imagen.FileName;

            }
            else
            {
                MessageBox.Show("No tiene ninguna imagen seleccionada seguro que desea salir", "Mensaje", MessageBoxButtons.OK);
            }
        }
        
    }
}
