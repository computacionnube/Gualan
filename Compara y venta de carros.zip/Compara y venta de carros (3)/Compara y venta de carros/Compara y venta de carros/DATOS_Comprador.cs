﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compara_y_venta_de_carros
{
    public partial class DATOS_Comprador : Form
    {
        DATOS_Vendedor datoss = new DATOS_Vendedor();
        public DATOS_Comprador()
        {
            InitializeComponent();
        }
        public int pos2;
        string nombre, apellido, direccion, telefono, ciudad,email;
        int i = 0;
        private void btnGuardarCompr_Click(object sender, EventArgs e)
        {

           nombre=txtnomb_comp.Text;
           apellido = txtapelli_comp.Text;
           email=txtemail_comp.Text;
           direccion=txtdirec_comp.Text;
           telefono=txtnumtelefono_comp.Text;
           ciudad=txtciud_comp.Text;
            dgvDATOS_comprador.Rows.Add(i,nombre,apellido,email,direccion,telefono,ciudad);
            i++;
            //this.Hide();
        }

        private void btnSAlircom_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataCompador_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos2 = dataCompador.CurrentRow.Index;
            datoss.textBox15.Text = dataCompador[1, pos2].Value.ToString();
            datoss.txtnomb_vend.Text = dataCompador[2, pos2].Value.ToString();
            datoss.txtapelli_vend.Text=dataCompador[3, pos2].Value.ToString();
            datoss.txtmodvehi_vend.Text = dataCompador[4, pos2].Value.ToString();
            datoss.txtmarcavehi_vend.Text = dataCompador[5, pos2].Value.ToString();
            datoss.txtkilomcont_vend.Text = dataCompador[6, pos2].Value.ToString();
        }
    }
}
