﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compara_y_venta_de_carros
{
    public partial class DATOS_Vendedor : Form
    {
       
        public DATOS_Vendedor()
        {
            InitializeComponent();
        }
        public int j = 1;
         public string nombre, direccion, nacionalidad, apellido, telefono, mail, marca, modelo, kilo;
        private void btnguar_vend_Click(object sender, EventArgs e)
        {
            DATOS_Comprador neww = new DATOS_Comprador();
            neww.Visible = true;
            this.Hide();
            nombre = txtnomb_vend.Text;
            direccion = txtdirec_vend.Text;
            nacionalidad = textBox15.Text;
            apellido = txtapelli_vend.Text;
            modelo = txtmodvehi_vend.Text;
            marca = txtmarcavehi_vend.Text;
            kilo = txtkilomcont_vend.Text;
            neww.dataCompador.Rows.Add(j,nacionalidad,nombre,apellido,marca,modelo,kilo);
            j++;
            

        }

        private void btnCnce_vend_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ESTA SEGURO ");
            if (DialogResult.Yes == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void DATOS_Vendedor_Load(object sender, EventArgs e)
        {

        }

        private void txttelf_vend_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
