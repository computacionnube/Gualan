﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compara_y_venta_de_carros
{
    public partial class Form1 : Form
    {
        struct Agenda
        
        {
            string Carro;
            public Agenda(string carro)            
            {
                Carro = carro;

            }
            public void setCrro(string C1)
            {
                Carro = C1;
            }
            public string getCrro()
            {
                return Carro;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
        Agenda[] contactos = new Agenda[100];
        DATOS_Comprador compra = new DATOS_Comprador();
        DATOS_Vendedor vender = new DATOS_Vendedor();
        int imag1= 0;
        int imag2 = 0;
        int imag3 = 0;
      //  Agenda[] contactos = new Agenda[100];
        int indice = 0;
        int pos = 0; int pos2 = 0;
        int pe = 0; int pe2 = 0;
        string estado = ""; string estado2 = "";
        
        private void RelogMIts_Tick(object sender, EventArgs e)
        {
            Pantalla1.Image = listimagen.Images[imag1];
            imag1++;
            if (imag1 == 3)
            {
                imag1= 0;
            }
        }
        private void carro1()
        {
            if (cmbModel_Mits.SelectedIndex == 0)
            {
                Pantalla1.Image = listimagen.Images[imag1=0];
                RelogMIts.Stop();
               
 
            }
            if (cmbModel_Mits.SelectedIndex == 1)
            {
                Pantalla1.Image = listimagen.Images[imag1 = 1];
                RelogMIts.Stop();
                
 

            }
            if (cmbModel_Mits.SelectedIndex == 2)
            {
                Pantalla1.Image = listimagen.Images[imag1 = 2];
                RelogMIts.Stop();
              
 

            }
        }
        private void carro2()
        {
            if (cobmodeloacura.SelectedIndex == 0)
            {
                Pantalla2.Image = lstAcura.Images[imag2 = 0];
                RelojAcura.Stop();
                

            }
            if (cobmodeloacura.SelectedIndex == 1)
            {
                Pantalla2.Image = lstAcura.Images[imag2 = 1];
                RelojAcura.Stop();



            }
            if (cobmodeloacura.SelectedIndex == 2)
            {
                Pantalla2.Image = lstAcura.Images[imag2 = 2];
                RelojAcura.Stop();
                


            }
        }
        private void carro3()
        {
            if (cmbMod_Toyota.SelectedIndex == 0)
            {
                Pantalla3.Image = lstTOYOTA.Images[imag3 = 0];
                RelojToyota.Stop();
                
 
            }
            if (cmbMod_Toyota.SelectedIndex == 1)
            {
                Pantalla3.Image = lstTOYOTA.Images[imag3= 1];
                RelojToyota.Stop();
                

            }
            if (cmbMod_Toyota.SelectedIndex == 2)
            {
                Pantalla3.Image = lstTOYOTA.Images[imag3 = 2];
                RelojToyota.Stop();
                

            }
            if (cmbMod_Toyota.SelectedIndex == 3)
            {
                Pantalla3.Image = lstTOYOTA.Images[imag3 = 3];
                RelojToyota.Stop();
                

            }
        }
    
    
        private void RelojAcura_Tick(object sender, EventArgs e)
        {
            Pantalla2.Image = lstAcura.Images[imag2];
            imag2++;
            if (imag2 == 3)
            {
                imag2 = 0;
            }

        }
        private void RelojToyota_Tick(object sender, EventArgs e)
        {
            Pantalla3.Image = lstTOYOTA.Images[imag3];
            imag3++;
            if (imag3 == 4)
            {
                imag3 = 0;
            }
        }
        private void butModelos_Click(object sender, EventArgs e)
        {
            indice = 1;
            tabCcArros1.SelectTab(indice);
            RelogMIts.Enabled = true;
            
        }

        private void tabCcArros_SelectedIndexChanged(object sender, EventArgs e)
        {
            tabCcArros1.SelectTab(indice);
           
        }

        private void butComp_Click(object sender, EventArgs e)
        {
            compra.Visible = true;
            indice = 0;
            tabCcArros1.SelectTab(indice);
        }
        private void btncomprAcura_Click(object sender, EventArgs e)
        {
            compra.Visible = true;
            indice = 0;
            tabCcArros1.SelectTab(indice);
        }

        private void btncomprToyota_Click(object sender, EventArgs e)
        {
            compra.Visible = true;
            indice = 0;
            tabCcArros1.SelectTab(indice);
        }
        private void btnsig1_Click(object sender, EventArgs e)
        {
            indice = 2;
            tabCcArros1.SelectTab(indice);
            RelojAcura.Start();
        }

       

        private void button3_Click(object sender, EventArgs e)
        {
            indice = 1;
            tabCcArros1.SelectTab(indice);
            RelogMIts.Enabled = true;
        }

        private void btnsig2_Click(object sender, EventArgs e)
        {
            indice = 3;
            tabCcArros1.SelectTab(indice);
            RelojToyota.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            indice = 2;
            tabCcArros1.SelectTab(indice);
            RelogMIts.Enabled = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            vender.Show();

        }

        private void btnsalir1_Click(object sender, EventArgs e)
        {
            indice =0;
            tabCcArros1.SelectTab(indice);
            RelogMIts.Enabled = true;
        }

        private void btnsalir2_Click(object sender, EventArgs e)
        {
            indice = 0;
            tabCcArros1.SelectTab(indice);
            RelogMIts.Enabled = true;
        }

        private void btnsalir3_Click(object sender, EventArgs e)
        {
            indice = 0;
            tabCcArros1.SelectTab(indice);
            RelogMIts.Enabled = true;
        }

        private void cmbModel_Mits_SelectedIndexChanged(object sender, EventArgs e)
        {
            carro1();
        }

        private void cbomodeloacura_SelectedIndexChanged(object sender, EventArgs e)
        {
            carro2();
        }

        private void cmbVer_Mits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbVer_Mits.SelectedIndex == 0)
            {
                lblPresio_Mits.Text = "45.000.00";
            }
            if (cmbVer_Mits.SelectedIndex == 1)
            {
                lblPresio_Mits.Text = "125.000.00";

            }
            if (cmbVer_Mits.SelectedIndex == 2)
            {
                lblPresio_Mits.Text = "25.000.00";
            }
            if (cmbVer_Mits.SelectedIndex == 3)
            {
                lblPresio_Mits.Text = "85.000.00";
            }
        }

        private void cboversionacura_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobmodeloacura.SelectedIndex == 0)
            {
                lblPresio_Mits.Text = "35.000.00";
            }
            if (cobmodeloacura.SelectedIndex == 1)
            {
                lblPresio_Mits.Text = "86.000.00";
            }
            if (cobmodeloacura.SelectedIndex == 3)
            {
                lblPresio_Mits.Text = "65.000.00";
            }
        }

        private void cmbMod_Toyota_SelectedIndexChanged(object sender, EventArgs e)
        {
            carro3();
        }

        private void cmbVer_Toyota_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbVer_Toyota.SelectedIndex == 0)
            {
                lblprecio_toyota.Text = "34.000.00";
            }
            if (cmbVer_Toyota.SelectedIndex == 1)
            {
                lblprecio_toyota.Text = "50.000.00";
            }
            if (cmbVer_Toyota.SelectedIndex == 2)
            {
                lblprecio_toyota.Text = "25.000.00";
            }
            if (cmbVer_Toyota.SelectedIndex == 3)
            {
                lblprecio_toyota.Text = "400.000.00";
            }
        }

        

        

    }
}
