﻿namespace Cronometro_temporisador__
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.butencerar = new System.Windows.Forms.Button();
            this.butdetener = new System.Windows.Forms.Button();
            this.butiniciar = new System.Windows.Forms.Button();
            this.textiempo = new System.Windows.Forms.TextBox();
            this.Relog = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpreloj = new System.Windows.Forms.DateTimePicker();
            this.Alarma = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.dtpFijahora = new System.Windows.Forms.DateTimePicker();
            this.butfijaralrma = new System.Windows.Forms.Button();
            this.nudHoras = new System.Windows.Forms.NumericUpDown();
            this.nudminutos = new System.Windows.Forms.NumericUpDown();
            this.nudsegundos = new System.Windows.Forms.NumericUpDown();
            this.butActivart = new System.Windows.Forms.Button();
            this.butdesactivar = new System.Windows.Forms.Button();
            this.Bomba = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nudHoras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudminutos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudsegundos)).BeginInit();
            this.SuspendLayout();
            // 
            // butencerar
            // 
            this.butencerar.Location = new System.Drawing.Point(206, 12);
            this.butencerar.Name = "butencerar";
            this.butencerar.Size = new System.Drawing.Size(75, 23);
            this.butencerar.TabIndex = 0;
            this.butencerar.Text = "Encerar";
            this.butencerar.UseVisualStyleBackColor = true;
            this.butencerar.Click += new System.EventHandler(this.butencerar_Click);
            // 
            // butdetener
            // 
            this.butdetener.Location = new System.Drawing.Point(104, 12);
            this.butdetener.Name = "butdetener";
            this.butdetener.Size = new System.Drawing.Size(75, 23);
            this.butdetener.TabIndex = 1;
            this.butdetener.Text = "Detener";
            this.butdetener.UseVisualStyleBackColor = true;
            this.butdetener.Click += new System.EventHandler(this.butdetener_Click);
            // 
            // butiniciar
            // 
            this.butiniciar.Location = new System.Drawing.Point(12, 12);
            this.butiniciar.Name = "butiniciar";
            this.butiniciar.Size = new System.Drawing.Size(75, 23);
            this.butiniciar.TabIndex = 2;
            this.butiniciar.Text = "Iniciar";
            this.butiniciar.UseVisualStyleBackColor = true;
            this.butiniciar.Click += new System.EventHandler(this.butiniciar_Click);
            // 
            // textiempo
            // 
            this.textiempo.BackColor = System.Drawing.Color.Silver;
            this.textiempo.ForeColor = System.Drawing.Color.Black;
            this.textiempo.Location = new System.Drawing.Point(104, 91);
            this.textiempo.Name = "textiempo";
            this.textiempo.Size = new System.Drawing.Size(63, 20);
            this.textiempo.TabIndex = 3;
            this.textiempo.Text = "00:00:00.0";
            // 
            // Relog
            // 
            this.Relog.Tick += new System.EventHandler(this.Relog_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tiempo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Reloj";
            // 
            // dtpreloj
            // 
            this.dtpreloj.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpreloj.Location = new System.Drawing.Point(104, 140);
            this.dtpreloj.Name = "dtpreloj";
            this.dtpreloj.Size = new System.Drawing.Size(86, 20);
            this.dtpreloj.TabIndex = 6;
            // 
            // Alarma
            // 
            this.Alarma.Enabled = true;
            this.Alarma.Tick += new System.EventHandler(this.Alarma_Tick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "Fijar Hora";
            // 
            // dtpFijahora
            // 
            this.dtpFijahora.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpFijahora.Location = new System.Drawing.Point(104, 182);
            this.dtpFijahora.Name = "dtpFijahora";
            this.dtpFijahora.ShowUpDown = true;
            this.dtpFijahora.Size = new System.Drawing.Size(86, 20);
            this.dtpFijahora.TabIndex = 8;
            // 
            // butfijaralrma
            // 
            this.butfijaralrma.Location = new System.Drawing.Point(209, 179);
            this.butfijaralrma.Name = "butfijaralrma";
            this.butfijaralrma.Size = new System.Drawing.Size(75, 23);
            this.butfijaralrma.TabIndex = 9;
            this.butfijaralrma.Text = "Fijar Alarma";
            this.butfijaralrma.UseVisualStyleBackColor = true;
            this.butfijaralrma.Click += new System.EventHandler(this.butfijaralrma_Click);
            // 
            // nudHoras
            // 
            this.nudHoras.Location = new System.Drawing.Point(285, 91);
            this.nudHoras.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nudHoras.Name = "nudHoras";
            this.nudHoras.Size = new System.Drawing.Size(32, 20);
            this.nudHoras.TabIndex = 10;
            // 
            // nudminutos
            // 
            this.nudminutos.Location = new System.Drawing.Point(332, 90);
            this.nudminutos.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nudminutos.Name = "nudminutos";
            this.nudminutos.Size = new System.Drawing.Size(38, 20);
            this.nudminutos.TabIndex = 11;
            // 
            // nudsegundos
            // 
            this.nudsegundos.Location = new System.Drawing.Point(389, 90);
            this.nudsegundos.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nudsegundos.Name = "nudsegundos";
            this.nudsegundos.Size = new System.Drawing.Size(34, 20);
            this.nudsegundos.TabIndex = 12;
            // 
            // butActivart
            // 
            this.butActivart.Location = new System.Drawing.Point(342, 128);
            this.butActivart.Name = "butActivart";
            this.butActivart.Size = new System.Drawing.Size(94, 31);
            this.butActivart.TabIndex = 13;
            this.butActivart.Text = "Activar";
            this.butActivart.UseVisualStyleBackColor = true;
            this.butActivart.Click += new System.EventHandler(this.butActivart_Click);
            // 
            // butdesactivar
            // 
            this.butdesactivar.Location = new System.Drawing.Point(342, 165);
            this.butdesactivar.Name = "butdesactivar";
            this.butdesactivar.Size = new System.Drawing.Size(94, 36);
            this.butdesactivar.TabIndex = 14;
            this.butdesactivar.Text = "Desactivar";
            this.butdesactivar.UseVisualStyleBackColor = true;
            this.butdesactivar.Click += new System.EventHandler(this.butdesactivar_Click);
            // 
            // Bomba
            // 
            this.Bomba.Tick += new System.EventHandler(this.Bomba_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 241);
            this.Controls.Add(this.butdesactivar);
            this.Controls.Add(this.butActivart);
            this.Controls.Add(this.nudsegundos);
            this.Controls.Add(this.nudminutos);
            this.Controls.Add(this.nudHoras);
            this.Controls.Add(this.butfijaralrma);
            this.Controls.Add(this.dtpFijahora);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtpreloj);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textiempo);
            this.Controls.Add(this.butiniciar);
            this.Controls.Add(this.butdetener);
            this.Controls.Add(this.butencerar);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudHoras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudminutos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudsegundos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butencerar;
        private System.Windows.Forms.Button butdetener;
        private System.Windows.Forms.Button butiniciar;
        private System.Windows.Forms.TextBox textiempo;
        private System.Windows.Forms.Timer Relog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpreloj;
        private System.Windows.Forms.Timer Alarma;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpFijahora;
        private System.Windows.Forms.Button butfijaralrma;
        private System.Windows.Forms.NumericUpDown nudHoras;
        private System.Windows.Forms.NumericUpDown nudminutos;
        private System.Windows.Forms.NumericUpDown nudsegundos;
        private System.Windows.Forms.Button butActivart;
        private System.Windows.Forms.Button butdesactivar;
        private System.Windows.Forms.Timer Bomba;
    }
}

