﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Cronometro_temporisador__
{
    public partial class Form1 : Form
    {
        int dd;
        int ss;
        int mm;
        int hh = 0;
        int hb, mb, sb;
        int fija_alarma = 0;
        public Form1()
        {
            InitializeComponent();
            butencerar.Enabled = false;
        }

        private void butiniciar_Click(object sender, EventArgs e)
        {
            
            Relog.Start();
        }

        private void butdetener_Click(object sender, EventArgs e)
        {
            butencerar.Enabled = true;
            Relog.Stop();
        }

        private void Relog_Tick(object sender, EventArgs e)
        {
            string ht,mt,st;
            dd++;
            if (dd==10)
            {
                dd = 0;
                ss++;
            }
            if (ss==60)
            {
                mm++;
                ss = 0;
                
            }
            if (mm==60)
            {
                hh++;
                mm = 0;
            }
            if (hh<10)
            {
                ht = "0" + Convert.ToString(hh);

            }
            else
            {
                ht = Convert.ToString(hh);

            }
            if (mm<10)
            {
                mt = "0" + Convert.ToString(mm);
            }
            else
            {
                mt = Convert.ToString(mm);
            }
            if (ss<10)
            {
                st = "0" + Convert.ToString(ss);
            }
            else
            {
                st = Convert.ToString(ss);
            }
            textiempo.Text=ht+":"+mt+":"+st+":"+"."+Convert.ToString(dd);
        }

        private void butencerar_Click(object sender, EventArgs e)
        {
            Relog.Stop();
            dd = 0;
            ss = 0;
            mm = 0;
            hh = 0;
            textiempo.Clear();
            textiempo.Text = "00:00:00.0";
        }

        private void Alarma_Tick(object sender, EventArgs e)
        {
            dtpreloj.Value = DateTime.Now;
            if (fija_alarma==1)
            {
                if (dtpreloj.Value.Second==dtpFijahora.Value.Second && dtpreloj.Value.Minute==dtpFijahora.Value.Minute && dtpreloj.Value.Hour==dtpFijahora.Value.Hour)
                {
                    
                    fija_alarma = 0;
                    MessageBox.Show("Alarma");
                }
            }
        }

        private void butfijaralrma_Click(object sender, EventArgs e)
        {
            fija_alarma = 1;
        }

        private void Bomba_Tick(object sender, EventArgs e)
        {
            sb--;
            if (sb <= 0)
            {
                if (mb > 0)
                {
                    mb--;
                    sb = 59;
                }
              

            }
            if (mb == 0)
            {
                if (hb > 0)
                {
                    hb--;
                    mb = 59;
                }
            }
            nudHoras.Value = Convert.ToDecimal(hb);
            nudminutos.Value = Convert.ToDecimal(mb);
            nudsegundos.Value = Convert.ToDecimal(sb);
            if (sb==0&&mb==0&&hb==0)
            {
                Bomba.Stop();
                MessageBox.Show("Termino el tiempo","Bomba",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }

        }

        private void butActivart_Click(object sender, EventArgs e)
        {
            sb = Convert.ToInt32(nudsegundos.Value);
            mb = Convert.ToInt32(nudminutos.Value);
            hb = Convert.ToInt32(nudHoras.Value);
            Bomba.Start();
        }

        private void butdesactivar_Click(object sender, EventArgs e)
        {
            Bomba.Stop();
        }


    }
}
