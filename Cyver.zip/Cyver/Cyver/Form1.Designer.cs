﻿namespace Cyver
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.but2 = new System.Windows.Forms.Button();
            this.but3 = new System.Windows.Forms.Button();
            this.but4 = new System.Windows.Forms.Button();
            this.but5 = new System.Windows.Forms.Button();
            this.but6 = new System.Windows.Forms.Button();
            this.but1 = new System.Windows.Forms.Button();
            this.nudHoras = new System.Windows.Forms.NumericUpDown();
            this.nudMin = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textLibres = new System.Windows.Forms.TextBox();
            this.textocupado = new System.Windows.Forms.TextBox();
            this.butsalir = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labTC6 = new System.Windows.Forms.Label();
            this.labTF6 = new System.Windows.Forms.Label();
            this.labTC5 = new System.Windows.Forms.Label();
            this.labTF5 = new System.Windows.Forms.Label();
            this.labTC4 = new System.Windows.Forms.Label();
            this.labTF4 = new System.Windows.Forms.Label();
            this.labTC3 = new System.Windows.Forms.Label();
            this.labTF3 = new System.Windows.Forms.Label();
            this.labTC2 = new System.Windows.Forms.Label();
            this.labTF2 = new System.Windows.Forms.Label();
            this.labTC1 = new System.Windows.Forms.Label();
            this.labTF1 = new System.Windows.Forms.Label();
            this.labTT6 = new System.Windows.Forms.Label();
            this.labTT5 = new System.Windows.Forms.Label();
            this.labTT4 = new System.Windows.Forms.Label();
            this.labTT3 = new System.Windows.Forms.Label();
            this.labTT2 = new System.Windows.Forms.Label();
            this.labTT1 = new System.Windows.Forms.Label();
            this.labTUSO6 = new System.Windows.Forms.Label();
            this.labTUSO5 = new System.Windows.Forms.Label();
            this.labTUSO4 = new System.Windows.Forms.Label();
            this.labTUSO3 = new System.Windows.Forms.Label();
            this.labTUSO2 = new System.Windows.Forms.Label();
            this.labTUSO1 = new System.Windows.Forms.Label();
            this.labE6 = new System.Windows.Forms.Label();
            this.labE5 = new System.Windows.Forms.Label();
            this.labE4 = new System.Windows.Forms.Label();
            this.labE3 = new System.Windows.Forms.Label();
            this.labE2 = new System.Windows.Forms.Label();
            this.labE1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.butP1 = new System.Windows.Forms.Button();
            this.butP2 = new System.Windows.Forms.Button();
            this.butP3 = new System.Windows.Forms.Button();
            this.butP4 = new System.Windows.Forms.Button();
            this.butP5 = new System.Windows.Forms.Button();
            this.butP6 = new System.Windows.Forms.Button();
            this.listP = new System.Windows.Forms.ListBox();
            this.label44 = new System.Windows.Forms.Label();
            this.labTotalPagar = new System.Windows.Forms.Label();
            this.labCHO = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Reloj1 = new System.Windows.Forms.Timer(this.components);
            this.Reloj2 = new System.Windows.Forms.Timer(this.components);
            this.Reloj3 = new System.Windows.Forms.Timer(this.components);
            this.Reloj4 = new System.Windows.Forms.Timer(this.components);
            this.Reloj5 = new System.Windows.Forms.Timer(this.components);
            this.Reloj6 = new System.Windows.Forms.Timer(this.components);
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nudHoras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMin)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // but2
            // 
            this.but2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("but2.BackgroundImage")));
            this.but2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.but2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but2.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but2.ForeColor = System.Drawing.Color.White;
            this.but2.Location = new System.Drawing.Point(104, 17);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(63, 44);
            this.but2.TabIndex = 1;
            this.but2.Text = "2";
            this.but2.UseVisualStyleBackColor = true;
            this.but2.Click += new System.EventHandler(this.but2_Click);
            // 
            // but3
            // 
            this.but3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("but3.BackgroundImage")));
            this.but3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.but3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but3.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but3.ForeColor = System.Drawing.Color.White;
            this.but3.Location = new System.Drawing.Point(24, 83);
            this.but3.Name = "but3";
            this.but3.Size = new System.Drawing.Size(63, 44);
            this.but3.TabIndex = 2;
            this.but3.Text = "3";
            this.but3.UseVisualStyleBackColor = true;
            // 
            // but4
            // 
            this.but4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("but4.BackgroundImage")));
            this.but4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.but4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but4.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but4.ForeColor = System.Drawing.Color.White;
            this.but4.Location = new System.Drawing.Point(104, 83);
            this.but4.Name = "but4";
            this.but4.Size = new System.Drawing.Size(63, 44);
            this.but4.TabIndex = 3;
            this.but4.Text = "4";
            this.but4.UseVisualStyleBackColor = true;
            // 
            // but5
            // 
            this.but5.BackColor = System.Drawing.Color.White;
            this.but5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("but5.BackgroundImage")));
            this.but5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.but5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but5.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but5.ForeColor = System.Drawing.Color.White;
            this.but5.Location = new System.Drawing.Point(24, 148);
            this.but5.Name = "but5";
            this.but5.Size = new System.Drawing.Size(63, 44);
            this.but5.TabIndex = 4;
            this.but5.Text = "5";
            this.but5.UseVisualStyleBackColor = false;
            // 
            // but6
            // 
            this.but6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("but6.BackgroundImage")));
            this.but6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.but6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but6.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but6.ForeColor = System.Drawing.Color.White;
            this.but6.Location = new System.Drawing.Point(104, 148);
            this.but6.Name = "but6";
            this.but6.Size = new System.Drawing.Size(63, 44);
            this.but6.TabIndex = 5;
            this.but6.Text = "6";
            this.but6.UseVisualStyleBackColor = true;
            // 
            // but1
            // 
            this.but1.BackColor = System.Drawing.Color.White;
            this.but1.BackgroundImage = global::Cyver.Properties.Resources._2;
            this.but1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.but1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but1.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but1.ForeColor = System.Drawing.Color.White;
            this.but1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.but1.Location = new System.Drawing.Point(24, 16);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(63, 44);
            this.but1.TabIndex = 0;
            this.but1.Text = "1";
            this.but1.UseVisualStyleBackColor = false;
            this.but1.Click += new System.EventHandler(this.but1_Click);
            // 
            // nudHoras
            // 
            this.nudHoras.Location = new System.Drawing.Point(24, 253);
            this.nudHoras.Name = "nudHoras";
            this.nudHoras.Size = new System.Drawing.Size(63, 20);
            this.nudHoras.TabIndex = 6;
            // 
            // nudMin
            // 
            this.nudMin.Location = new System.Drawing.Point(104, 253);
            this.nudMin.Name = "nudMin";
            this.nudMin.Size = new System.Drawing.Size(63, 20);
            this.nudMin.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 219);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 22);
            this.label1.TabIndex = 8;
            this.label1.Text = "Horas:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(90, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 22);
            this.label2.TabIndex = 9;
            this.label2.Text = "Minutos:";
            // 
            // textLibres
            // 
            this.textLibres.Location = new System.Drawing.Point(25, 357);
            this.textLibres.Name = "textLibres";
            this.textLibres.Size = new System.Drawing.Size(72, 20);
            this.textLibres.TabIndex = 10;
            this.textLibres.Text = "Libres:";
            // 
            // textocupado
            // 
            this.textocupado.Location = new System.Drawing.Point(24, 320);
            this.textocupado.Name = "textocupado";
            this.textocupado.Size = new System.Drawing.Size(73, 20);
            this.textocupado.TabIndex = 11;
            this.textocupado.Text = "Ocupado:";
            // 
            // butsalir
            // 
            this.butsalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butsalir.Location = new System.Drawing.Point(104, 320);
            this.butsalir.Name = "butsalir";
            this.butsalir.Size = new System.Drawing.Size(65, 57);
            this.butsalir.TabIndex = 12;
            this.butsalir.Text = "Salir";
            this.butsalir.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labTC6);
            this.groupBox1.Controls.Add(this.labTF6);
            this.groupBox1.Controls.Add(this.labTC5);
            this.groupBox1.Controls.Add(this.labTF5);
            this.groupBox1.Controls.Add(this.labTC4);
            this.groupBox1.Controls.Add(this.labTF4);
            this.groupBox1.Controls.Add(this.labTC3);
            this.groupBox1.Controls.Add(this.labTF3);
            this.groupBox1.Controls.Add(this.labTC2);
            this.groupBox1.Controls.Add(this.labTF2);
            this.groupBox1.Controls.Add(this.labTC1);
            this.groupBox1.Controls.Add(this.labTF1);
            this.groupBox1.Controls.Add(this.labTT6);
            this.groupBox1.Controls.Add(this.labTT5);
            this.groupBox1.Controls.Add(this.labTT4);
            this.groupBox1.Controls.Add(this.labTT3);
            this.groupBox1.Controls.Add(this.labTT2);
            this.groupBox1.Controls.Add(this.labTT1);
            this.groupBox1.Controls.Add(this.labTUSO6);
            this.groupBox1.Controls.Add(this.labTUSO5);
            this.groupBox1.Controls.Add(this.labTUSO4);
            this.groupBox1.Controls.Add(this.labTUSO3);
            this.groupBox1.Controls.Add(this.labTUSO2);
            this.groupBox1.Controls.Add(this.labTUSO1);
            this.groupBox1.Controls.Add(this.labE6);
            this.groupBox1.Controls.Add(this.labE5);
            this.groupBox1.Controls.Add(this.labE4);
            this.groupBox1.Controls.Add(this.labE3);
            this.groupBox1.Controls.Add(this.labE2);
            this.groupBox1.Controls.Add(this.labE1);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(186, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(486, 331);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // labTC6
            // 
            this.labTC6.BackColor = System.Drawing.Color.White;
            this.labTC6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTC6.Location = new System.Drawing.Point(406, 294);
            this.labTC6.Name = "labTC6";
            this.labTC6.Size = new System.Drawing.Size(58, 23);
            this.labTC6.TabIndex = 40;
            // 
            // labTF6
            // 
            this.labTF6.BackColor = System.Drawing.Color.White;
            this.labTF6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTF6.Location = new System.Drawing.Point(312, 295);
            this.labTF6.Name = "labTF6";
            this.labTF6.Size = new System.Drawing.Size(58, 23);
            this.labTF6.TabIndex = 39;
            // 
            // labTC5
            // 
            this.labTC5.BackColor = System.Drawing.Color.White;
            this.labTC5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTC5.Location = new System.Drawing.Point(406, 245);
            this.labTC5.Name = "labTC5";
            this.labTC5.Size = new System.Drawing.Size(58, 23);
            this.labTC5.TabIndex = 38;
            // 
            // labTF5
            // 
            this.labTF5.BackColor = System.Drawing.Color.White;
            this.labTF5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTF5.Location = new System.Drawing.Point(312, 245);
            this.labTF5.Name = "labTF5";
            this.labTF5.Size = new System.Drawing.Size(58, 23);
            this.labTF5.TabIndex = 37;
            // 
            // labTC4
            // 
            this.labTC4.BackColor = System.Drawing.Color.White;
            this.labTC4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTC4.Location = new System.Drawing.Point(406, 194);
            this.labTC4.Name = "labTC4";
            this.labTC4.Size = new System.Drawing.Size(58, 23);
            this.labTC4.TabIndex = 36;
            // 
            // labTF4
            // 
            this.labTF4.BackColor = System.Drawing.Color.White;
            this.labTF4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTF4.Location = new System.Drawing.Point(312, 194);
            this.labTF4.Name = "labTF4";
            this.labTF4.Size = new System.Drawing.Size(58, 23);
            this.labTF4.TabIndex = 35;
            // 
            // labTC3
            // 
            this.labTC3.BackColor = System.Drawing.Color.White;
            this.labTC3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTC3.Location = new System.Drawing.Point(406, 153);
            this.labTC3.Name = "labTC3";
            this.labTC3.Size = new System.Drawing.Size(58, 23);
            this.labTC3.TabIndex = 34;
            // 
            // labTF3
            // 
            this.labTF3.BackColor = System.Drawing.Color.White;
            this.labTF3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTF3.Location = new System.Drawing.Point(312, 153);
            this.labTF3.Name = "labTF3";
            this.labTF3.Size = new System.Drawing.Size(58, 23);
            this.labTF3.TabIndex = 33;
            // 
            // labTC2
            // 
            this.labTC2.BackColor = System.Drawing.Color.White;
            this.labTC2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTC2.Location = new System.Drawing.Point(407, 113);
            this.labTC2.Name = "labTC2";
            this.labTC2.Size = new System.Drawing.Size(58, 23);
            this.labTC2.TabIndex = 32;
            // 
            // labTF2
            // 
            this.labTF2.BackColor = System.Drawing.Color.White;
            this.labTF2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTF2.Location = new System.Drawing.Point(312, 113);
            this.labTF2.Name = "labTF2";
            this.labTF2.Size = new System.Drawing.Size(58, 23);
            this.labTF2.TabIndex = 31;
            // 
            // labTC1
            // 
            this.labTC1.BackColor = System.Drawing.Color.White;
            this.labTC1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTC1.Location = new System.Drawing.Point(407, 68);
            this.labTC1.Name = "labTC1";
            this.labTC1.Size = new System.Drawing.Size(58, 23);
            this.labTC1.TabIndex = 30;
            // 
            // labTF1
            // 
            this.labTF1.BackColor = System.Drawing.Color.White;
            this.labTF1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTF1.Location = new System.Drawing.Point(312, 68);
            this.labTF1.Name = "labTF1";
            this.labTF1.Size = new System.Drawing.Size(58, 23);
            this.labTF1.TabIndex = 29;
            // 
            // labTT6
            // 
            this.labTT6.BackColor = System.Drawing.Color.White;
            this.labTT6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTT6.Location = new System.Drawing.Point(224, 294);
            this.labTT6.Name = "labTT6";
            this.labTT6.Size = new System.Drawing.Size(58, 23);
            this.labTT6.TabIndex = 28;
            // 
            // labTT5
            // 
            this.labTT5.BackColor = System.Drawing.Color.White;
            this.labTT5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTT5.Location = new System.Drawing.Point(220, 246);
            this.labTT5.Name = "labTT5";
            this.labTT5.Size = new System.Drawing.Size(58, 23);
            this.labTT5.TabIndex = 27;
            // 
            // labTT4
            // 
            this.labTT4.BackColor = System.Drawing.Color.White;
            this.labTT4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTT4.Location = new System.Drawing.Point(220, 194);
            this.labTT4.Name = "labTT4";
            this.labTT4.Size = new System.Drawing.Size(58, 23);
            this.labTT4.TabIndex = 26;
            // 
            // labTT3
            // 
            this.labTT3.BackColor = System.Drawing.Color.White;
            this.labTT3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTT3.Location = new System.Drawing.Point(220, 153);
            this.labTT3.Name = "labTT3";
            this.labTT3.Size = new System.Drawing.Size(58, 23);
            this.labTT3.TabIndex = 25;
            // 
            // labTT2
            // 
            this.labTT2.BackColor = System.Drawing.Color.White;
            this.labTT2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTT2.Location = new System.Drawing.Point(220, 113);
            this.labTT2.Name = "labTT2";
            this.labTT2.Size = new System.Drawing.Size(58, 23);
            this.labTT2.TabIndex = 24;
            // 
            // labTT1
            // 
            this.labTT1.BackColor = System.Drawing.Color.White;
            this.labTT1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTT1.Location = new System.Drawing.Point(220, 67);
            this.labTT1.Name = "labTT1";
            this.labTT1.Size = new System.Drawing.Size(58, 23);
            this.labTT1.TabIndex = 23;
            // 
            // labTUSO6
            // 
            this.labTUSO6.BackColor = System.Drawing.Color.White;
            this.labTUSO6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTUSO6.Location = new System.Drawing.Point(135, 294);
            this.labTUSO6.Name = "labTUSO6";
            this.labTUSO6.Size = new System.Drawing.Size(58, 23);
            this.labTUSO6.TabIndex = 22;
            // 
            // labTUSO5
            // 
            this.labTUSO5.BackColor = System.Drawing.Color.White;
            this.labTUSO5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTUSO5.Location = new System.Drawing.Point(135, 245);
            this.labTUSO5.Name = "labTUSO5";
            this.labTUSO5.Size = new System.Drawing.Size(58, 23);
            this.labTUSO5.TabIndex = 21;
            // 
            // labTUSO4
            // 
            this.labTUSO4.BackColor = System.Drawing.Color.White;
            this.labTUSO4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTUSO4.Location = new System.Drawing.Point(135, 196);
            this.labTUSO4.Name = "labTUSO4";
            this.labTUSO4.Size = new System.Drawing.Size(58, 23);
            this.labTUSO4.TabIndex = 20;
            // 
            // labTUSO3
            // 
            this.labTUSO3.BackColor = System.Drawing.Color.White;
            this.labTUSO3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTUSO3.Location = new System.Drawing.Point(135, 153);
            this.labTUSO3.Name = "labTUSO3";
            this.labTUSO3.Size = new System.Drawing.Size(58, 23);
            this.labTUSO3.TabIndex = 19;
            // 
            // labTUSO2
            // 
            this.labTUSO2.BackColor = System.Drawing.Color.White;
            this.labTUSO2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTUSO2.Location = new System.Drawing.Point(135, 113);
            this.labTUSO2.Name = "labTUSO2";
            this.labTUSO2.Size = new System.Drawing.Size(58, 23);
            this.labTUSO2.TabIndex = 18;
            // 
            // labTUSO1
            // 
            this.labTUSO1.BackColor = System.Drawing.Color.White;
            this.labTUSO1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTUSO1.Location = new System.Drawing.Point(135, 67);
            this.labTUSO1.Name = "labTUSO1";
            this.labTUSO1.Size = new System.Drawing.Size(58, 23);
            this.labTUSO1.TabIndex = 11;
            // 
            // labE6
            // 
            this.labE6.BackColor = System.Drawing.Color.White;
            this.labE6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labE6.Location = new System.Drawing.Point(55, 294);
            this.labE6.Name = "labE6";
            this.labE6.Size = new System.Drawing.Size(58, 23);
            this.labE6.TabIndex = 16;
            // 
            // labE5
            // 
            this.labE5.BackColor = System.Drawing.Color.White;
            this.labE5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labE5.Location = new System.Drawing.Point(55, 246);
            this.labE5.Name = "labE5";
            this.labE5.Size = new System.Drawing.Size(58, 23);
            this.labE5.TabIndex = 15;
            // 
            // labE4
            // 
            this.labE4.BackColor = System.Drawing.Color.White;
            this.labE4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labE4.Location = new System.Drawing.Point(55, 194);
            this.labE4.Name = "labE4";
            this.labE4.Size = new System.Drawing.Size(58, 23);
            this.labE4.TabIndex = 14;
            // 
            // labE3
            // 
            this.labE3.BackColor = System.Drawing.Color.White;
            this.labE3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labE3.Location = new System.Drawing.Point(55, 153);
            this.labE3.Name = "labE3";
            this.labE3.Size = new System.Drawing.Size(58, 23);
            this.labE3.TabIndex = 13;
            // 
            // labE2
            // 
            this.labE2.BackColor = System.Drawing.Color.White;
            this.labE2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labE2.Location = new System.Drawing.Point(55, 113);
            this.labE2.Name = "labE2";
            this.labE2.Size = new System.Drawing.Size(58, 23);
            this.labE2.TabIndex = 12;
            // 
            // labE1
            // 
            this.labE1.BackColor = System.Drawing.Color.White;
            this.labE1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labE1.Location = new System.Drawing.Point(55, 67);
            this.labE1.Name = "labE1";
            this.labE1.Size = new System.Drawing.Size(58, 23);
            this.labE1.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(7, 295);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 16);
            this.label13.TabIndex = 10;
            this.label13.Text = "Maq6";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 246);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 16);
            this.label12.TabIndex = 9;
            this.label12.Text = "Maq5";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 197);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "Maq4";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(7, 154);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 16);
            this.label10.TabIndex = 7;
            this.label10.Text = "Maq3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 16);
            this.label9.TabIndex = 6;
            this.label9.Text = "Maq2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(7, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Maq1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(404, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Total a cobrar";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(298, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Tiempo Faltante";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(217, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Total tiempo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(116, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tiempo de uso";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Estado";
            // 
            // butP1
            // 
            this.butP1.Location = new System.Drawing.Point(698, 83);
            this.butP1.Name = "butP1";
            this.butP1.Size = new System.Drawing.Size(37, 24);
            this.butP1.TabIndex = 14;
            this.butP1.Text = "1";
            this.butP1.UseVisualStyleBackColor = true;
            this.butP1.Click += new System.EventHandler(this.butP1_Click);
            // 
            // butP2
            // 
            this.butP2.Location = new System.Drawing.Point(698, 128);
            this.butP2.Name = "butP2";
            this.butP2.Size = new System.Drawing.Size(37, 24);
            this.butP2.TabIndex = 15;
            this.butP2.Text = "2";
            this.butP2.UseVisualStyleBackColor = true;
            this.butP2.Click += new System.EventHandler(this.butP2_Click);
            // 
            // butP3
            // 
            this.butP3.Location = new System.Drawing.Point(698, 170);
            this.butP3.Name = "butP3";
            this.butP3.Size = new System.Drawing.Size(37, 24);
            this.butP3.TabIndex = 16;
            this.butP3.Text = "3";
            this.butP3.UseVisualStyleBackColor = true;
            // 
            // butP4
            // 
            this.butP4.Location = new System.Drawing.Point(698, 212);
            this.butP4.Name = "butP4";
            this.butP4.Size = new System.Drawing.Size(37, 24);
            this.butP4.TabIndex = 17;
            this.butP4.Text = "4";
            this.butP4.UseVisualStyleBackColor = true;
            // 
            // butP5
            // 
            this.butP5.Location = new System.Drawing.Point(698, 256);
            this.butP5.Name = "butP5";
            this.butP5.Size = new System.Drawing.Size(37, 24);
            this.butP5.TabIndex = 18;
            this.butP5.Text = "5";
            this.butP5.UseVisualStyleBackColor = true;
            // 
            // butP6
            // 
            this.butP6.Location = new System.Drawing.Point(698, 309);
            this.butP6.Name = "butP6";
            this.butP6.Size = new System.Drawing.Size(37, 24);
            this.butP6.TabIndex = 19;
            this.butP6.Text = "6";
            this.butP6.UseVisualStyleBackColor = true;
            // 
            // listP
            // 
            this.listP.FormattingEnabled = true;
            this.listP.Location = new System.Drawing.Point(804, 48);
            this.listP.Name = "listP";
            this.listP.Size = new System.Drawing.Size(120, 212);
            this.listP.TabIndex = 20;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(788, 287);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(44, 16);
            this.label44.TabIndex = 21;
            this.label44.Text = "Total";
            // 
            // labTotalPagar
            // 
            this.labTotalPagar.BackColor = System.Drawing.Color.White;
            this.labTotalPagar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labTotalPagar.Location = new System.Drawing.Point(838, 287);
            this.labTotalPagar.Name = "labTotalPagar";
            this.labTotalPagar.Size = new System.Drawing.Size(86, 23);
            this.labTotalPagar.TabIndex = 22;
            this.labTotalPagar.Text = "Total";
            // 
            // labCHO
            // 
            this.labCHO.BackColor = System.Drawing.Color.White;
            this.labCHO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labCHO.Location = new System.Drawing.Point(104, 288);
            this.labCHO.Name = "labCHO";
            this.labCHO.Size = new System.Drawing.Size(53, 23);
            this.labCHO.TabIndex = 23;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 290);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 13);
            this.label15.TabIndex = 24;
            this.label15.Text = "Costo de la Hora";
            // 
            // Reloj1
            // 
            this.Reloj1.Interval = 10;
            this.Reloj1.Tick += new System.EventHandler(this.Reloj1_Tick);
            // 
            // Reloj2
            // 
            this.Reloj2.Tick += new System.EventHandler(this.Reloj2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 389);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.labCHO);
            this.Controls.Add(this.labTotalPagar);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.listP);
            this.Controls.Add(this.butP6);
            this.Controls.Add(this.butP5);
            this.Controls.Add(this.butP4);
            this.Controls.Add(this.butP3);
            this.Controls.Add(this.butP2);
            this.Controls.Add(this.butP1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.butsalir);
            this.Controls.Add(this.textocupado);
            this.Controls.Add(this.textLibres);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nudMin);
            this.Controls.Add(this.nudHoras);
            this.Controls.Add(this.but6);
            this.Controls.Add(this.but5);
            this.Controls.Add(this.but4);
            this.Controls.Add(this.but3);
            this.Controls.Add(this.but2);
            this.Controls.Add(this.but1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "1";
            ((System.ComponentModel.ISupportInitialize)(this.nudHoras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMin)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.Button but2;
        private System.Windows.Forms.Button but3;
        private System.Windows.Forms.Button but4;
        private System.Windows.Forms.Button but5;
        private System.Windows.Forms.Button but6;
        private System.Windows.Forms.NumericUpDown nudHoras;
        private System.Windows.Forms.NumericUpDown nudMin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textLibres;
        private System.Windows.Forms.TextBox textocupado;
        private System.Windows.Forms.Button butsalir;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labTC6;
        private System.Windows.Forms.Label labTF6;
        private System.Windows.Forms.Label labTC5;
        private System.Windows.Forms.Label labTF5;
        private System.Windows.Forms.Label labTC4;
        private System.Windows.Forms.Label labTF4;
        private System.Windows.Forms.Label labTC3;
        private System.Windows.Forms.Label labTF3;
        private System.Windows.Forms.Label labTC2;
        private System.Windows.Forms.Label labTF2;
        private System.Windows.Forms.Label labTC1;
        private System.Windows.Forms.Label labTF1;
        private System.Windows.Forms.Label labTT6;
        private System.Windows.Forms.Label labTT5;
        private System.Windows.Forms.Label labTT4;
        private System.Windows.Forms.Label labTT3;
        private System.Windows.Forms.Label labTT2;
        private System.Windows.Forms.Label labTT1;
        private System.Windows.Forms.Label labTUSO6;
        private System.Windows.Forms.Label labTUSO5;
        private System.Windows.Forms.Label labTUSO4;
        private System.Windows.Forms.Label labTUSO3;
        private System.Windows.Forms.Label labTUSO2;
        private System.Windows.Forms.Label labTUSO1;
        private System.Windows.Forms.Label labE6;
        private System.Windows.Forms.Label labE5;
        private System.Windows.Forms.Label labE4;
        private System.Windows.Forms.Label labE3;
        private System.Windows.Forms.Label labE2;
        private System.Windows.Forms.Label labE1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button butP1;
        private System.Windows.Forms.Button butP2;
        private System.Windows.Forms.Button butP3;
        private System.Windows.Forms.Button butP4;
        private System.Windows.Forms.Button butP5;
        private System.Windows.Forms.Button butP6;
        private System.Windows.Forms.ListBox listP;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label labTotalPagar;
        private System.Windows.Forms.Label labCHO;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Timer Reloj1;
        private System.Windows.Forms.Timer Reloj2;
        private System.Windows.Forms.Timer Reloj3;
        private System.Windows.Forms.Timer Reloj4;
        private System.Windows.Forms.Timer Reloj5;
        private System.Windows.Forms.Timer Reloj6;
        private System.Windows.Forms.Timer timer7;
    }
}

