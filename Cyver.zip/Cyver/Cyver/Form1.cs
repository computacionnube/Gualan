﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Cyver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            butP1.Enabled = false;
            butP2.Enabled = false;
        }
        //Maquina 1
        int dd1;                       
        int ss1;
        int mm1;
        int hh1 = 0;
        string ht, mt, st;
        int hb, mb, sb;
        int cts1 = 5;
        int dol1;
        int v1;
        int vd1;
        private void Reloj1_Tick(object sender, EventArgs e)
        {
            nudHoras.Value = Convert.ToDecimal(hh1);
            nudMin.Value = Convert.ToDecimal(mm2);
           //Aumente
            dd1++;
            if (dd1==10)
            {
                dd1 = 0;
                ss1++;
            }
            if (ss1==60)
            {
                mm1++;
                ss1 = 0;
                
            }
            if (mm1==60)
            {
                hh1++;
                mm1 = 0;
            }
            
            if (hh1<10)
            {
                ht = "0" + Convert.ToString(hh1);

            }
            else
            {
                ht = Convert.ToString(hh1);

            }
            if (mm1<10)
            {
                mt = "0" + Convert.ToString(mm1);
            }
            else
            {
                mt = Convert.ToString(mm1);
            }
            if (ss1<10)
            {
                st = "0" + Convert.ToString(ss1);
            }
            else
            {
                st = Convert.ToString(ss1);
            }

            labTUSO1.Text = ht + ":" + mt + ":" + st;
            
            //Decrese
        
            sb--;
            if (sb <= 0)
            {
                if (mb > 0)
                {
                    mb--;
                    sb = 59;
                }


            }
            if (mb == 0)
            {
                if (hb > 0)
                {
                    hb--;
                    mb = 59;
                }
            }
           
            if (sb == 0 && mb == 0 && hb == 0)
            {

                Reloj1.Stop();
                MessageBox.Show("Termino el tiempo", "Bomba", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            labTF1.Text = hb + ":" + mb + ":" + "00";
            //Para cobrar
            double tS;
            dd1++;
            if (dd1 == 10)
            {

                ss1++;
                dd1 = 0;


                if (ss1 == 60)
                {


                    ss1 = 0;

                    if (mm1++ % 1 == 0 && mm1 != 1)
                    {

                        cts1 += 5;


                    }
                    if (cts1 == 100)
                    {
                        cts1 = 0;
                        dol1++;

                    }


                }
                if (mm1 == 60)
                {
                    hh1++;
                    mm1 = 0;
                }


            }

            v1 = cts1;
            vd1 = dol1;
            if (cts1 <= 99)
            {
                labTC1.Text = hh1.ToString("00") + ":" + mm1.ToString("00") + ":" + ss1.ToString("00 \n") +
     "Valor  " + dol1.ToString("$ 00") + "." + cts1.ToString("00");
            }
            else
            {

                tS = v1 + dol1 * 0.10;
                labTC1.Text = hh1.ToString("00") + ":" + mm1.ToString("00") + ":" + ss1.ToString("00 \n") +
    "Valor  " + tS.ToString("$ ") + "." + "" + "dolar";

            }
        }

        private void but1_Click(object sender, EventArgs e)
        {
            mb = Convert.ToInt32(nudMin.Value);
            hb = Convert.ToInt32(nudHoras.Value);
            nudHoras.Value = Convert.ToUInt32(mb);
            nudMin.Value = Convert.ToUInt32(hb);
            labTT1.Text = hb + ":" + mb + ":" + ":"+ss1;
        
            Reloj1.Start();
            butP1.Enabled = true;
            if (Reloj1.Enabled==true)
            {
                labE1.Text = "OCUPADO";
            }
        }

        private void butP1_Click(object sender, EventArgs e)
        {
            Reloj1.Stop();
            if (Reloj1.Enabled == false)
            {
                labE1.Text = "LIBRE";
            }
        }
        //Maquina 2
        int dd2;
        int ss2;
        int mm2;
        int hh2 = 0;

        private void Reloj2_Tick(object sender, EventArgs e)
        {
            string ht2, mt2, st2;
            dd2++;
            if (dd2 == 10)
            {
                dd2 = 0;
                ss2++;
            }
            if (ss2 == 60)
            {
                mm2++;
                ss2 = 0;

            }
            if (mm2 == 60)
            {
                hh2++;
                mm2 = 0;
            }
            if (hh2 < 10)
            {
                ht2 = "0" + Convert.ToString(hh2);

            }
            else
            {
                ht2 = Convert.ToString(hh2);

            }
            if (mm2 < 10)
            {
                mt2 = "0" + Convert.ToString(mm2);
            }
            else
            {
                mt2 = Convert.ToString(mm2);
            }
            if (ss2 < 10)
            {
                st2 = "0" + Convert.ToString(ss2);
            }
            else
            {
                st2 = Convert.ToString(ss1);
            }
            labTUSO2.Text = ht2 + ":" + mt2 + ":" + st2;
        }

        private void but2_Click(object sender, EventArgs e)
        {
            Reloj2.Start();
            butP2.Enabled = true;
        }

        private void butP2_Click(object sender, EventArgs e)
        {
            Reloj2.Stop();
        }

     
    }
}
