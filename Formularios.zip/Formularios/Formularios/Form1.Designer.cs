﻿namespace Formularios
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.butejer1 = new System.Windows.Forms.Button();
            this.butejer2 = new System.Windows.Forms.Button();
            this.butejer3 = new System.Windows.Forms.Button();
            this.butejer4 = new System.Windows.Forms.Button();
            this.butsalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butejer1
            // 
            this.butejer1.Location = new System.Drawing.Point(22, 32);
            this.butejer1.Name = "butejer1";
            this.butejer1.Size = new System.Drawing.Size(75, 23);
            this.butejer1.TabIndex = 0;
            this.butejer1.Text = "Ejercicio1";
            this.butejer1.UseVisualStyleBackColor = true;
            this.butejer1.Click += new System.EventHandler(this.butejer1_Click);
            // 
            // butejer2
            // 
            this.butejer2.Location = new System.Drawing.Point(188, 32);
            this.butejer2.Name = "butejer2";
            this.butejer2.Size = new System.Drawing.Size(75, 23);
            this.butejer2.TabIndex = 1;
            this.butejer2.Text = "Ejercicio2";
            this.butejer2.UseVisualStyleBackColor = true;
            this.butejer2.Click += new System.EventHandler(this.butejer2_Click);
            // 
            // butejer3
            // 
            this.butejer3.Location = new System.Drawing.Point(188, 75);
            this.butejer3.Name = "butejer3";
            this.butejer3.Size = new System.Drawing.Size(75, 23);
            this.butejer3.TabIndex = 2;
            this.butejer3.Text = "Ejercicio3";
            this.butejer3.UseVisualStyleBackColor = true;
            this.butejer3.Click += new System.EventHandler(this.butejer3_Click);
            // 
            // butejer4
            // 
            this.butejer4.Location = new System.Drawing.Point(22, 75);
            this.butejer4.Name = "butejer4";
            this.butejer4.Size = new System.Drawing.Size(75, 23);
            this.butejer4.TabIndex = 3;
            this.butejer4.Text = "Ejercicio4";
            this.butejer4.UseVisualStyleBackColor = true;
            this.butejer4.Click += new System.EventHandler(this.butejer4_Click);
            // 
            // butsalir
            // 
            this.butsalir.Location = new System.Drawing.Point(107, 114);
            this.butsalir.Name = "butsalir";
            this.butsalir.Size = new System.Drawing.Size(75, 23);
            this.butsalir.TabIndex = 4;
            this.butsalir.Text = "Salir";
            this.butsalir.UseVisualStyleBackColor = true;
            this.butsalir.Click += new System.EventHandler(this.butsalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 262);
            this.Controls.Add(this.butsalir);
            this.Controls.Add(this.butejer4);
            this.Controls.Add(this.butejer3);
            this.Controls.Add(this.butejer2);
            this.Controls.Add(this.butejer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butejer1;
        private System.Windows.Forms.Button butejer2;
        private System.Windows.Forms.Button butejer3;
        private System.Windows.Forms.Button butejer4;
        private System.Windows.Forms.Button butsalir;
    }
}

