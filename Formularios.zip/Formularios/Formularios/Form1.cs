﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Formularios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void butsalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void butejer1_Click(object sender, EventArgs e)
        {
            frmEjercicio1 obEjerci1 = new frmEjercicio1();
            obEjerci1.Text = "Ejercicio de Arreglos";
            obEjerci1.MaximizeBox = false;
            obEjerci1.Show();
        }

        private void butejer2_Click(object sender, EventArgs e)
        {
            frmEjercicio2 obEjerci2 = new frmEjercicio2();
            obEjerci2.Text = "Formulario Maximizado";
            obEjerci2.WindowState = FormWindowState.Maximized;                              
            obEjerci2.Show();
        }

        private void butejer3_Click(object sender, EventArgs e)
        {
            frmEjercicio3 obEjerci3 = new frmEjercicio3();
            this.Hide();
            obEjerci3.ShowDialog();
            this.Visible = true;

        }

        private void butejer4_Click(object sender, EventArgs e)
        {
            frmEjercicio4 obEjerci4 = new frmEjercicio4();
            obEjerci4.ShowDialog();
        }
    }
}
