﻿namespace Formularios
{
    partial class frmEjercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butcerrar1 = new System.Windows.Forms.Button();
            this.textlimite1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listPrimos = new System.Windows.Forms.ListBox();
            this.butgenerar = new System.Windows.Forms.Button();
            this.butLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butcerrar1
            // 
            this.butcerrar1.Location = new System.Drawing.Point(206, 239);
            this.butcerrar1.Name = "butcerrar1";
            this.butcerrar1.Size = new System.Drawing.Size(75, 23);
            this.butcerrar1.TabIndex = 0;
            this.butcerrar1.Text = "Cerrar";
            this.butcerrar1.UseVisualStyleBackColor = true;
            this.butcerrar1.Click += new System.EventHandler(this.butcerrar1_Click);
            // 
            // textlimite1
            // 
            this.textlimite1.Location = new System.Drawing.Point(58, 26);
            this.textlimite1.Name = "textlimite1";
            this.textlimite1.Size = new System.Drawing.Size(100, 20);
            this.textlimite1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Limite:";
            // 
            // listPrimos
            // 
            this.listPrimos.FormattingEnabled = true;
            this.listPrimos.Location = new System.Drawing.Point(58, 77);
            this.listPrimos.Name = "listPrimos";
            this.listPrimos.Size = new System.Drawing.Size(120, 173);
            this.listPrimos.TabIndex = 3;
            // 
            // butgenerar
            // 
            this.butgenerar.Location = new System.Drawing.Point(197, 22);
            this.butgenerar.Name = "butgenerar";
            this.butgenerar.Size = new System.Drawing.Size(75, 23);
            this.butgenerar.TabIndex = 4;
            this.butgenerar.Text = "Generar";
            this.butgenerar.UseVisualStyleBackColor = true;
            this.butgenerar.Click += new System.EventHandler(this.butgenerar_Click);
            // 
            // butLimpiar
            // 
            this.butLimpiar.Location = new System.Drawing.Point(197, 66);
            this.butLimpiar.Name = "butLimpiar";
            this.butLimpiar.Size = new System.Drawing.Size(75, 23);
            this.butLimpiar.TabIndex = 5;
            this.butLimpiar.Text = "Limpiar";
            this.butLimpiar.UseVisualStyleBackColor = true;
            this.butLimpiar.Click += new System.EventHandler(this.butLimpiar_Click_1);
            // 
            // frmEjercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.butLimpiar);
            this.Controls.Add(this.butgenerar);
            this.Controls.Add(this.listPrimos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textlimite1);
            this.Controls.Add(this.butcerrar1);
            this.Name = "frmEjercicio1";
            this.Text = "frmEjercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butcerrar1;
        private System.Windows.Forms.TextBox textlimite1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listPrimos;
        private System.Windows.Forms.Button butgenerar;
        private System.Windows.Forms.Button butLimpiar;
    }
}