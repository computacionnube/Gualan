﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Formularios
{
    public partial class frmEjercicio1 : Form
    {
        public frmEjercicio1()
        {
            InitializeComponent();
        }
        bool banderta = true;
        int primo=1;
        int lim;
        private void butcerrar1_Click(object sender, EventArgs e)
        {
            Form1.ActiveForm.Show();
            this.Close();
        }
        private void Primos()
        {
           
                lim = Convert.ToInt32(textlimite1.Text);
                for (int i = 0; i < lim; i++)
                {
                    banderta = false;
                    while (banderta == false)
                    {
                        int divi = 2;
                        while (primo >= divi && primo % divi != 0)
                        {
                            divi++;
                        }
                        if (primo <= divi)
                        {
                            banderta = true;
                        }
                        else
                        {
                            primo = primo + 1;
                        }
                    }
                    listPrimos.Items.Add(primo);
                    primo = primo + 1;
                }
            
            
            
        }

        private void butgenerar_Click(object sender, EventArgs e)
        {
            if (textlimite1.Text == "")
            {
                listPrimos.Items.Clear();
                
            }
            else
            {
                this.Primos();
            }
        }

       private void butLimpiar_Click_1(object sender, EventArgs e)
       {
           textlimite1.Text = "";
           listPrimos.Items.Clear();
       }
       
        
    }
}
