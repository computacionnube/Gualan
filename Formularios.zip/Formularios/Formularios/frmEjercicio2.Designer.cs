﻿namespace Formularios
{
    partial class frmEjercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEjercicio2));
            this.butcerrar2 = new System.Windows.Forms.Button();
            this.listimagen = new System.Windows.Forms.ImageList(this.components);
            this.RelogPantalla = new System.Windows.Forms.Timer(this.components);
            this.Pantalla = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla)).BeginInit();
            this.SuspendLayout();
            // 
            // butcerrar2
            // 
            this.butcerrar2.Location = new System.Drawing.Point(207, 238);
            this.butcerrar2.Name = "butcerrar2";
            this.butcerrar2.Size = new System.Drawing.Size(75, 23);
            this.butcerrar2.TabIndex = 0;
            this.butcerrar2.Text = "Cerrar";
            this.butcerrar2.UseVisualStyleBackColor = true;
            this.butcerrar2.Click += new System.EventHandler(this.butcerrar2_Click);
            // 
            // listimagen
            // 
            this.listimagen.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("listimagen.ImageStream")));
            this.listimagen.TransparentColor = System.Drawing.Color.Transparent;
            this.listimagen.Images.SetKeyName(0, "1");
            this.listimagen.Images.SetKeyName(1, "2");
            this.listimagen.Images.SetKeyName(2, "3");
            this.listimagen.Images.SetKeyName(3, "4");
            this.listimagen.Images.SetKeyName(4, "5");
            this.listimagen.Images.SetKeyName(5, "6");
            this.listimagen.Images.SetKeyName(6, "7");
            this.listimagen.Images.SetKeyName(7, "8");
            this.listimagen.Images.SetKeyName(8, "9");
            this.listimagen.Images.SetKeyName(9, "10");
            this.listimagen.Images.SetKeyName(10, "11");
            // 
            // RelogPantalla
            // 
            this.RelogPantalla.Enabled = true;
            this.RelogPantalla.Interval = 1000;
            this.RelogPantalla.Tick += new System.EventHandler(this.RelogPantalla_Tick);
            // 
            // Pantalla
            // 
            this.Pantalla.Location = new System.Drawing.Point(12, 69);
            this.Pantalla.Name = "Pantalla";
            this.Pantalla.Size = new System.Drawing.Size(210, 136);
            this.Pantalla.TabIndex = 1;
            this.Pantalla.TabStop = false;
            // 
            // frmEjercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.Pantalla);
            this.Controls.Add(this.butcerrar2);
            this.Name = "frmEjercicio2";
            this.Text = "frmEjercicio2";
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butcerrar2;
        private System.Windows.Forms.ImageList listimagen;
        private System.Windows.Forms.Timer RelogPantalla;
        private System.Windows.Forms.PictureBox Pantalla;
    }
}