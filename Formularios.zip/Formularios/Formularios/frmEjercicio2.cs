﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Formularios
{
    public partial class frmEjercicio2 : Form
    {
        public frmEjercicio2()
        {
            InitializeComponent();
        }
        int imag = 0;
        private void butcerrar2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RelogPantalla_Tick(object sender, EventArgs e)
        {
            Pantalla.Image = listimagen.Images[imag];
            imag++;
            if (imag==11)
            {
                imag = 0;
            }
        }
    }
}
