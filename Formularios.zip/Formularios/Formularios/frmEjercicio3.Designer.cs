﻿namespace Formularios
{
    partial class frmEjercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butcerrar3 = new System.Windows.Forms.Button();
            this.listA = new System.Windows.Forms.ListBox();
            this.listB = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textlim = new System.Windows.Forms.TextBox();
            this.butA = new System.Windows.Forms.Button();
            this.butB = new System.Windows.Forms.Button();
            this.but1 = new System.Windows.Forms.Button();
            this.but2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butcerrar3
            // 
            this.butcerrar3.Location = new System.Drawing.Point(236, 238);
            this.butcerrar3.Name = "butcerrar3";
            this.butcerrar3.Size = new System.Drawing.Size(46, 23);
            this.butcerrar3.TabIndex = 0;
            this.butcerrar3.Text = "Cerrar";
            this.butcerrar3.UseVisualStyleBackColor = true;
            this.butcerrar3.Click += new System.EventHandler(this.butcerrar3_Click);
            // 
            // listA
            // 
            this.listA.FormattingEnabled = true;
            this.listA.Location = new System.Drawing.Point(12, 77);
            this.listA.Name = "listA";
            this.listA.Size = new System.Drawing.Size(80, 173);
            this.listA.TabIndex = 1;
            // 
            // listB
            // 
            this.listB.FormattingEnabled = true;
            this.listB.Location = new System.Drawing.Point(147, 77);
            this.listB.Name = "listB";
            this.listB.Size = new System.Drawing.Size(83, 173);
            this.listB.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Agregue:";
            // 
            // textlim
            // 
            this.textlim.Location = new System.Drawing.Point(70, 23);
            this.textlim.Name = "textlim";
            this.textlim.Size = new System.Drawing.Size(100, 20);
            this.textlim.TabIndex = 4;
            this.textlim.TextChanged += new System.EventHandler(this.text_TextChanged);
            // 
            // butA
            // 
            this.butA.Location = new System.Drawing.Point(207, 20);
            this.butA.Name = "butA";
            this.butA.Size = new System.Drawing.Size(75, 23);
            this.butA.TabIndex = 5;
            this.butA.Text = "A";
            this.butA.UseVisualStyleBackColor = true;
            this.butA.Click += new System.EventHandler(this.butA_Click);
            // 
            // butB
            // 
            this.butB.Location = new System.Drawing.Point(207, 50);
            this.butB.Name = "butB";
            this.butB.Size = new System.Drawing.Size(75, 23);
            this.butB.TabIndex = 6;
            this.butB.Text = "B";
            this.butB.UseVisualStyleBackColor = true;
            this.butB.Click += new System.EventHandler(this.butB_Click);
            // 
            // but1
            // 
            this.but1.Location = new System.Drawing.Point(108, 117);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(33, 35);
            this.but1.TabIndex = 7;
            this.but1.Text = "<";
            this.but1.UseVisualStyleBackColor = true;
            this.but1.Click += new System.EventHandler(this.but1_Click);
            // 
            // but2
            // 
            this.but2.Location = new System.Drawing.Point(108, 158);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(33, 35);
            this.but2.TabIndex = 8;
            this.but2.Text = ">";
            this.but2.UseVisualStyleBackColor = true;
            // 
            // frmEjercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.but2);
            this.Controls.Add(this.but1);
            this.Controls.Add(this.butB);
            this.Controls.Add(this.butA);
            this.Controls.Add(this.textlim);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listB);
            this.Controls.Add(this.listA);
            this.Controls.Add(this.butcerrar3);
            this.Name = "frmEjercicio3";
            this.Text = "frmEjercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butcerrar3;
        private System.Windows.Forms.ListBox listA;
        private System.Windows.Forms.ListBox listB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textlim;
        private System.Windows.Forms.Button butA;
        private System.Windows.Forms.Button butB;
        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.Button but2;
    }
}