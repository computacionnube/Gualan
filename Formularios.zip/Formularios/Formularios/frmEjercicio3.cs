﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Formularios
{
    struct Contactos
    {
        string A;
        string B;
        public Contactos(string a,string b)
        {
            A=a;
            B=b;
        }
        public void setA (string a)
        {
            A=a;
        }
        public string getA()
        {
            return A;
        }
        public void setB(string b)
        {
            B=b;
        }
        public string get()
        {
            return B;
        }
        
    }
    public partial class frmEjercicio3 : Form
    {
        public frmEjercicio3()
        {
            InitializeComponent();
           
            Contactos[] cont = new Contactos[lim];
        }
        

        Random alv = new Random();
        int lim;
        int pos=0;
        
        int pe=0;
        
        
        string estado = "";
   

        private void butcerrar3_Click(object sender, EventArgs e)
        {
            frmEjercicio3.ActiveForm.Close();
        }



        private void text_TextChanged(object sender, EventArgs e)
        {

        }
        private void GenerarA()
        {
            lim = Convert.ToInt32(textlim.Text);
          
            for (int i = 0; i < lim; i++)
            {
               alv.Next(1, 6);
               listA.Items.Add(i);
            }
           
        }
        private void GenerarB()
        {
            lim = Convert.ToInt32(textlim.Text);

            for (int i = 0; i < lim; i++)
            {
               alv.Next(1, 6);
                listB.Items.Add(i);
            }
           
        }
        private void llenar(int i)
        {
            
        }
        private void butA_Click(object sender, EventArgs e)
        {
            this.GenerarA();
        }

        private void butB_Click(object sender, EventArgs e)
        {
            this.GenerarB();
        }

        private void but1_Click(object sender, EventArgs e)
        {
           

        }
    }
}
