﻿namespace Formularios
{
    partial class frmEjercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butcerrar4 = new System.Windows.Forms.Button();
            this.butpresenta = new System.Windows.Forms.Button();
            this.butrepite = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butcerrar4
            // 
            this.butcerrar4.Location = new System.Drawing.Point(208, 237);
            this.butcerrar4.Name = "butcerrar4";
            this.butcerrar4.Size = new System.Drawing.Size(75, 23);
            this.butcerrar4.TabIndex = 0;
            this.butcerrar4.Text = "Cerrar";
            this.butcerrar4.UseVisualStyleBackColor = true;
            this.butcerrar4.Click += new System.EventHandler(this.butcerrar4_Click);
            // 
            // butpresenta
            // 
            this.butpresenta.Location = new System.Drawing.Point(13, 13);
            this.butpresenta.Name = "butpresenta";
            this.butpresenta.Size = new System.Drawing.Size(75, 23);
            this.butpresenta.TabIndex = 1;
            this.butpresenta.Text = "Presenta";
            this.butpresenta.UseVisualStyleBackColor = true;
            this.butpresenta.Click += new System.EventHandler(this.butpresenta_Click);
            // 
            // butrepite
            // 
            this.butrepite.Location = new System.Drawing.Point(134, 12);
            this.butrepite.Name = "butrepite";
            this.butrepite.Size = new System.Drawing.Size(75, 23);
            this.butrepite.TabIndex = 2;
            this.butrepite.Text = "Repite";
            this.butrepite.UseVisualStyleBackColor = true;
            this.butrepite.Click += new System.EventHandler(this.butrepite_Click);
            // 
            // frmEjercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.butrepite);
            this.Controls.Add(this.butpresenta);
            this.Controls.Add(this.butcerrar4);
            this.Name = "frmEjercicio4";
            this.Text = "frmEjercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butcerrar4;
        private System.Windows.Forms.Button butpresenta;
        private System.Windows.Forms.Button butrepite;
    }
}