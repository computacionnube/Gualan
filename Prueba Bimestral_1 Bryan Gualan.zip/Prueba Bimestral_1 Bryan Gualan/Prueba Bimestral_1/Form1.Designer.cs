﻿namespace Prueba_Bimestral_1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textApellido = new System.Windows.Forms.TextBox();
            this.textcomparar = new System.Windows.Forms.TextBox();
            this.textNombre = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radbdenegado = new System.Windows.Forms.RadioButton();
            this.radbexpedido = new System.Windows.Forms.RadioButton();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.textdivisiondevisado = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radbotros45 = new System.Windows.Forms.RadioButton();
            this.radbsegumedico = new System.Windows.Forms.RadioButton();
            this.radbtranspor = new System.Windows.Forms.RadioButton();
            this.radbmedio = new System.Windows.Forms.RadioButton();
            this.radbdocumen = new System.Windows.Forms.RadioButton();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.textnombreexpedido = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.radbotros2 = new System.Windows.Forms.RadioButton();
            this.label51 = new System.Windows.Forms.Label();
            this.textnombrepequeñi = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textnumerosolicitud = new System.Windows.Forms.TextBox();
            this.textfechasolicitud = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radbfrontera = new System.Windows.Forms.RadioButton();
            this.radbinterme = new System.Windows.Forms.RadioButton();
            this.radbprovedor = new System.Windows.Forms.RadioButton();
            this.radbccs = new System.Windows.Forms.RadioButton();
            this.radbemba = new System.Windows.Forms.RadioButton();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textaño = new System.Windows.Forms.TextBox();
            this.textmes = new System.Windows.Forms.TextBox();
            this.textdia = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cobpais = new System.Windows.Forms.ComboBox();
            this.cobnacimiento = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labsino = new System.Windows.Forms.Label();
            this.textNacionalidadactual = new System.Windows.Forms.TextBox();
            this.labLugarNac = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.grpsexo = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.radBF = new System.Windows.Forms.RadioButton();
            this.radBM = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textespecifique = new System.Windows.Forms.TextBox();
            this.radBotros = new System.Windows.Forms.RadioButton();
            this.label22 = new System.Windows.Forms.Label();
            this.radBCasado = new System.Windows.Forms.RadioButton();
            this.radBviudo = new System.Windows.Forms.RadioButton();
            this.radBDivorciado = new System.Windows.Forms.RadioButton();
            this.radBSoltero = new System.Windows.Forms.RadioButton();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textDirecT = new System.Windows.Forms.TextBox();
            this.textnomA = new System.Windows.Forms.TextBox();
            this.textnomT = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.radBno = new System.Windows.Forms.RadioButton();
            this.radBsi = new System.Windows.Forms.RadioButton();
            this.label23 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textcedula = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radBPasaOficial = new System.Windows.Forms.RadioButton();
            this.textespecifiqueviaje = new System.Windows.Forms.TextBox();
            this.radBPasaOtro = new System.Windows.Forms.RadioButton();
            this.radBPasaespeci = new System.Windows.Forms.RadioButton();
            this.radBPasadiplo = new System.Windows.Forms.RadioButton();
            this.radBPasaSer = new System.Windows.Forms.RadioButton();
            this.radBPasaO = new System.Windows.Forms.RadioButton();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.textnumerodeviaje = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.textfechaexpedicion = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textespedido = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.textCorreo = new System.Windows.Forms.TextBox();
            this.textresidente = new System.Windows.Forms.TextBox();
            this.textDomicilioP = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.texttelefono = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.dataregistro = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apellidos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FechaN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.luga = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pais = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sexo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tutor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Numde = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tipode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feclalim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Valido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Expedido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Domicilio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Numeros = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.butagregar = new System.Windows.Forms.Button();
            this.butnuevo = new System.Windows.Forms.Button();
            this.buteditar = new System.Windows.Forms.Button();
            this.buteliminar = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.textvalido = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.butus = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.grpsexo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataregistro)).BeginInit();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(33, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 134);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(254, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Solicitud de Visado";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(119, 134);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textApellido);
            this.panel1.Controls.Add(this.textcomparar);
            this.panel1.Controls.Add(this.textNombre);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(3, 213);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(672, 127);
            this.panel1.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(664, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = resources.GetString("label6.Text");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(664, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = resources.GetString("label5.Text");
            // 
            // textApellido
            // 
            this.textApellido.Location = new System.Drawing.Point(284, 95);
            this.textApellido.Name = "textApellido";
            this.textApellido.Size = new System.Drawing.Size(254, 20);
            this.textApellido.TabIndex = 5;
            this.textApellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textApellido_KeyPress);
            // 
            // textcomparar
            // 
            this.textcomparar.Location = new System.Drawing.Point(284, 47);
            this.textcomparar.Name = "textcomparar";
            this.textcomparar.Size = new System.Drawing.Size(368, 20);
            this.textcomparar.TabIndex = 4;
            this.textcomparar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textcomparar_KeyPress);
            // 
            // textNombre
            // 
            this.textNombre.Location = new System.Drawing.Point(284, 11);
            this.textNombre.Name = "textNombre";
            this.textNombre.Size = new System.Drawing.Size(254, 20);
            this.textNombre.TabIndex = 3;
            this.textNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNombre_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "3 Apellido";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(249, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "2 Apellido(s) de nacimiento (apellidos(s) anterior(es))";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "1 Nombre";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.groupBox4);
            this.panel2.Controls.Add(this.textdivisiondevisado);
            this.panel2.Controls.Add(this.label58);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.textnombreexpedido);
            this.panel2.Controls.Add(this.label52);
            this.panel2.Controls.Add(this.radbotros2);
            this.panel2.Controls.Add(this.label51);
            this.panel2.Controls.Add(this.textnombrepequeñi);
            this.panel2.Controls.Add(this.label50);
            this.panel2.Controls.Add(this.textnumerosolicitud);
            this.panel2.Controls.Add(this.textfechasolicitud);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.label44);
            this.panel2.Controls.Add(this.label43);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(1354, 124);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(238, 667);
            this.panel2.TabIndex = 4;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radbdenegado);
            this.groupBox4.Controls.Add(this.radbexpedido);
            this.groupBox4.Controls.Add(this.label60);
            this.groupBox4.Controls.Add(this.label59);
            this.groupBox4.Location = new System.Drawing.Point(10, 607);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(236, 54);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "groupBox4";
            // 
            // radbdenegado
            // 
            this.radbdenegado.AutoSize = true;
            this.radbdenegado.Location = new System.Drawing.Point(154, 32);
            this.radbdenegado.Name = "radbdenegado";
            this.radbdenegado.Size = new System.Drawing.Size(14, 13);
            this.radbdenegado.TabIndex = 3;
            this.radbdenegado.TabStop = true;
            this.radbdenegado.UseVisualStyleBackColor = true;
            // 
            // radbexpedido
            // 
            this.radbexpedido.AutoSize = true;
            this.radbexpedido.Location = new System.Drawing.Point(50, 32);
            this.radbexpedido.Name = "radbexpedido";
            this.radbexpedido.Size = new System.Drawing.Size(14, 13);
            this.radbexpedido.TabIndex = 2;
            this.radbexpedido.TabStop = true;
            this.radbexpedido.UseVisualStyleBackColor = true;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(27, 16);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(51, 13);
            this.label60.TabIndex = 1;
            this.label60.Text = "Expedido";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(138, 16);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(57, 13);
            this.label59.TabIndex = 0;
            this.label59.Text = "Denegado";
            // 
            // textdivisiondevisado
            // 
            this.textdivisiondevisado.Location = new System.Drawing.Point(113, 581);
            this.textdivisiondevisado.Name = "textdivisiondevisado";
            this.textdivisiondevisado.Size = new System.Drawing.Size(118, 20);
            this.textdivisiondevisado.TabIndex = 16;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(7, 581);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(93, 13);
            this.label58.TabIndex = 15;
            this.label58.Text = "Division de visado";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radbotros45);
            this.groupBox3.Controls.Add(this.radbsegumedico);
            this.groupBox3.Controls.Add(this.radbtranspor);
            this.groupBox3.Controls.Add(this.radbmedio);
            this.groupBox3.Controls.Add(this.radbdocumen);
            this.groupBox3.Controls.Add(this.label57);
            this.groupBox3.Controls.Add(this.label56);
            this.groupBox3.Controls.Add(this.label55);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.label53);
            this.groupBox3.Location = new System.Drawing.Point(6, 457);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(240, 110);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Documentos presentados ";
            // 
            // radbotros45
            // 
            this.radbotros45.AutoSize = true;
            this.radbotros45.Location = new System.Drawing.Point(201, 20);
            this.radbotros45.Name = "radbotros45";
            this.radbotros45.Size = new System.Drawing.Size(14, 13);
            this.radbotros45.TabIndex = 9;
            this.radbotros45.TabStop = true;
            this.radbotros45.UseVisualStyleBackColor = true;
            // 
            // radbsegumedico
            // 
            this.radbsegumedico.AutoSize = true;
            this.radbsegumedico.Location = new System.Drawing.Point(185, 72);
            this.radbsegumedico.Name = "radbsegumedico";
            this.radbsegumedico.Size = new System.Drawing.Size(14, 13);
            this.radbsegumedico.TabIndex = 8;
            this.radbsegumedico.TabStop = true;
            this.radbsegumedico.UseVisualStyleBackColor = true;
            // 
            // radbtranspor
            // 
            this.radbtranspor.AutoSize = true;
            this.radbtranspor.Location = new System.Drawing.Point(25, 85);
            this.radbtranspor.Name = "radbtranspor";
            this.radbtranspor.Size = new System.Drawing.Size(14, 13);
            this.radbtranspor.TabIndex = 7;
            this.radbtranspor.TabStop = true;
            this.radbtranspor.UseVisualStyleBackColor = true;
            // 
            // radbmedio
            // 
            this.radbmedio.AutoSize = true;
            this.radbmedio.Location = new System.Drawing.Point(25, 53);
            this.radbmedio.Name = "radbmedio";
            this.radbmedio.Size = new System.Drawing.Size(14, 13);
            this.radbmedio.TabIndex = 6;
            this.radbmedio.TabStop = true;
            this.radbmedio.UseVisualStyleBackColor = true;
            // 
            // radbdocumen
            // 
            this.radbdocumen.AutoSize = true;
            this.radbdocumen.Location = new System.Drawing.Point(25, 20);
            this.radbdocumen.Name = "radbdocumen";
            this.radbdocumen.Size = new System.Drawing.Size(14, 13);
            this.radbdocumen.TabIndex = 5;
            this.radbdocumen.TabStop = true;
            this.radbdocumen.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(142, 20);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(32, 13);
            this.label57.TabIndex = 4;
            this.label57.Text = "Otros";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(94, 72);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(81, 13);
            this.label56.TabIndex = 3;
            this.label56.Text = "Seguro medico ";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(55, 85);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(101, 13);
            this.label55.TabIndex = 2;
            this.label55.Text = "Medio de transporte";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(44, 53);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(112, 13);
            this.label54.TabIndex = 1;
            this.label54.Text = "Medio de subsistencia";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(44, 20);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(92, 13);
            this.label53.TabIndex = 0;
            this.label53.Text = "Documentos viaje";
            // 
            // textnombreexpedido
            // 
            this.textnombreexpedido.Location = new System.Drawing.Point(103, 417);
            this.textnombreexpedido.Name = "textnombreexpedido";
            this.textnombreexpedido.Size = new System.Drawing.Size(123, 20);
            this.textnombreexpedido.TabIndex = 13;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(16, 424);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(72, 13);
            this.label52.TabIndex = 12;
            this.label52.Text = "Expedido por:";
            // 
            // radbotros2
            // 
            this.radbotros2.AutoSize = true;
            this.radbotros2.Location = new System.Drawing.Point(81, 396);
            this.radbotros2.Name = "radbotros2";
            this.radbotros2.Size = new System.Drawing.Size(14, 13);
            this.radbotros2.TabIndex = 11;
            this.radbotros2.TabStop = true;
            this.radbotros2.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(19, 396);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(30, 13);
            this.label51.TabIndex = 10;
            this.label51.Text = "otros";
            // 
            // textnombrepequeñi
            // 
            this.textnombrepequeñi.Location = new System.Drawing.Point(81, 360);
            this.textnombrepequeñi.Name = "textnombrepequeñi";
            this.textnombrepequeñi.Size = new System.Drawing.Size(145, 20);
            this.textnombrepequeñi.TabIndex = 9;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(19, 364);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(44, 13);
            this.label50.TabIndex = 8;
            this.label50.Text = "Nombre";
            // 
            // textnumerosolicitud
            // 
            this.textnumerosolicitud.Location = new System.Drawing.Point(113, 191);
            this.textnumerosolicitud.Name = "textnumerosolicitud";
            this.textnumerosolicitud.Size = new System.Drawing.Size(125, 20);
            this.textnumerosolicitud.TabIndex = 7;
            // 
            // textfechasolicitud
            // 
            this.textfechasolicitud.Location = new System.Drawing.Point(113, 156);
            this.textfechasolicitud.Name = "textfechasolicitud";
            this.textfechasolicitud.Size = new System.Drawing.Size(125, 20);
            this.textfechasolicitud.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radbfrontera);
            this.groupBox2.Controls.Add(this.radbinterme);
            this.groupBox2.Controls.Add(this.radbprovedor);
            this.groupBox2.Controls.Add(this.radbccs);
            this.groupBox2.Controls.Add(this.radbemba);
            this.groupBox2.Controls.Add(this.label49);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Location = new System.Drawing.Point(10, 222);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(216, 134);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Solicitud presente en";
            // 
            // radbfrontera
            // 
            this.radbfrontera.AutoSize = true;
            this.radbfrontera.Location = new System.Drawing.Point(138, 108);
            this.radbfrontera.Name = "radbfrontera";
            this.radbfrontera.Size = new System.Drawing.Size(14, 13);
            this.radbfrontera.TabIndex = 9;
            this.radbfrontera.TabStop = true;
            this.radbfrontera.UseVisualStyleBackColor = true;
            // 
            // radbinterme
            // 
            this.radbinterme.AutoSize = true;
            this.radbinterme.Location = new System.Drawing.Point(138, 87);
            this.radbinterme.Name = "radbinterme";
            this.radbinterme.Size = new System.Drawing.Size(14, 13);
            this.radbinterme.TabIndex = 8;
            this.radbinterme.TabStop = true;
            this.radbinterme.UseVisualStyleBackColor = true;
            // 
            // radbprovedor
            // 
            this.radbprovedor.AutoSize = true;
            this.radbprovedor.Location = new System.Drawing.Point(138, 63);
            this.radbprovedor.Name = "radbprovedor";
            this.radbprovedor.Size = new System.Drawing.Size(14, 13);
            this.radbprovedor.TabIndex = 7;
            this.radbprovedor.TabStop = true;
            this.radbprovedor.UseVisualStyleBackColor = true;
            // 
            // radbccs
            // 
            this.radbccs.AutoSize = true;
            this.radbccs.Location = new System.Drawing.Point(138, 44);
            this.radbccs.Name = "radbccs";
            this.radbccs.Size = new System.Drawing.Size(14, 13);
            this.radbccs.TabIndex = 6;
            this.radbccs.TabStop = true;
            this.radbccs.UseVisualStyleBackColor = true;
            // 
            // radbemba
            // 
            this.radbemba.AutoSize = true;
            this.radbemba.Location = new System.Drawing.Point(138, 19);
            this.radbemba.Name = "radbemba";
            this.radbemba.Size = new System.Drawing.Size(14, 13);
            this.radbemba.TabIndex = 5;
            this.radbemba.TabStop = true;
            this.radbemba.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(7, 108);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(46, 13);
            this.label49.TabIndex = 4;
            this.label49.Text = "Frontera";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(7, 87);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(115, 13);
            this.label48.TabIndex = 3;
            this.label48.Text = "Intermediario comercial";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 66);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(109, 13);
            this.label47.TabIndex = 2;
            this.label47.Text = "Provedor de servicios";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(7, 44);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(28, 13);
            this.label46.TabIndex = 1;
            this.label46.Text = "CCS";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(7, 20);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(108, 13);
            this.label45.TabIndex = 0;
            this.label45.Text = "Embajada/consulado";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(3, 191);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(111, 13);
            this.label44.TabIndex = 4;
            this.label44.Text = "Numero de la solicitud";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(7, 159);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(93, 13);
            this.label43.TabIndex = 3;
            this.label43.Text = "Fecha de solicitud";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.textaño);
            this.panel3.Controls.Add(this.textmes);
            this.panel3.Controls.Add(this.textdia);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(3, 346);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(183, 121);
            this.panel3.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(133, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "AA";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(77, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "MM";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "DD";
            // 
            // textaño
            // 
            this.textaño.Location = new System.Drawing.Point(136, 71);
            this.textaño.Name = "textaño";
            this.textaño.Size = new System.Drawing.Size(22, 20);
            this.textaño.TabIndex = 3;
            // 
            // textmes
            // 
            this.textmes.Location = new System.Drawing.Point(80, 71);
            this.textmes.Name = "textmes";
            this.textmes.Size = new System.Drawing.Size(22, 20);
            this.textmes.TabIndex = 2;
            // 
            // textdia
            // 
            this.textdia.Location = new System.Drawing.Point(24, 71);
            this.textdia.Name = "textdia";
            this.textdia.Size = new System.Drawing.Size(22, 20);
            this.textdia.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "4 Fecha de nacimiento";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.cobpais);
            this.panel4.Controls.Add(this.cobnacimiento);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Location = new System.Drawing.Point(192, 346);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(236, 121);
            this.panel4.TabIndex = 6;
            // 
            // cobpais
            // 
            this.cobpais.FormattingEnabled = true;
            this.cobpais.Items.AddRange(new object[] {
            "Ecuador",
            "Colombia",
            "Peru",
            "Puerto Rico",
            "Estados Unidos"});
            this.cobpais.Location = new System.Drawing.Point(112, 63);
            this.cobpais.Name = "cobpais";
            this.cobpais.Size = new System.Drawing.Size(121, 21);
            this.cobpais.TabIndex = 3;
            this.cobpais.Text = "Pais";
            // 
            // cobnacimiento
            // 
            this.cobnacimiento.FormattingEnabled = true;
            this.cobnacimiento.Items.AddRange(new object[] {
            "Loja",
            "Pichincha",
            "Azuay",
            "Oro",
            "Guayaquil"});
            this.cobnacimiento.Location = new System.Drawing.Point(112, 11);
            this.cobnacimiento.Name = "cobnacimiento";
            this.cobnacimiento.Size = new System.Drawing.Size(121, 21);
            this.cobnacimiento.TabIndex = 2;
            this.cobnacimiento.Text = "Lugar";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "6 Pais Nacimiento";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "5 Lugar Nacimiento";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.labsino);
            this.panel5.Controls.Add(this.textNacionalidadactual);
            this.panel5.Controls.Add(this.labLugarNac);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Location = new System.Drawing.Point(434, 346);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(241, 121);
            this.panel5.TabIndex = 7;
            // 
            // labsino
            // 
            this.labsino.BackColor = System.Drawing.Color.White;
            this.labsino.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labsino.Location = new System.Drawing.Point(162, 73);
            this.labsino.Name = "labsino";
            this.labsino.Size = new System.Drawing.Size(65, 23);
            this.labsino.TabIndex = 5;
            // 
            // textNacionalidadactual
            // 
            this.textNacionalidadactual.Location = new System.Drawing.Point(127, 8);
            this.textNacionalidadactual.Name = "textNacionalidadactual";
            this.textNacionalidadactual.Size = new System.Drawing.Size(100, 20);
            this.textNacionalidadactual.TabIndex = 4;
            this.textNacionalidadactual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNacionalidadactual_KeyPress);
            // 
            // labLugarNac
            // 
            this.labLugarNac.BackColor = System.Drawing.Color.White;
            this.labLugarNac.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labLugarNac.Location = new System.Drawing.Point(162, 37);
            this.labLugarNac.Name = "labLugarNac";
            this.labLugarNac.Size = new System.Drawing.Size(65, 23);
            this.labLugarNac.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 87);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Diferente de actual";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 47);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(153, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Nacionalidad de nacimiento,Si ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "7 Nacionalida actual";
            // 
            // grpsexo
            // 
            this.grpsexo.Controls.Add(this.label17);
            this.grpsexo.Controls.Add(this.label16);
            this.grpsexo.Controls.Add(this.radBF);
            this.grpsexo.Controls.Add(this.radBM);
            this.grpsexo.Location = new System.Drawing.Point(3, 475);
            this.grpsexo.Name = "grpsexo";
            this.grpsexo.Size = new System.Drawing.Size(183, 100);
            this.grpsexo.TabIndex = 8;
            this.grpsexo.TabStop = false;
            this.grpsexo.Text = "8 Sexo";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(27, 59);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Femenino";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label16.Location = new System.Drawing.Point(24, 19);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 15);
            this.label16.TabIndex = 2;
            this.label16.Text = "Masculino";
            // 
            // radBF
            // 
            this.radBF.AutoSize = true;
            this.radBF.Location = new System.Drawing.Point(105, 59);
            this.radBF.Name = "radBF";
            this.radBF.Size = new System.Drawing.Size(31, 17);
            this.radBF.TabIndex = 1;
            this.radBF.TabStop = true;
            this.radBF.Text = "F";
            this.radBF.UseVisualStyleBackColor = true;
            // 
            // radBM
            // 
            this.radBM.AutoSize = true;
            this.radBM.Location = new System.Drawing.Point(105, 19);
            this.radBM.Name = "radBM";
            this.radBM.Size = new System.Drawing.Size(34, 17);
            this.radBM.TabIndex = 0;
            this.radBM.TabStop = true;
            this.radBM.Text = "M";
            this.radBM.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textespecifique);
            this.groupBox1.Controls.Add(this.radBotros);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.radBCasado);
            this.groupBox1.Controls.Add(this.radBviudo);
            this.groupBox1.Controls.Add(this.radBDivorciado);
            this.groupBox1.Controls.Add(this.radBSoltero);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Location = new System.Drawing.Point(198, 475);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(477, 100);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "9 Estado civil";
            // 
            // textespecifique
            // 
            this.textespecifique.Location = new System.Drawing.Point(339, 56);
            this.textespecifique.Name = "textespecifique";
            this.textespecifique.Size = new System.Drawing.Size(100, 20);
            this.textespecifique.TabIndex = 10;
            // 
            // radBotros
            // 
            this.radBotros.AutoSize = true;
            this.radBotros.Location = new System.Drawing.Point(213, 59);
            this.radBotros.Name = "radBotros";
            this.radBotros.Size = new System.Drawing.Size(14, 13);
            this.radBotros.TabIndex = 9;
            this.radBotros.TabStop = true;
            this.radBotros.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(248, 59);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 13);
            this.label22.TabIndex = 8;
            this.label22.Text = "Otros";
            // 
            // radBCasado
            // 
            this.radBCasado.AutoSize = true;
            this.radBCasado.Location = new System.Drawing.Point(106, 56);
            this.radBCasado.Name = "radBCasado";
            this.radBCasado.Size = new System.Drawing.Size(14, 13);
            this.radBCasado.TabIndex = 7;
            this.radBCasado.TabStop = true;
            this.radBCasado.UseVisualStyleBackColor = true;
            // 
            // radBviudo
            // 
            this.radBviudo.AutoSize = true;
            this.radBviudo.Location = new System.Drawing.Point(425, 19);
            this.radBviudo.Name = "radBviudo";
            this.radBviudo.Size = new System.Drawing.Size(14, 13);
            this.radBviudo.TabIndex = 6;
            this.radBviudo.TabStop = true;
            this.radBviudo.UseVisualStyleBackColor = true;
            // 
            // radBDivorciado
            // 
            this.radBDivorciado.AutoSize = true;
            this.radBDivorciado.Location = new System.Drawing.Point(251, 16);
            this.radBDivorciado.Name = "radBDivorciado";
            this.radBDivorciado.Size = new System.Drawing.Size(14, 13);
            this.radBDivorciado.TabIndex = 5;
            this.radBDivorciado.TabStop = true;
            this.radBDivorciado.UseVisualStyleBackColor = true;
            // 
            // radBSoltero
            // 
            this.radBSoltero.AutoSize = true;
            this.radBSoltero.Location = new System.Drawing.Point(106, 16);
            this.radBSoltero.Name = "radBSoltero";
            this.radBSoltero.Size = new System.Drawing.Size(14, 13);
            this.radBSoltero.TabIndex = 4;
            this.radBSoltero.TabStop = true;
            this.radBSoltero.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(360, 19);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Viudo/a";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(176, 16);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "Divorciado/a";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Casado/a";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(7, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Soltero/a";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.textDirecT);
            this.panel6.Controls.Add(this.textnomA);
            this.panel6.Controls.Add(this.textnomT);
            this.panel6.Controls.Add(this.label28);
            this.panel6.Controls.Add(this.label27);
            this.panel6.Controls.Add(this.label26);
            this.panel6.Controls.Add(this.label25);
            this.panel6.Controls.Add(this.label24);
            this.panel6.Controls.Add(this.radBno);
            this.panel6.Controls.Add(this.radBsi);
            this.panel6.Controls.Add(this.label23);
            this.panel6.Location = new System.Drawing.Point(3, 581);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(672, 100);
            this.panel6.TabIndex = 10;
            // 
            // textDirecT
            // 
            this.textDirecT.Location = new System.Drawing.Point(534, 26);
            this.textDirecT.Name = "textDirecT";
            this.textDirecT.Size = new System.Drawing.Size(118, 20);
            this.textDirecT.TabIndex = 10;
            // 
            // textnomA
            // 
            this.textnomA.Location = new System.Drawing.Point(301, 45);
            this.textnomA.Name = "textnomA";
            this.textnomA.Size = new System.Drawing.Size(139, 20);
            this.textnomA.TabIndex = 9;
            this.textnomA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textnomA_KeyPress);
            // 
            // textnomT
            // 
            this.textnomT.Location = new System.Drawing.Point(301, 13);
            this.textnomT.Name = "textnomT";
            this.textnomT.Size = new System.Drawing.Size(139, 20);
            this.textnomT.TabIndex = 8;
            this.textnomT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textnomT_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(463, 29);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(52, 13);
            this.label28.TabIndex = 7;
            this.label28.Text = "Direccion";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(189, 53);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(85, 13);
            this.label27.TabIndex = 6;
            this.label27.Text = "Apellido del tutor";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(189, 13);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(85, 13);
            this.label26.TabIndex = 5;
            this.label26.Text = "Nombre del tutor";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(82, 40);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(21, 13);
            this.label25.TabIndex = 4;
            this.label25.Text = "No";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 40);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(16, 13);
            this.label24.TabIndex = 3;
            this.label24.Text = "Si";
            // 
            // radBno
            // 
            this.radBno.AutoSize = true;
            this.radBno.Location = new System.Drawing.Point(122, 40);
            this.radBno.Name = "radBno";
            this.radBno.Size = new System.Drawing.Size(14, 13);
            this.radBno.TabIndex = 2;
            this.radBno.TabStop = true;
            this.radBno.UseVisualStyleBackColor = true;
            // 
            // radBsi
            // 
            this.radBsi.AutoSize = true;
            this.radBsi.Location = new System.Drawing.Point(46, 40);
            this.radBsi.Name = "radBsi";
            this.radBsi.Size = new System.Drawing.Size(14, 13);
            this.radBsi.TabIndex = 1;
            this.radBsi.TabStop = true;
            this.radBsi.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "10 Menor de edad";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Controls.Add(this.textcedula);
            this.panel7.Controls.Add(this.comboBox3);
            this.panel7.Controls.Add(this.label29);
            this.panel7.Location = new System.Drawing.Point(678, 213);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(318, 127);
            this.panel7.TabIndex = 11;
            // 
            // textcedula
            // 
            this.textcedula.Location = new System.Drawing.Point(32, 47);
            this.textcedula.Name = "textcedula";
            this.textcedula.Size = new System.Drawing.Size(257, 20);
            this.textcedula.TabIndex = 2;
            this.textcedula.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textcedula_KeyPress);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Cedula",
            "Ruc",
            "Pasaporte"});
            this.comboBox3.Location = new System.Drawing.Point(168, 8);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(29, 11);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(133, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "11 Numero de documento ";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel8.Controls.Add(this.radBPasaOficial);
            this.panel8.Controls.Add(this.textespecifiqueviaje);
            this.panel8.Controls.Add(this.radBPasaOtro);
            this.panel8.Controls.Add(this.radBPasaespeci);
            this.panel8.Controls.Add(this.radBPasadiplo);
            this.panel8.Controls.Add(this.radBPasaSer);
            this.panel8.Controls.Add(this.radBPasaO);
            this.panel8.Controls.Add(this.label36);
            this.panel8.Controls.Add(this.label35);
            this.panel8.Controls.Add(this.label34);
            this.panel8.Controls.Add(this.label33);
            this.panel8.Controls.Add(this.label32);
            this.panel8.Controls.Add(this.label31);
            this.panel8.Controls.Add(this.label30);
            this.panel8.Location = new System.Drawing.Point(1002, 213);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(346, 127);
            this.panel8.TabIndex = 12;
            // 
            // radBPasaOficial
            // 
            this.radBPasaOficial.AutoSize = true;
            this.radBPasaOficial.Location = new System.Drawing.Point(320, 98);
            this.radBPasaOficial.Name = "radBPasaOficial";
            this.radBPasaOficial.Size = new System.Drawing.Size(14, 13);
            this.radBPasaOficial.TabIndex = 13;
            this.radBPasaOficial.TabStop = true;
            this.radBPasaOficial.UseVisualStyleBackColor = true;
            // 
            // textespecifiqueviaje
            // 
            this.textespecifiqueviaje.Location = new System.Drawing.Point(87, 95);
            this.textespecifiqueviaje.Name = "textespecifiqueviaje";
            this.textespecifiqueviaje.Size = new System.Drawing.Size(100, 20);
            this.textespecifiqueviaje.TabIndex = 12;
            this.textespecifiqueviaje.Text = "Especifique";
            // 
            // radBPasaOtro
            // 
            this.radBPasaOtro.AutoSize = true;
            this.radBPasaOtro.Location = new System.Drawing.Point(52, 98);
            this.radBPasaOtro.Name = "radBPasaOtro";
            this.radBPasaOtro.Size = new System.Drawing.Size(14, 13);
            this.radBPasaOtro.TabIndex = 11;
            this.radBPasaOtro.TabStop = true;
            this.radBPasaOtro.UseVisualStyleBackColor = true;
            // 
            // radBPasaespeci
            // 
            this.radBPasaespeci.AutoSize = true;
            this.radBPasaespeci.Location = new System.Drawing.Point(309, 69);
            this.radBPasaespeci.Name = "radBPasaespeci";
            this.radBPasaespeci.Size = new System.Drawing.Size(14, 13);
            this.radBPasaespeci.TabIndex = 10;
            this.radBPasaespeci.TabStop = true;
            this.radBPasaespeci.UseVisualStyleBackColor = true;
            // 
            // radBPasadiplo
            // 
            this.radBPasadiplo.AutoSize = true;
            this.radBPasadiplo.Location = new System.Drawing.Point(309, 30);
            this.radBPasadiplo.Name = "radBPasadiplo";
            this.radBPasadiplo.Size = new System.Drawing.Size(14, 13);
            this.radBPasadiplo.TabIndex = 9;
            this.radBPasadiplo.TabStop = true;
            this.radBPasadiplo.UseVisualStyleBackColor = true;
            // 
            // radBPasaSer
            // 
            this.radBPasaSer.AutoSize = true;
            this.radBPasaSer.Location = new System.Drawing.Point(136, 69);
            this.radBPasaSer.Name = "radBPasaSer";
            this.radBPasaSer.Size = new System.Drawing.Size(14, 13);
            this.radBPasaSer.TabIndex = 8;
            this.radBPasaSer.TabStop = true;
            this.radBPasaSer.UseVisualStyleBackColor = true;
            // 
            // radBPasaO
            // 
            this.radBPasaO.AutoSize = true;
            this.radBPasaO.Location = new System.Drawing.Point(136, 30);
            this.radBPasaO.Name = "radBPasaO";
            this.radBPasaO.Size = new System.Drawing.Size(14, 13);
            this.radBPasaO.TabIndex = 7;
            this.radBPasaO.TabStop = true;
            this.radBPasaO.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(7, 102);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(27, 13);
            this.label36.TabIndex = 6;
            this.label36.Text = "Otro";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(176, 69);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(97, 13);
            this.label35.TabIndex = 5;
            this.label35.Text = "Pasaporte especial";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(218, 98);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(85, 13);
            this.label34.TabIndex = 4;
            this.label34.Text = "Pasaporte oficial";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(7, 69);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(109, 13);
            this.label33.TabIndex = 3;
            this.label33.Text = "Pasaporte de servicio";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(176, 30);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(111, 13);
            this.label32.TabIndex = 2;
            this.label32.Text = "Pasaporte diplomatico";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(7, 31);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(98, 13);
            this.label31.TabIndex = 1;
            this.label31.Text = "Pasaporte ordinario";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(3, 8);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(83, 13);
            this.label30.TabIndex = 0;
            this.label30.Text = "12 Tipo de viaje";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel9.Controls.Add(this.textnumerodeviaje);
            this.panel9.Controls.Add(this.label37);
            this.panel9.Location = new System.Drawing.Point(681, 346);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(208, 121);
            this.panel9.TabIndex = 13;
            // 
            // textnumerodeviaje
            // 
            this.textnumerodeviaje.Location = new System.Drawing.Point(17, 47);
            this.textnumerodeviaje.Name = "textnumerodeviaje";
            this.textnumerodeviaje.Size = new System.Drawing.Size(142, 20);
            this.textnumerodeviaje.TabIndex = 1;
            this.textnumerodeviaje.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textnumerodeviaje_KeyPress);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(11, 14);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(170, 13);
            this.label37.TabIndex = 0;
            this.label37.Text = "13 Numero de documento de viaje";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel10.Controls.Add(this.textfechaexpedicion);
            this.panel10.Controls.Add(this.label38);
            this.panel10.Location = new System.Drawing.Point(895, 346);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(143, 121);
            this.panel10.TabIndex = 14;
            // 
            // textfechaexpedicion
            // 
            this.textfechaexpedicion.Location = new System.Drawing.Point(16, 47);
            this.textfechaexpedicion.Name = "textfechaexpedicion";
            this.textfechaexpedicion.Size = new System.Drawing.Size(108, 20);
            this.textfechaexpedicion.TabIndex = 1;
            this.textfechaexpedicion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textfechaexpedicion_KeyPress);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(3, 8);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(121, 13);
            this.label38.TabIndex = 0;
            this.label38.Text = "14 Fecha de expedicion";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel11.Controls.Add(this.textespedido);
            this.panel11.Controls.Add(this.label39);
            this.panel11.Location = new System.Drawing.Point(1197, 346);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(151, 121);
            this.panel11.TabIndex = 15;
            // 
            // textespedido
            // 
            this.textespedido.Location = new System.Drawing.Point(22, 44);
            this.textespedido.Name = "textespedido";
            this.textespedido.Size = new System.Drawing.Size(117, 20);
            this.textespedido.TabIndex = 1;
            this.textespedido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textespedido_KeyPress);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(19, 19);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(84, 13);
            this.label39.TabIndex = 0;
            this.label39.Text = "16 Expedido por";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel12.Controls.Add(this.textCorreo);
            this.panel12.Controls.Add(this.textresidente);
            this.panel12.Controls.Add(this.textDomicilioP);
            this.panel12.Controls.Add(this.label41);
            this.panel12.Controls.Add(this.label40);
            this.panel12.Location = new System.Drawing.Point(681, 475);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(667, 100);
            this.panel12.TabIndex = 16;
            // 
            // textCorreo
            // 
            this.textCorreo.Location = new System.Drawing.Point(479, 12);
            this.textCorreo.Name = "textCorreo";
            this.textCorreo.Size = new System.Drawing.Size(165, 20);
            this.textCorreo.TabIndex = 4;
            this.textCorreo.Text = "Correo";
            // 
            // textresidente
            // 
            this.textresidente.Location = new System.Drawing.Point(342, 65);
            this.textresidente.Name = "textresidente";
            this.textresidente.Size = new System.Drawing.Size(302, 20);
            this.textresidente.TabIndex = 3;
            // 
            // textDomicilioP
            // 
            this.textDomicilioP.Location = new System.Drawing.Point(291, 13);
            this.textDomicilioP.Name = "textDomicilioP";
            this.textDomicilioP.Size = new System.Drawing.Size(160, 20);
            this.textDomicilioP.TabIndex = 2;
            this.textDomicilioP.Text = "Domicilio";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(14, 73);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(308, 13);
            this.label41.TabIndex = 1;
            this.label41.Text = "18 Residente de un Pais distinto del pais de nacionalidad actual";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label40.Location = new System.Drawing.Point(14, 16);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(251, 15);
            this.label40.TabIndex = 0;
            this.label40.Text = "17 Domicio Postal y direccion de correo electronico";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel13.Controls.Add(this.texttelefono);
            this.panel13.Controls.Add(this.label42);
            this.panel13.Location = new System.Drawing.Point(681, 581);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(184, 100);
            this.panel13.TabIndex = 17;
            // 
            // texttelefono
            // 
            this.texttelefono.Location = new System.Drawing.Point(17, 37);
            this.texttelefono.Name = "texttelefono";
            this.texttelefono.Size = new System.Drawing.Size(151, 20);
            this.texttelefono.TabIndex = 1;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(45, 13);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(100, 13);
            this.label42.TabIndex = 0;
            this.label42.Text = "Numero de telefono";
            // 
            // dataregistro
            // 
            this.dataregistro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataregistro.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Apellidos,
            this.Nombres,
            this.FechaN,
            this.luga,
            this.pais,
            this.Sexo,
            this.estado,
            this.Tutor,
            this.Numde,
            this.Tipode,
            this.numv,
            this.feclalim,
            this.Valido,
            this.Expedido,
            this.Domicilio,
            this.Correo,
            this.Numeros});
            this.dataregistro.Location = new System.Drawing.Point(3, 707);
            this.dataregistro.Name = "dataregistro";
            this.dataregistro.Size = new System.Drawing.Size(1345, 141);
            this.dataregistro.TabIndex = 18;
            this.dataregistro.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataregistro_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "#";
            this.Column1.Name = "Column1";
            // 
            // Apellidos
            // 
            this.Apellidos.HeaderText = "Apellidos";
            this.Apellidos.Name = "Apellidos";
            // 
            // Nombres
            // 
            this.Nombres.HeaderText = "Nombres";
            this.Nombres.Name = "Nombres";
            // 
            // FechaN
            // 
            this.FechaN.HeaderText = "Fecha N.";
            this.FechaN.Name = "FechaN";
            // 
            // luga
            // 
            this.luga.HeaderText = "Lugar Nacimiento";
            this.luga.Name = "luga";
            // 
            // pais
            // 
            this.pais.HeaderText = "Pais";
            this.pais.Name = "pais";
            // 
            // Sexo
            // 
            this.Sexo.HeaderText = "Sexo";
            this.Sexo.Name = "Sexo";
            // 
            // estado
            // 
            this.estado.HeaderText = "Estado";
            this.estado.Name = "estado";
            // 
            // Tutor
            // 
            this.Tutor.HeaderText = "Mayor";
            this.Tutor.Name = "Tutor";
            // 
            // Numde
            // 
            this.Numde.HeaderText = "Cedula ";
            this.Numde.Name = "Numde";
            // 
            // Tipode
            // 
            this.Tipode.HeaderText = "Viaje";
            this.Tipode.Name = "Tipode";
            // 
            // numv
            // 
            this.numv.HeaderText = "Numero de Viaje";
            this.numv.Name = "numv";
            // 
            // feclalim
            // 
            this.feclalim.HeaderText = "Fecha Expedicion";
            this.feclalim.Name = "feclalim";
            // 
            // Valido
            // 
            this.Valido.HeaderText = "Valido Hasta";
            this.Valido.Name = "Valido";
            // 
            // Expedido
            // 
            this.Expedido.HeaderText = "Expedido";
            this.Expedido.Name = "Expedido";
            // 
            // Domicilio
            // 
            this.Domicilio.HeaderText = "DomicilioPost";
            this.Domicilio.Name = "Domicilio";
            // 
            // Correo
            // 
            this.Correo.HeaderText = "Correo";
            this.Correo.Name = "Correo";
            // 
            // Numeros
            // 
            this.Numeros.HeaderText = "Telefono";
            this.Numeros.Name = "Numeros";
            // 
            // butagregar
            // 
            this.butagregar.Location = new System.Drawing.Point(1403, 12);
            this.butagregar.Name = "butagregar";
            this.butagregar.Size = new System.Drawing.Size(75, 23);
            this.butagregar.TabIndex = 19;
            this.butagregar.Text = "Add";
            this.butagregar.UseVisualStyleBackColor = true;
            this.butagregar.Click += new System.EventHandler(this.butagregar_Click);
            // 
            // butnuevo
            // 
            this.butnuevo.Location = new System.Drawing.Point(1502, 12);
            this.butnuevo.Name = "butnuevo";
            this.butnuevo.Size = new System.Drawing.Size(75, 23);
            this.butnuevo.TabIndex = 20;
            this.butnuevo.Text = "New";
            this.butnuevo.UseVisualStyleBackColor = true;
            this.butnuevo.Click += new System.EventHandler(this.butnuevo_Click);
            // 
            // buteditar
            // 
            this.buteditar.Location = new System.Drawing.Point(1406, 59);
            this.buteditar.Name = "buteditar";
            this.buteditar.Size = new System.Drawing.Size(75, 23);
            this.buteditar.TabIndex = 21;
            this.buteditar.Text = "Edd";
            this.buteditar.UseVisualStyleBackColor = true;
            this.buteditar.Click += new System.EventHandler(this.buteditar_Click);
            // 
            // buteliminar
            // 
            this.buteliminar.Location = new System.Drawing.Point(1502, 59);
            this.buteliminar.Name = "buteliminar";
            this.buteliminar.Size = new System.Drawing.Size(75, 23);
            this.buteliminar.TabIndex = 22;
            this.buteliminar.Text = "Eliminar";
            this.buteliminar.UseVisualStyleBackColor = true;
            this.buteliminar.Click += new System.EventHandler(this.buteliminar_Click);
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel14.Controls.Add(this.textvalido);
            this.panel14.Controls.Add(this.label61);
            this.panel14.Location = new System.Drawing.Point(1044, 348);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(147, 119);
            this.panel14.TabIndex = 23;
            // 
            // textvalido
            // 
            this.textvalido.Location = new System.Drawing.Point(10, 45);
            this.textvalido.Name = "textvalido";
            this.textvalido.Size = new System.Drawing.Size(135, 20);
            this.textvalido.TabIndex = 1;
            this.textvalido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textvalido_KeyPress);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(10, 8);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(80, 13);
            this.label61.TabIndex = 0;
            this.label61.Text = "15 Valido hasta";
            // 
            // butus
            // 
            this.butus.Location = new System.Drawing.Point(27, 169);
            this.butus.Name = "butus";
            this.butus.Size = new System.Drawing.Size(125, 23);
            this.butus.TabIndex = 24;
            this.butus.Text = "Buscar";
            this.butus.UseVisualStyleBackColor = true;
            this.butus.Click += new System.EventHandler(this.butus_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1604, 882);
            this.Controls.Add(this.butus);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.buteliminar);
            this.Controls.Add(this.buteditar);
            this.Controls.Add(this.butnuevo);
            this.Controls.Add(this.butagregar);
            this.Controls.Add(this.dataregistro);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpsexo);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.grpsexo.ResumeLayout(false);
            this.grpsexo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataregistro)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textApellido;
        private System.Windows.Forms.TextBox textcomparar;
        private System.Windows.Forms.TextBox textNombre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textaño;
        private System.Windows.Forms.TextBox textmes;
        private System.Windows.Forms.TextBox textdia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cobpais;
        private System.Windows.Forms.ComboBox cobnacimiento;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label labsino;
        private System.Windows.Forms.TextBox textNacionalidadactual;
        private System.Windows.Forms.Label labLugarNac;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox grpsexo;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton radBF;
        private System.Windows.Forms.RadioButton radBM;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textespecifique;
        private System.Windows.Forms.RadioButton radBotros;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton radBCasado;
        private System.Windows.Forms.RadioButton radBviudo;
        private System.Windows.Forms.RadioButton radBDivorciado;
        private System.Windows.Forms.RadioButton radBSoltero;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textDirecT;
        private System.Windows.Forms.TextBox textnomA;
        private System.Windows.Forms.TextBox textnomT;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RadioButton radBno;
        private System.Windows.Forms.RadioButton radBsi;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textcedula;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radBPasaOficial;
        private System.Windows.Forms.TextBox textespecifiqueviaje;
        private System.Windows.Forms.RadioButton radBPasaOtro;
        private System.Windows.Forms.RadioButton radBPasaespeci;
        private System.Windows.Forms.RadioButton radBPasadiplo;
        private System.Windows.Forms.RadioButton radBPasaSer;
        private System.Windows.Forms.RadioButton radBPasaO;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox textnumerodeviaje;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox textfechaexpedicion;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textespedido;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox textCorreo;
        private System.Windows.Forms.TextBox textresidente;
        private System.Windows.Forms.TextBox textDomicilioP;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radbdenegado;
        private System.Windows.Forms.RadioButton radbexpedido;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textdivisiondevisado;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radbotros45;
        private System.Windows.Forms.RadioButton radbsegumedico;
        private System.Windows.Forms.RadioButton radbtranspor;
        private System.Windows.Forms.RadioButton radbmedio;
        private System.Windows.Forms.RadioButton radbdocumen;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textnombreexpedido;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.RadioButton radbotros2;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textnombrepequeñi;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textnumerosolicitud;
        private System.Windows.Forms.TextBox textfechasolicitud;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radbfrontera;
        private System.Windows.Forms.RadioButton radbinterme;
        private System.Windows.Forms.RadioButton radbprovedor;
        private System.Windows.Forms.RadioButton radbccs;
        private System.Windows.Forms.RadioButton radbemba;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox texttelefono;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.DataGridView dataregistro;
        private System.Windows.Forms.Button butagregar;
        private System.Windows.Forms.Button butnuevo;
        private System.Windows.Forms.Button buteditar;
        private System.Windows.Forms.Button buteliminar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Apellidos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombres;
        private System.Windows.Forms.DataGridViewTextBoxColumn FechaN;
        private System.Windows.Forms.DataGridViewTextBoxColumn luga;
        private System.Windows.Forms.DataGridViewTextBoxColumn pais;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sexo;
        private System.Windows.Forms.DataGridViewTextBoxColumn estado;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tutor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numde;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tipode;
        private System.Windows.Forms.DataGridViewTextBoxColumn numv;
        private System.Windows.Forms.DataGridViewTextBoxColumn feclalim;
        private System.Windows.Forms.DataGridViewTextBoxColumn Valido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Expedido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Domicilio;
        private System.Windows.Forms.DataGridViewTextBoxColumn Correo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numeros;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox textvalido;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Button butus;
    }
}

