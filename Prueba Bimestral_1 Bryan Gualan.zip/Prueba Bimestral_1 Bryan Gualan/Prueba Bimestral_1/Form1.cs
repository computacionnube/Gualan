﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prueba_Bimestral_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
        int i;
        int pos;
        string sexo, estadocivil;
        string edad;
        string tipoviaje;
        private void Form1_Load(object sender, EventArgs e)
        {




        }

        private void Limpiar()
        {
            textNombre.Text = "";
            textcomparar.Text = "";
            textApellido.Text = "";
            textdia.Text = "";
            textmes.Text = "";
            textaño.Text = "";
            textNacionalidadactual.Text = "";
            labLugarNac.Text = "";
            labsino.Text = "";
            textespecifique.Text = "";
            textnomT.Text = "";
            textnomA.Text = "";
            textDirecT.Text = "";
            textcedula.Text = "";
            textespecifiqueviaje.Text = "";
            textfechaexpedicion.Text = "";
            textvalido.Text = "";
            textespedido.Text = "";
            textDomicilioP.Text = "";
            textCorreo.Text = "";
            textresidente.Text = "";
            texttelefono.Text = "";
            textfechasolicitud.Text = "";
            textnumerosolicitud.Text = "";
            textnombrepequeñi.Text = "";
            textnombreexpedido.Text = "";
            textdivisiondevisado.Text = "";



        }
        private void butagregar_Click(object sender, EventArgs e)
        {
            string apellido, nombre, fechaN,cedula, mumeroviaje, fechaexpedicion, valido, expedido, domicilio, correo, numerotele;
            apellido = textApellido.Text;
            nombre = textNombre.Text;
            cedula = textcedula.Text;
            mumeroviaje = textnumerodeviaje.Text;
            fechaexpedicion = textfechaexpedicion.Text;
            valido = textvalido.Text;
            expedido = textespedido.Text;
            domicilio = textDomicilioP.Text;
            correo = textCorreo.Text;
            numerotele = texttelefono.Text;
            sexo = "";
            tipoviaje = "";
            estadocivil = "";
            fechaN = textdia.Text + textmes.Text + textaño.Text;
            if (radBF.Checked==true)
            {
                sexo += radBF.Text;
            }
            if (radBM.Checked==true)
            {
                sexo += radBM.Text;
            }
            if (radBCasado.Checked==true)
            {
                estadocivil += radBCasado.Text;
            }
            if (radBDivorciado.Checked==true)
            {
                estadocivil += radBDivorciado.Text;
            }
            if (radBSoltero.Checked==true)
            {
                estadocivil += radBSoltero.Text;
            }
            if (radBviudo.Checked==true)
            {
                estadocivil += radBviudo.Text;
            }
            if (radBotros.Checked==true)
            {
                estadocivil += radBotros.Text;
            }
            if (radBsi.Checked==true)
            {
                edad += radBsi.Text;
            }
            if (radBno.Checked==true)
            {
                edad += radBno.Text;
            }
            if (radBPasaO.Checked==true)
            {
                tipoviaje += radBPasaO.Text;
            }
            if (radBPasadiplo.Checked==true)
            {
                tipoviaje += radBPasadiplo.Text;
            }
            if (radBPasaSer.Checked==true)
            {
                tipoviaje += radBPasaSer.Text;
            }
            if (radBPasaespeci.Checked==true)
            {
                tipoviaje += radBPasaespeci.Text;
            }
            if (radBPasaOficial.Checked==true)
            {
                tipoviaje += radBPasaOficial.Text;
            }
            if (radBPasaOtro.Checked==true)
            {
                tipoviaje += radBPasaOtro.Text;
            }
            dataregistro.Rows.Add(i, apellido, nombre, fechaN, cobnacimiento.Text, cobpais.Text, sexo, estadocivil, edad, cedula, tipoviaje, mumeroviaje, fechaexpedicion, valido, expedido,domicilio, correo, numerotele);

            i++;
            if (textApellido.Text == textcomparar.Text && textNombre.Text == textcomparar.Text)
            {
                MessageBox.Show("Continue");
                panel3.Enabled = true;
            }
            else
            {
                MessageBox.Show("Error");
            }

        }

        private void butnuevo_Click(object sender, EventArgs e)
        {
            Limpiar();
            cobnacimiento.Text = null;
            cobpais.Text = null;
            sexo = "";
            estadocivil = "";
            tipoviaje = "";
            edad = "";


           
        }

        private void dataregistro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
  // dataregistro.Rows.Add(i, 1apellido, 2nombre, 3fechaN, 4cobnacimiento.Text, 5cobpais.Text, 6sexo,7 estadocivil, 8edad, 9cedula, 10tipoviaje, mumeroviaje, fechaexpedicion, valido, expedido,domicilio, correo, numerotele);
            pos = dataregistro.CurrentRow.Index;
            textApellido.Text = dataregistro[1, pos].Value.ToString();
            textNombre.Text = dataregistro[2, pos].Value.ToString();
            textdia.Text = dataregistro[3, pos].Value.ToString();
            textmes.Text = dataregistro[3, pos].Value.ToString();
            textaño.Text = dataregistro[3, pos].Value.ToString();
            cobnacimiento.Text = dataregistro[4, pos].Value.ToString();
            cobpais.Text = dataregistro[5, pos].Value.ToString();
            if (radBF.Checked == true)
            {
                radBF.Text = dataregistro[6, pos].Value.ToString();
            }
            if (radBM.Checked == true)
            {
                radBM.Text = dataregistro[6, pos].Value.ToString();
            }
            //
            if (radBCasado.Checked == true)
            {
                radBCasado.Text = dataregistro[7, pos].Value.ToString();
            }
            if (radBDivorciado.Checked == true)
            {
                radBDivorciado.Text = dataregistro[7, pos].Value.ToString();
            }
            if (radBSoltero.Checked == true)
            {
                radBSoltero.Text = dataregistro[7, pos].Value.ToString();
            }
            if (radBviudo.Checked == true)
            {
                radBviudo.Text = dataregistro[7, pos].Value.ToString();
            }
            if (radBotros.Checked == true)
            {
                radBotros.Text = dataregistro[7, pos].Value.ToString();
            }
            //
            if (radBsi.Checked == true)
            {
                radBsi.Text = dataregistro[8, pos].Value.ToString();
            }
            if (radBno.Checked == true)
            {
                radBno.Text = dataregistro[8, pos].Value.ToString();
            }
            //
            textcedula.Text = dataregistro[9, pos].Value.ToString();

            if (radBPasaO.Checked == true)
            {
                radBPasaO.Text = dataregistro[10, pos].Value.ToString();
            }
            if (radBPasadiplo.Checked == true)
            {
                radBPasadiplo.Text = dataregistro[10, pos].Value.ToString();
            }
            if (radBPasaSer.Checked == true)
            {
                radBPasaSer.Text = dataregistro[10, pos].Value.ToString();
            }
            if (radBPasaespeci.Checked == true)
            {
                radBPasaespeci.Text = dataregistro[10, pos].Value.ToString();
            }
            if (radBPasaOficial.Checked == true)
            {
                radBPasaOficial.Text = dataregistro[10, pos].Value.ToString();
            }
            if (radBPasaOtro.Checked == true)
            {
                radBPasaOtro.Text = dataregistro[10, pos].Value.ToString();
            }
            textnumerodeviaje.Text = dataregistro[11, pos].Value.ToString();


        }

        private void buteditar_Click(object sender, EventArgs e)
        {
            dataregistro[1, pos].Value = textApellido.Text;
            dataregistro[2, pos].Value = textNombre.Text;
           dataregistro[3, pos].Value = textdia.Text;
           dataregistro[3, pos].Value = textmes.Text;
           dataregistro[3, pos].Value = textaño.Text;
           dataregistro[4, pos].Value = cobnacimiento.Text;

           dataregistro[5, pos].Value = cobpais.Text;

        }

        private void textcedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;

            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;

            }
        }

        private void textnumerodeviaje_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;

            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;

            }
        }

        private void textvalido_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;

            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;

            }
        }

        private void textfechaexpedicion_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;

            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;

            }
        }

        private void textespedido_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;

            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;

            }
        }

        private void textcomparar_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }

            if (textApellido.Text == textcomparar.Text && textNombre.Text == textcomparar.Text)
            {
                MessageBox.Show("Continue");
                panel3.Enabled = true;
            }
            else
            {
                MessageBox.Show("Error");
            }
          

        }

        private void textNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textNacionalidadactual_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
            labLugarNac.Text = cobnacimiento.Text;
        }

        private void textnomT_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textnomA_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void butus_Click(object sender, EventArgs e)
        {
            OpenFileDialog Imagen = new OpenFileDialog();
            Imagen.InitialDirectory = "C:\\";
            Imagen.Filter = "Archivos de imagen (*.jpg)(jpeg)|*.jpg;*.jpeg|PNG(*.png)|*.png|GIF(*.gif)|*.gif";
            if (Imagen.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = Imagen.FileName;
                pictureBox2.ImageLocation = Imagen.FileName;

            }
            else
            {
                MessageBox.Show("No tiene ninguna imagen seleccionada seguro que desea salir", "Mensaje", MessageBoxButtons.OK);
            }
            
            
        }

        private void buteliminar_Click(object sender, EventArgs e)
        {

            dataregistro.Rows.RemoveAt(pos);
        }

       

        
    }
}
