﻿namespace barras_estado
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.datosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsl1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsl2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsp1 = new System.Windows.Forms.ToolStripProgressBar();
            this.tsm1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsl4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabdatos = new System.Windows.Forms.TabControl();
            this.tP1 = new System.Windows.Forms.TabPage();
            this.butsalir = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.butEdita = new System.Windows.Forms.Button();
            this.butNuevo = new System.Windows.Forms.Button();
            this.listAgenda = new System.Windows.Forms.ListBox();
            this.tP2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.butcancelar = new System.Windows.Forms.Button();
            this.butGuarda = new System.Windows.Forms.Button();
            this.textcorreo = new System.Windows.Forms.TextBox();
            this.texttelefono = new System.Windows.Forms.TextBox();
            this.textdireccion = new System.Windows.Forms.TextBox();
            this.textnombre = new System.Windows.Forms.TextBox();
            this.textcedula = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tP3 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.butregresar = new System.Windows.Forms.Button();
            this.butGuardarB = new System.Windows.Forms.Button();
            this.texttituloS = new System.Windows.Forms.TextBox();
            this.textsuperior = new System.Windows.Forms.TextBox();
            this.texttituloB = new System.Windows.Forms.TextBox();
            this.textbachillerato = new System.Windows.Forms.TextBox();
            this.textprimaria = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tabdatos.SuspendLayout();
            this.tP1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tP2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tP3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.datosToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(469, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // datosToolStripMenuItem
            // 
            this.datosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inicioToolStripMenuItem,
            this.ingresoAToolStripMenuItem,
            this.ingresoBToolStripMenuItem});
            this.datosToolStripMenuItem.Name = "datosToolStripMenuItem";
            this.datosToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.datosToolStripMenuItem.Text = "Datos";
            // 
            // inicioToolStripMenuItem
            // 
            this.inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            this.inicioToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.inicioToolStripMenuItem.Text = "Inicio";
            this.inicioToolStripMenuItem.Click += new System.EventHandler(this.inicioToolStripMenuItem_Click);
            // 
            // ingresoAToolStripMenuItem
            // 
            this.ingresoAToolStripMenuItem.Name = "ingresoAToolStripMenuItem";
            this.ingresoAToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ingresoAToolStripMenuItem.Text = "Ingreso A";
            this.ingresoAToolStripMenuItem.Click += new System.EventHandler(this.ingresoAToolStripMenuItem_Click);
            // 
            // ingresoBToolStripMenuItem
            // 
            this.ingresoBToolStripMenuItem.Name = "ingresoBToolStripMenuItem";
            this.ingresoBToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ingresoBToolStripMenuItem.Text = "Ingreso B";
            this.ingresoBToolStripMenuItem.Click += new System.EventHandler(this.ingresoBToolStripMenuItem_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.salirToolStripMenuItem.Text = "Salir";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripComboBox1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(469, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 25);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsl1,
            this.tsl2,
            this.tsp1,
            this.tsm1,
            this.tsl4});
            this.statusStrip1.Location = new System.Drawing.Point(0, 332);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(469, 26);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsl1
            // 
            this.tsl1.BackColor = System.Drawing.Color.Red;
            this.tsl1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tsl1.BorderStyle = System.Windows.Forms.Border3DStyle.Bump;
            this.tsl1.Image = global::barras_estado.Properties.Resources._8;
            this.tsl1.Name = "tsl1";
            this.tsl1.Size = new System.Drawing.Size(68, 21);
            this.tsl1.Text = "Agenda";
            this.tsl1.Click += new System.EventHandler(this.tsl1_Click);
            // 
            // tsl2
            // 
            this.tsl2.ActiveLinkColor = System.Drawing.Color.Red;
            this.tsl2.BackColor = System.Drawing.Color.Cyan;
            this.tsl2.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tsl2.BorderStyle = System.Windows.Forms.Border3DStyle.Raised;
            this.tsl2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsl2.Name = "tsl2";
            this.tsl2.Size = new System.Drawing.Size(51, 21);
            this.tsl2.Text = "Fecha:";
            // 
            // tsp1
            // 
            this.tsp1.Name = "tsp1";
            this.tsp1.Size = new System.Drawing.Size(100, 20);
            this.tsp1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            // 
            // tsm1
            // 
            this.tsm1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsm1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.tsm1.Image = ((System.Drawing.Image)(resources.GetObject("tsm1.Image")));
            this.tsm1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsm1.Name = "tsm1";
            this.tsm1.Size = new System.Drawing.Size(29, 24);
            this.tsm1.Text = "toolStripDropDownButton1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
            this.toolStripMenuItem1.Text = "Bryana Gualan";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(176, 22);
            this.toolStripMenuItem2.Text = "Analisis en sitemas ";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(176, 22);
            this.toolStripMenuItem3.Text = "Cuarto ciclo";
            // 
            // tsl4
            // 
            this.tsl4.Name = "tsl4";
            this.tsl4.Size = new System.Drawing.Size(38, 21);
            this.tsl4.Text = "toolSt";
            // 
            // tabdatos
            // 
            this.tabdatos.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabdatos.Controls.Add(this.tP1);
            this.tabdatos.Controls.Add(this.tP2);
            this.tabdatos.Controls.Add(this.tP3);
            this.tabdatos.Location = new System.Drawing.Point(0, 64);
            this.tabdatos.Multiline = true;
            this.tabdatos.Name = "tabdatos";
            this.tabdatos.SelectedIndex = 0;
            this.tabdatos.Size = new System.Drawing.Size(457, 234);
            this.tabdatos.TabIndex = 3;
            this.tabdatos.SelectedIndexChanged += new System.EventHandler(this.tabdatos_SelectedIndexChanged);
            // 
            // tP1
            // 
            this.tP1.BackColor = System.Drawing.Color.Cyan;
            this.tP1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tP1.Controls.Add(this.butsalir);
            this.tP1.Controls.Add(this.panel1);
            this.tP1.Controls.Add(this.listAgenda);
            this.tP1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.tP1.Location = new System.Drawing.Point(4, 25);
            this.tP1.Name = "tP1";
            this.tP1.Padding = new System.Windows.Forms.Padding(3);
            this.tP1.Size = new System.Drawing.Size(449, 205);
            this.tP1.TabIndex = 0;
            this.tP1.Text = "Inicio";
            // 
            // butsalir
            // 
            this.butsalir.Location = new System.Drawing.Point(259, 82);
            this.butsalir.Name = "butsalir";
            this.butsalir.Size = new System.Drawing.Size(57, 23);
            this.butsalir.TabIndex = 2;
            this.butsalir.Text = "Salir";
            this.butsalir.UseVisualStyleBackColor = true;
            this.butsalir.Click += new System.EventHandler(this.butsalir_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.butEdita);
            this.panel1.Controls.Add(this.butNuevo);
            this.panel1.Location = new System.Drawing.Point(254, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(63, 69);
            this.panel1.TabIndex = 1;
            // 
            // butEdita
            // 
            this.butEdita.Location = new System.Drawing.Point(3, 37);
            this.butEdita.Name = "butEdita";
            this.butEdita.Size = new System.Drawing.Size(57, 23);
            this.butEdita.TabIndex = 1;
            this.butEdita.Text = "Editar";
            this.butEdita.UseVisualStyleBackColor = true;
            this.butEdita.Click += new System.EventHandler(this.butEdita_Click);
            // 
            // butNuevo
            // 
            this.butNuevo.Location = new System.Drawing.Point(3, 3);
            this.butNuevo.Name = "butNuevo";
            this.butNuevo.Size = new System.Drawing.Size(57, 28);
            this.butNuevo.TabIndex = 0;
            this.butNuevo.Text = "Nuevo";
            this.butNuevo.UseVisualStyleBackColor = true;
            this.butNuevo.Click += new System.EventHandler(this.butNuevo_Click);
            // 
            // listAgenda
            // 
            this.listAgenda.FormattingEnabled = true;
            this.listAgenda.Location = new System.Drawing.Point(3, 7);
            this.listAgenda.Name = "listAgenda";
            this.listAgenda.Size = new System.Drawing.Size(240, 134);
            this.listAgenda.TabIndex = 0;
            this.listAgenda.SelectedIndexChanged += new System.EventHandler(this.listAgenda_SelectedIndexChanged);
            // 
            // tP2
            // 
            this.tP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.tP2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tP2.Controls.Add(this.panel2);
            this.tP2.ForeColor = System.Drawing.Color.Red;
            this.tP2.Location = new System.Drawing.Point(4, 25);
            this.tP2.Name = "tP2";
            this.tP2.Padding = new System.Windows.Forms.Padding(3);
            this.tP2.Size = new System.Drawing.Size(449, 205);
            this.tP2.TabIndex = 1;
            this.tP2.Text = "Ingreso A";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.butcancelar);
            this.panel2.Controls.Add(this.butGuarda);
            this.panel2.Controls.Add(this.textcorreo);
            this.panel2.Controls.Add(this.texttelefono);
            this.panel2.Controls.Add(this.textdireccion);
            this.panel2.Controls.Add(this.textnombre);
            this.panel2.Controls.Add(this.textcedula);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(433, 189);
            this.panel2.TabIndex = 0;
            // 
            // butcancelar
            // 
            this.butcancelar.Location = new System.Drawing.Point(299, 140);
            this.butcancelar.Name = "butcancelar";
            this.butcancelar.Size = new System.Drawing.Size(75, 23);
            this.butcancelar.TabIndex = 11;
            this.butcancelar.Text = "Cancelar ";
            this.butcancelar.UseVisualStyleBackColor = true;
            // 
            // butGuarda
            // 
            this.butGuarda.Location = new System.Drawing.Point(299, 109);
            this.butGuarda.Name = "butGuarda";
            this.butGuarda.Size = new System.Drawing.Size(75, 23);
            this.butGuarda.TabIndex = 10;
            this.butGuarda.Text = "Guardar";
            this.butGuarda.UseVisualStyleBackColor = true;
            this.butGuarda.Click += new System.EventHandler(this.butGuarda_Click);
            // 
            // textcorreo
            // 
            this.textcorreo.Location = new System.Drawing.Point(55, 133);
            this.textcorreo.Name = "textcorreo";
            this.textcorreo.Size = new System.Drawing.Size(129, 20);
            this.textcorreo.TabIndex = 9;
            // 
            // texttelefono
            // 
            this.texttelefono.Location = new System.Drawing.Point(55, 102);
            this.texttelefono.Name = "texttelefono";
            this.texttelefono.Size = new System.Drawing.Size(100, 20);
            this.texttelefono.TabIndex = 8;
            // 
            // textdireccion
            // 
            this.textdireccion.Location = new System.Drawing.Point(55, 69);
            this.textdireccion.Name = "textdireccion";
            this.textdireccion.Size = new System.Drawing.Size(162, 20);
            this.textdireccion.TabIndex = 7;
            // 
            // textnombre
            // 
            this.textnombre.Location = new System.Drawing.Point(55, 38);
            this.textnombre.Name = "textnombre";
            this.textnombre.Size = new System.Drawing.Size(162, 20);
            this.textnombre.TabIndex = 6;
            // 
            // textcedula
            // 
            this.textcedula.Location = new System.Drawing.Point(55, 11);
            this.textcedula.Name = "textcedula";
            this.textcedula.Size = new System.Drawing.Size(100, 20);
            this.textcedula.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(0, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Correo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(-2, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Telefono:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(-2, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Direccion:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cédula:";
            // 
            // tP3
            // 
            this.tP3.BackColor = System.Drawing.Color.Lime;
            this.tP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tP3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tP3.Controls.Add(this.panel3);
            this.tP3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.tP3.Location = new System.Drawing.Point(4, 25);
            this.tP3.Name = "tP3";
            this.tP3.Padding = new System.Windows.Forms.Padding(3);
            this.tP3.Size = new System.Drawing.Size(449, 205);
            this.tP3.TabIndex = 2;
            this.tP3.Text = "Ingreso B";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.butregresar);
            this.panel3.Controls.Add(this.butGuardarB);
            this.panel3.Controls.Add(this.texttituloS);
            this.panel3.Controls.Add(this.textsuperior);
            this.panel3.Controls.Add(this.texttituloB);
            this.panel3.Controls.Add(this.textbachillerato);
            this.panel3.Controls.Add(this.textprimaria);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(7, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(434, 191);
            this.panel3.TabIndex = 0;
            // 
            // butregresar
            // 
            this.butregresar.Location = new System.Drawing.Point(325, 130);
            this.butregresar.Name = "butregresar";
            this.butregresar.Size = new System.Drawing.Size(75, 23);
            this.butregresar.TabIndex = 11;
            this.butregresar.Text = "Regresar";
            this.butregresar.UseVisualStyleBackColor = true;
            this.butregresar.Click += new System.EventHandler(this.butregresar_Click);
            // 
            // butGuardarB
            // 
            this.butGuardarB.Location = new System.Drawing.Point(325, 106);
            this.butGuardarB.Name = "butGuardarB";
            this.butGuardarB.Size = new System.Drawing.Size(75, 23);
            this.butGuardarB.TabIndex = 10;
            this.butGuardarB.Text = "Guardar";
            this.butGuardarB.UseVisualStyleBackColor = true;
            this.butGuardarB.Click += new System.EventHandler(this.butGuardarB_Click);
            // 
            // texttituloS
            // 
            this.texttituloS.Location = new System.Drawing.Point(106, 133);
            this.texttituloS.Name = "texttituloS";
            this.texttituloS.Size = new System.Drawing.Size(100, 20);
            this.texttituloS.TabIndex = 9;
            // 
            // textsuperior
            // 
            this.textsuperior.Location = new System.Drawing.Point(106, 106);
            this.textsuperior.Name = "textsuperior";
            this.textsuperior.Size = new System.Drawing.Size(143, 20);
            this.textsuperior.TabIndex = 8;
            // 
            // texttituloB
            // 
            this.texttituloB.Location = new System.Drawing.Point(106, 63);
            this.texttituloB.Name = "texttituloB";
            this.texttituloB.Size = new System.Drawing.Size(143, 20);
            this.texttituloB.TabIndex = 7;
            // 
            // textbachillerato
            // 
            this.textbachillerato.Location = new System.Drawing.Point(106, 33);
            this.textbachillerato.Name = "textbachillerato";
            this.textbachillerato.Size = new System.Drawing.Size(143, 20);
            this.textbachillerato.TabIndex = 6;
            // 
            // textprimaria
            // 
            this.textprimaria.Location = new System.Drawing.Point(106, 4);
            this.textprimaria.Name = "textprimaria";
            this.textprimaria.Size = new System.Drawing.Size(100, 20);
            this.textprimaria.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 141);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Titulo:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(31, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Superior:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Titulo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Bachillerato:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Primaria:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 358);
            this.Controls.Add(this.tabdatos);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabdatos.ResumeLayout(false);
            this.tP1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tP2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tP3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem datosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresoAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresoBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsl1;
        private System.Windows.Forms.ToolStripStatusLabel tsl2;
        private System.Windows.Forms.ToolStripProgressBar tsp1;
        private System.Windows.Forms.ToolStripDropDownButton tsm1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripStatusLabel tsl4;
        private System.Windows.Forms.TabControl tabdatos;
        private System.Windows.Forms.TabPage tP1;
        private System.Windows.Forms.TabPage tP2;
        private System.Windows.Forms.TabPage tP3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox listAgenda;
        private System.Windows.Forms.Button butNuevo;
        private System.Windows.Forms.Button butsalir;
        private System.Windows.Forms.Button butEdita;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button butcancelar;
        private System.Windows.Forms.Button butGuarda;
        private System.Windows.Forms.TextBox textcorreo;
        private System.Windows.Forms.TextBox texttelefono;
        private System.Windows.Forms.TextBox textdireccion;
        private System.Windows.Forms.TextBox textnombre;
        private System.Windows.Forms.TextBox textcedula;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button butregresar;
        private System.Windows.Forms.Button butGuardarB;
        private System.Windows.Forms.TextBox texttituloS;
        private System.Windows.Forms.TextBox textsuperior;
        private System.Windows.Forms.TextBox texttituloB;
        private System.Windows.Forms.TextBox textbachillerato;
        private System.Windows.Forms.TextBox textprimaria;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
    }
}

