﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace barras_estado
{
   
    struct Agenda

    {
        string cedula;
        string nombre;
        string direc;
        string telef;
        string corre;
        public Agenda(string ced, string nom, string dic,string telf, string cor)
        {
            cedula = ced;
            nombre = nom;
            direc = dic;
            telef = telf;
            corre = cor;

        }
        //IngresoA
        //Nombre
        public void setnombre(string nom)
        {
            nombre = nom;
        }
        public string getnombre()
        {
            return nombre;
        }
        //Cedula
        public void setcedula(string ced)
        {
            cedula = ced;
        }
        public string getcedula()
        {
            return cedula;
        }
        //Direccion
        public void setdireccion(string dic)
        {
            direc = dic;
        }
        public string getdireccion()
        {
            return direc;
        }
        //Telefono

        public void settelefono(string telf)
        {
            telef = telf;
        }
        public string gettelefono()
        {
            return telef;
        }
        //Correo

        public void setcorreo(string cor)
        {
            corre = cor;
        }
        public string getcorreo()
        {
            return corre;
        }

        }
    //IngresoB
    struct Mande
    {
        string Primari;
        string Bachiller;
        string tituloB;
        string superio;
        string tituloS;
        public Mande(string Pri, string Bach, string TitB,string Sup, string TitS)
        {
            Primari = Pri;
            Bachiller = Bach;
            tituloB = TitB;
            superio = Sup;
            tituloS = TitS;

        }
        //Primaria
        private void setprimaria(string Pri)
        {
            Primari = Pri;
        }
        public string getprimaria()
        {
            return Primari;
        }
        //Bachiller
        private void setbachiller(string Bach)
        {
            Bachiller = Bach;
        }
        public string getbachiller()
        {
            return Bachiller;
        }
        //Titulo
        private void settitulo(string TitB)
        {
            tituloB = TitB;
        }
        public string gettituloB()
        {
            return tituloB;
        }
        //Superio
        private void setSuperior(string Sup)
        {
            superio = Sup;
        }
        public string getSuperior()
        {
            return superio;
        }
        //TituloSuperior
        private void setTituloS(string TitS)
        {
            tituloS = TitS;
        }
        public string getTituloSupe()
        {
            return tituloS;
        }
     
    }
   
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int indice = 0;
       
        Agenda[] contactos = new Agenda[100];
        Mande[] restitulos = new Mande[100];
        int pos = 0; int pos2=0;
        int pe = 0; int pe2 = 0;
        string estado = "";
       

        private void Form1_Load(object sender, EventArgs e)
        {
            tsl2.Text += DateTime.Now.ToString();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Desarollador");
        }

        private void tsl1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Datos Personales");
        }

        private void tabdatos_SelectedIndexChanged(object sender, EventArgs e)
        {
            tabdatos.SelectTab(indice);
        }

        private void ingresoAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            indice = 1;
            tabdatos.SelectTab(indice);
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            indice = 1;
            tabdatos.SelectTab(indice);
        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            indice = 0;
            tabdatos.SelectTab(indice);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            indice = 0;
            tabdatos.SelectTab(indice);
        }

        private void ingresoBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            indice = 2;
            tabdatos.SelectTab(indice);
        }


        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            indice = 2;
            tabdatos.SelectTab(indice);
        }

        private void butNuevo_Click(object sender, EventArgs e)
        {
            indice = 1;
            tabdatos.SelectTab(indice);
            estado = "N";
            this.limpiar();
        }

        private void butGuarda_Click(object sender, EventArgs e)
        {
            if (estado=="N")
            {
                llenaestructura(pos);
                pos++;
                listAgenda.Items.Add(textcedula.Text+","+textnombre.Text);
                estado="";
            }
            if (estado=="E")
            {
                llenaestructura(pe);
                listAgenda.Items.Insert(pe, textcedula.Text + "," + textnombre.Text);
                estado = "";
                listAgenda.Items.RemoveAt(pe + 1);
            }
            indice = 2;
            tabdatos.SelectTab(indice);

        }
        private void llenaestructura(int i)
        {
            contactos[i].setcedula(textcedula.Text);
            contactos[i].setnombre(textnombre.Text);
            contactos[i].setdireccion(textdireccion.Text);
            contactos[i].settelefono(texttelefono.Text);
            contactos[i].setcorreo(textcorreo.Text);
       
        }

        private void butregresar_Click(object sender, EventArgs e)
        {
            indice = 0;
            tabdatos.SelectTab(indice);
        }

        private void listAgenda_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listAgenda.SelectedIndex>=0)
            {
                pe = listAgenda.SelectedIndex;
                textcedula.Text = contactos[pe].getcedula();
                textnombre.Text = contactos[pe].getnombre();
                textdireccion.Text = contactos[pe].getdireccion();
                texttelefono.Text =contactos[pe].gettelefono();
                textcorreo.Text = contactos[pe].getcorreo();
            }
        }

        private void butEdita_Click(object sender, EventArgs e)
        {
            indice = 1;
            tabdatos.SelectTab(indice);
            estado = "E";
        }

        private void butsalir_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void limpiar()
        {
            foreach (Control text in this.panel2.Controls)
            {
                if (text is TextBox)
                {
                    text.Text = "";
                }
            }

        }
        //estructuras
        private void LLenarStructura(int i)
        {
           
        }


        private void butGuardarB_Click(object sender, EventArgs e)
        {
           
        }

    }
}
