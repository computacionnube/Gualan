﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace cronometro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int x1=0, y1=0;
        int signox = 1;
        int signoy = 1;
       
        private void btnIniciar_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void btnDetener_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (x1+50<=this.Size.Width && x1>0)
            {
                btnImagen.Location = new Point(x1+=10 * signox,y1);
                if (x1<=1)
                {
                    signoy *= -1;
                    y1 -= 10;
                    x1 = 1;
                }
            }
            if (x1+50>=this.Size.Width || x1==1)
            {
                if (x1+50 >=this.Size.Width && y1<75)
                {
                    signoy *= -1;
                    btnImagen.Location = new Point(x1,y1+=10*signoy);
                    if (y1+90>=this.Size.Height || y1<70)
                    {
                        signox *= -1;
                        if (y1>70)
                        {
                            x1 -= 10;
                        }
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
