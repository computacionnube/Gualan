﻿namespace menus
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.vectoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interseccioonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.diferenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matricesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cuadradaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.latinaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.cuboMagicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labcolor1 = new System.Windows.Forms.Label();
            this.vScrojo = new System.Windows.Forms.VScrollBar();
            this.vScazul = new System.Windows.Forms.VScrollBar();
            this.vScverde = new System.Windows.Forms.VScrollBar();
            this.pict1 = new System.Windows.Forms.PictureBox();
            this.hScancho = new System.Windows.Forms.HScrollBar();
            this.vScalto = new System.Windows.Forms.VScrollBar();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vectoreToolStripMenuItem,
            this.matricesToolStripMenuItem,
            this.salirToolStripMenuItem,
            this.toolStripComboBox1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(454, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // vectoreToolStripMenuItem
            // 
            this.vectoreToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unionToolStripMenuItem,
            this.interseccioonToolStripMenuItem,
            this.toolStripMenuItem1,
            this.diferenciaToolStripMenuItem});
            this.vectoreToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow;
            this.vectoreToolStripMenuItem.Image = global::menus.Properties.Resources._8;
            this.vectoreToolStripMenuItem.Name = "vectoreToolStripMenuItem";
            this.vectoreToolStripMenuItem.Size = new System.Drawing.Size(75, 23);
            this.vectoreToolStripMenuItem.Text = "&Vectore";
            // 
            // unionToolStripMenuItem
            // 
            this.unionToolStripMenuItem.Name = "unionToolStripMenuItem";
            this.unionToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.unionToolStripMenuItem.Text = "Union";
            // 
            // interseccioonToolStripMenuItem
            // 
            this.interseccioonToolStripMenuItem.Name = "interseccioonToolStripMenuItem";
            this.interseccioonToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.interseccioonToolStripMenuItem.Text = "Interseccioon";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(142, 6);
            // 
            // diferenciaToolStripMenuItem
            // 
            this.diferenciaToolStripMenuItem.Name = "diferenciaToolStripMenuItem";
            this.diferenciaToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.diferenciaToolStripMenuItem.Text = "Diferencia";
            // 
            // matricesToolStripMenuItem
            // 
            this.matricesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cuadradaToolStripMenuItem,
            this.latinaToolStripMenuItem,
            this.toolStripMenuItem2,
            this.cuboMagicoToolStripMenuItem});
            this.matricesToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.matricesToolStripMenuItem.Name = "matricesToolStripMenuItem";
            this.matricesToolStripMenuItem.Size = new System.Drawing.Size(64, 23);
            this.matricesToolStripMenuItem.Text = "&Matrices";
            // 
            // cuadradaToolStripMenuItem
            // 
            this.cuadradaToolStripMenuItem.Name = "cuadradaToolStripMenuItem";
            this.cuadradaToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.cuadradaToolStripMenuItem.Text = "Cuadrada";
            // 
            // latinaToolStripMenuItem
            // 
            this.latinaToolStripMenuItem.Name = "latinaToolStripMenuItem";
            this.latinaToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.latinaToolStripMenuItem.Text = "Latina";
            this.latinaToolStripMenuItem.ToolTipText = "Latina";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(143, 6);
            // 
            // cuboMagicoToolStripMenuItem
            // 
            this.cuboMagicoToolStripMenuItem.Name = "cuboMagicoToolStripMenuItem";
            this.cuboMagicoToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.cuboMagicoToolStripMenuItem.Text = "Cubo magico";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(40, 23);
            this.salirToolStripMenuItem.Text = "salir";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "Serie1",
            "Serie2",
            "Serie3"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBox1.Text = "Serie";
            this.toolStripComboBox1.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(90, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 1;
            // 
            // labcolor1
            // 
            this.labcolor1.BackColor = System.Drawing.Color.White;
            this.labcolor1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labcolor1.Location = new System.Drawing.Point(93, 78);
            this.labcolor1.Name = "labcolor1";
            this.labcolor1.Size = new System.Drawing.Size(100, 122);
            this.labcolor1.TabIndex = 2;
            // 
            // vScrojo
            // 
            this.vScrojo.LargeChange = 5;
            this.vScrojo.Location = new System.Drawing.Point(9, 78);
            this.vScrojo.Maximum = 255;
            this.vScrojo.Name = "vScrojo";
            this.vScrojo.Size = new System.Drawing.Size(21, 122);
            this.vScrojo.TabIndex = 3;
            this.vScrojo.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrojo_Scroll);
            // 
            // vScazul
            // 
            this.vScazul.LargeChange = 5;
            this.vScazul.Location = new System.Drawing.Point(70, 78);
            this.vScazul.Maximum = 255;
            this.vScazul.Name = "vScazul";
            this.vScazul.Size = new System.Drawing.Size(17, 122);
            this.vScazul.TabIndex = 4;
            this.vScazul.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScazul_Scroll);
            // 
            // vScverde
            // 
            this.vScverde.LargeChange = 5;
            this.vScverde.Location = new System.Drawing.Point(43, 78);
            this.vScverde.Maximum = 255;
            this.vScverde.Name = "vScverde";
            this.vScverde.Size = new System.Drawing.Size(17, 121);
            this.vScverde.TabIndex = 5;
            this.vScverde.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScverde_Scroll);
            // 
            // pict1
            // 
            this.pict1.Image = global::menus.Properties.Resources._8;
            this.pict1.Location = new System.Drawing.Point(305, 79);
            this.pict1.Name = "pict1";
            this.pict1.Size = new System.Drawing.Size(60, 60);
            this.pict1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pict1.TabIndex = 6;
            this.pict1.TabStop = false;
            // 
            // hScancho
            // 
            this.hScancho.Location = new System.Drawing.Point(305, 56);
            this.hScancho.Name = "hScancho";
            this.hScancho.Size = new System.Drawing.Size(120, 17);
            this.hScancho.TabIndex = 7;
            this.hScancho.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScancho_Scroll);
            // 
            // vScalto
            // 
            this.vScalto.Location = new System.Drawing.Point(285, 59);
            this.vScalto.Name = "vScalto";
            this.vScalto.Size = new System.Drawing.Size(17, 120);
            this.vScalto.TabIndex = 8;
            this.vScalto.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScalto_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 262);
            this.Controls.Add(this.vScalto);
            this.Controls.Add(this.hScancho);
            this.Controls.Add(this.pict1);
            this.Controls.Add(this.vScverde);
            this.Controls.Add(this.vScazul);
            this.Controls.Add(this.vScrojo);
            this.Controls.Add(this.labcolor1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem matricesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cuadradaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem latinaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cuboMagicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vectoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interseccioonToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem diferenciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labcolor1;
        private System.Windows.Forms.VScrollBar vScrojo;
        private System.Windows.Forms.VScrollBar vScazul;
        private System.Windows.Forms.VScrollBar vScverde;
        private System.Windows.Forms.PictureBox pict1;
        private System.Windows.Forms.HScrollBar hScancho;
        private System.Windows.Forms.VScrollBar vScalto;
    }
}

