﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace menus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        int ancho, alto;

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (toolStripComboBox1.SelectedIndex == 0)
            {
                MessageBox.Show("Serie Basica");

            }
            else
            {
                if (toolStripComboBox1.SelectedIndex == 1)
                {
                    MessageBox.Show("serie media");
                }

            }

            if (toolStripComboBox1.SelectedIndex == 2)
            {
                MessageBox.Show("serie compleja");
            } 
 
        }

        private void vScrojo_Scroll(object sender, ScrollEventArgs e)
        {
            labcolor1.BackColor = Color.FromArgb(vScrojo.Value, vScverde.Value, vScazul.Value);
        }

        private void vScverde_Scroll(object sender, ScrollEventArgs e)
        {
            labcolor1.BackColor = Color.FromArgb(vScrojo.Value, vScverde.Value, vScazul.Value);
        }

        private void vScazul_Scroll(object sender, ScrollEventArgs e)
        {
            labcolor1.BackColor = Color.FromArgb(vScrojo.Value, vScverde.Value, vScazul.Value);
        }

        private void hScancho_Scroll(object sender, ScrollEventArgs e)
        {
            ancho = 60 + hScancho.Value;
            pict1.Size = new Size(ancho, alto);
        }

        private void vScalto_Scroll(object sender, ScrollEventArgs e)
        {
            alto = 60 + vScalto.Value;
            pict1.Size = new Size(ancho,alto);
        }

       

    }
}
